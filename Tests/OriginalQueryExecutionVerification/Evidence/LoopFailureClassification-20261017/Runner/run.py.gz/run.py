#!/usr/bin/env python3
"""Verify the actual prepared face caller using existing receipted lower products."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
MASS = BASE.parent / 'u1-mass-direct-20261016'
sys.path.insert(0, str(SOURCE / 'Tests/OriginalQueryExecutionVerification'))
from native_tests import run, RSS_BYTES

ORIGINS = {
    'native': '2f31acb76717f3d5de9c9e4b157ddb223865edde9684bd6519cacc8fd48d8364',
    'asan': '2f31acb76717f3d5de9c9e4b157ddb223865edde9684bd6519cacc8fd48d8364',
    'wasm': '74da3d559dbe2e7d221f4112eb64b040272b99848fcd2b883fcd2216250e64cd',
    'embedded': 'c7172f5119678388a48eedbe95f38300b3d38f590469721d376cffacab451c0d',
}
SOURCES = {
    'CADModeling': ['Sources/CADModeling/ExactFacePcurve/ExactFacePcurveBuilder.swift'],
    'CADKernel': [
        'Sources/CADKernel/FiniteFaceContainment/DefaultFacePointContainmentTester.swift',
        'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentTesting.swift',
        'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentPreparationCache.swift',
        'Sources/CADKernel/PreparedBooleanOperation/PreparedBooleanQueryLifetime.swift',
        'Sources/CADKernel/OriginalBRepBounds/OriginalFaceParameterBounds.swift',
        'Sources/CADKernel/OriginalGeometryQuery/OriginalQueryExecution+Kernel.swift',
    ],
}
FIXTURE = 'Tests/OriginalQueryExecutionVerification/FaceContainmentLoopFailureClassificationPortable.swift'
EXPECTED = ['PASS authoredRectanglePreparesAndClassifiesItsOriginalUV',
            'PASS lowerLoopWorkRefusalPreservesItsOriginalClassificationAndContext',
            'PASS lowerLoopCallerCancellationKeepsItsCause']


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(value, message):
    if not value:
        raise RuntimeError(message)


def verify(files):
    for path, sha in files.items():
        require(digest(path) == sha, 'Changed input/product/log: ' + path)


def prepare(lane):
    output = BASE / lane
    output.mkdir(exist_ok=False)
    origin_path = MASS / 'portable-import-final-r4' / ('asan' if lane == 'native' else lane) / 'receipt.json'
    require(digest(origin_path) == ORIGINS[lane], 'Accepted portable authority changed.')
    origin = json.loads(origin_path.read_text())
    require(origin['status'] == 'passed' and origin['sourcesProductsAndLogsUnchanged'],
            'Accepted portable lower-product authority was not successful.')
    # Verify the complete literal origin pins once before any cache is consumed.
    # The stage checks retain these exact pins instead of changing the old loader.
    files = dict(origin['inputAndProductSHA256'])
    files[str(origin_path)] = ORIGINS[lane]
    verify(files)
    native_path = MASS / 'main-authority-r1/receipt.json'
    require(digest(native_path) == '2f2c8a793521ef5c0ee4a51cfbe084ad28f77d7c811c6e9c88e7b3e86640ec88',
            'Current Main source authority changed.')
    native = json.loads(native_path.read_text())
    files[str(native_path)] = digest(native_path)
    lower_names = {'CADCore', 'CADGeometry', 'CADTopology', 'CADIR'}
    lower = {p: h for p, h in native['sourceSHA256'].items()
             if p.split('/')[1] in lower_names}
    require(len(lower) == 3198, 'Current lower source inventory differs.')
    for relative, sha in lower.items():
        require(digest(SOURCE / relative) == sha, 'Current lower source changed: ' + relative)
        files[str(SOURCE / relative)] = sha
    comparison_path = BASE / 'import-only-comparison.json'
    comparison = json.loads(comparison_path.read_text())
    require(comparison['allInverseByteEqual'], 'Exact target-capability correction was not accepted.')
    files[str(comparison_path)] = digest(comparison_path)
    for relative in [p for paths in SOURCES.values() for p in paths]:
        change = comparison['changes'].get(relative)
        if change: require(change['beforeSHA256'] == native['sourceSHA256'][relative], 'Changed source authority differs.')
        expected = change['afterSHA256'] if change else native['sourceSHA256'][relative]
        require(digest(SOURCE / relative) == expected,
                'Actual caller source differs from accepted Main: ' + relative)
    sources = {p: digest(SOURCE / p) for paths in SOURCES.values() for p in paths}
    fixture_sha = digest(SOURCE / FIXTURE)
    files[str(SOURCE / FIXTURE)] = fixture_sha
    files[str(SOURCE / 'Tests/CADKernelTests/FaceContainmentLoopFailureClassificationTests.swift')] = (
        digest(SOURCE / 'Tests/CADKernelTests/FaceContainmentLoopFailureClassificationTests.swift'))
    for name in ['native_tests.py', 'typecheck.py']:
        path = SOURCE / 'Tests/OriginalQueryExecutionVerification' / name
        files[str(path)] = digest(path)
    files[str(Path(__file__))] = digest(Path(__file__))
    require(RSS_BYTES == 10 * 1024**3, 'Canonical process-tree memory bound differs.')
    for relative, sha in {**sources, FIXTURE: fixture_sha}.items():
        copy = output / 'snapshot' / relative
        copy.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / relative, copy)
        files[str(copy)] = sha
        files[str(SOURCE / relative)] = sha
    modules = output / 'modules'
    modules.mkdir()
    old_compile = origin['commands']['CADKernel']
    flags = old_compile[1:old_compile.index('-module-name')]
    # The previous Kernel module is never selected as this caller's authority.
    old_kernel_modules = str(origin_path.parent / 'modules')
    for index in range(len(flags) - 2, -1, -1):
        if flags[index:index + 2] == ['-I', old_kernel_modules]:
            del flags[index:index + 2]
    native_objects = None
    if lane == 'native':
        cleaned = []
        index = 0
        while index < len(flags):
            if flags[index] == '-I':
                index += 2
            elif flags[index] == '-sanitize=address':
                index += 1
            else:
                cleaned.append(flags[index]); index += 1
        native_modules = native_path.parent / 'modules'
        collection_path = Path(native['collectionsProductsReceipt']['path'])
        require(digest(collection_path) == native['collectionsProductsReceipt']['sha256'], 'Native Collections receipt changed.')
        collection_products = json.loads(collection_path.read_text())
        files[str(collection_path)] = digest(collection_path)
        files.update(collection_products)
        flags = cleaned + ['-I', str(native_modules), '-I', str(Path(next(iter(collection_products))).parent)]
        native_objects = []
        for module in ['CADCore', 'CADGeometry', 'CADTopology', 'CADIR']:
            for suffix, sha in [('.swiftmodule', native['products'][module]), ('.o', native['objects'][module])]:
                product = native_modules / (module + suffix)
                require(digest(product) == sha, 'Native lower product changed: ' + str(product))
                files[str(product)] = sha
                if suffix == '.o': native_objects.append(str(product))
            owner_path = Path(native['steps'][module]['reusedFrom'])
            owner = json.loads(owner_path.read_text())
            files[str(owner_path)] = digest(owner_path)
            log = owner_path.parent / (module + '.log')
            require(digest(log) == native['steps'][module]['logSHA256'], 'Native lower compiler log changed.')
            files[str(log)] = digest(log)
        native_objects += [p for p in collection_products if p.endswith('.o')]
    flags = ['-I', str(modules)] + flags
    commands = {}
    products = {}
    for module, relative_sources in SOURCES.items():
        response = output / (module + 'Sources.rsp')
        response.write_text(''.join('"' + str(output / 'snapshot' / p) + '"\n'
                                    for p in sorted(relative_sources)))
        files[str(response)] = digest(response)
        module_path = modules / (module + '.swiftmodule')
        command = [old_compile[0]] + flags + ['-module-name', module, '-emit-module',
                   '-emit-module-path', str(module_path)]
        products[module] = [str(module_path)]
        if lane != 'embedded':
            obj = modules / (module + '.code.o')
            command += ['-emit-object', '-o', str(obj)]
            products[module].append(str(obj))
        commands[module] = command + ['@' + str(response)]
    old_link = origin['commands']['client-link']
    objects = [p for p in old_link if p.endswith('.o')]
    objects = [str(modules / Path(p).name) if Path(p).name in
               {'CADModeling.code.o', 'CADKernel.code.o'} else p for p in objects]
    if lane == 'native':
        objects = native_objects + [str(modules / (m + '.code.o')) for m in SOURCES]
    executable = output / ('LoopFailureClassification' if lane in {'native', 'asan'} else 'LoopFailureClassification.wasm')
    tail = old_link[old_link.index('-o'):]
    tail[1] = str(executable)
    commands['client-link'] = ([old_compile[0]] + flags +
        [str(output / 'snapshot' / FIXTURE)] + objects + tail)
    commands['runtime'] = ([str(executable)] if lane in {'native', 'asan'} else
        origin['commands']['runtime'][:-1] + [str(executable)])
    model_path = BASE.parent / ('u1-loopclass-final-20261017' if lane in {'native', 'embedded'} else 'u1-loopclass-portable-20261017') / lane / 'receipt.json'
    model_origin = json.loads(model_path.read_text())
    model_step = model_origin['steps']['CADModeling']
    require(model_step['exitCode'] == 0 and model_step['stopReason'] is None, 'Actual one-file Modeling compiler phase was not successful.')
    model_relative = SOURCES['CADModeling'][0]
    require(model_origin['sourceSHA256'][model_relative] == sources[model_relative], 'One-file Modeling source changed.')
    files[str(model_path)] = digest(model_path)
    model_log = model_path.parent / 'CADModeling.log'
    require(digest(model_log) == model_step['logSHA256'], 'One-file Modeling compiler log changed.')
    files[str(model_log)] = digest(model_log)
    for product in model_origin['products']['CADModeling']:
        sha = model_origin['inputAndProductSHA256'][product]
        require(digest(product) == sha, 'One-file Modeling product changed.')
        files[product] = sha
    model_modules = Path(model_origin['products']['CADModeling'][0]).parent
    for stage in ['CADKernel', 'client-link']:
        require(commands[stage][1:3] == ['-I', str(modules)], 'Current Kernel import must remain first.')
        commands[stage][3:3] = ['-I', str(model_modules)]
    commands['client-link'] = [str(model_modules / Path(v).name) if v == str(modules / 'CADModeling.code.o') else v for v in commands['client-link']]
    commands['CADModeling'] = model_origin['commands']['CADModeling']
    products['CADModeling'] = model_origin['products']['CADModeling']
    kernel_reused_step = None
    if lane in {'native', 'embedded'}:
        kernel_path = BASE.parent / 'u1-loopclass-current-20261017' / lane / 'receipt.json'
        kernel_origin = json.loads(kernel_path.read_text())
        kernel_step = kernel_origin['steps']['CADKernel']
        require(kernel_step['exitCode'] == 0 and kernel_step['stopReason'] is None, 'Current six-file Kernel compile phase was not successful.')
        for relative in SOURCES['CADKernel']:
            require(kernel_origin['sourceSHA256'][relative] == sources[relative], 'Current cached Kernel source differs.')
            snapshot = kernel_path.parent / 'snapshot' / relative
            require(digest(snapshot) == sources[relative], 'Current cached Kernel snapshot differs.')
            files[str(snapshot)] = sources[relative]
        files[str(kernel_path)] = digest(kernel_path)
        kernel_log = kernel_path.parent / 'CADKernel.log'
        require(digest(kernel_log) == kernel_step['logSHA256'], 'Current Kernel compiler log changed.')
        files[str(kernel_log)] = digest(kernel_log)
        for product in kernel_origin['products']['CADKernel']:
            sha = kernel_origin['inputAndProductSHA256'][product]
            require(digest(product) == sha, 'Current Kernel product changed.')
            files[product] = sha
        kernel_modules = Path(kernel_origin['products']['CADKernel'][0]).parent
        commands['client-link'][3:3] = ['-I', str(kernel_modules)]
        commands['client-link'] = [str(kernel_modules / Path(v).name) if v == str(modules / 'CADKernel.code.o') else v for v in commands['client-link']]
        commands['CADKernel'] = kernel_origin['commands']['CADKernel']
        products['CADKernel'] = kernel_origin['products']['CADKernel']
        kernel_reused_step = dict(kernel_step, reusedFrom=str(kernel_path), originSHA256=digest(kernel_path))
    reused_step = dict(model_step, reusedFrom=str(model_path), originSHA256=digest(model_path))
    return {
        'schemaVersion': 1, 'status': 'prepared', 'lane': lane, 'sourceRoot': str(SOURCE),
        'scope': 'Final C-math/direct-import/cancellation capability correction; actual whole-file Modeling1/Kernel6 and three prepared-session oracles; no whole module/family completion.',
        'sourceSHA256': sources, 'fixture': {'path': FIXTURE, 'sha256': fixture_sha},
        'reusedLowerSourceCount': 3198, 'lowerModulesRegenerated': False,
        'acceptedPortableOrigin': {'path': str(origin_path), 'sha256': ORIGINS[lane]},
        'inputAndProductSHA256': files, 'commands': commands, 'products': products,
        'executable': str(executable), 'expectedOutputLines': EXPECTED, 'steps': {'CADModeling': reused_step, **({'CADKernel': kernel_reused_step} if kernel_reused_step else {})},
        'kernelModuleRegenerated': lane not in {'native', 'embedded'},
        'modelingModuleRegenerated': False,
        'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120,
                   'processTreeRSSBytes': RSS_BYTES, 'jobs': 1},
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', choices=ORIGINS, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--resume-plan', action='store_true')
    args = parser.parse_args()
    output = BASE / args.lane
    receipt_path = output / 'receipt.json'
    record = None
    try:
        if args.resume_plan:
            record = json.loads(receipt_path.read_text())
            require(record['status'] == 'prepared' and record['lane'] == args.lane,
                    'Only unexecuted exact plans may resume.')
        else:
            record = prepare(args.lane)
        verify(record['inputAndProductSHA256'])
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        if args.prepare_only:
            print(json.dumps({'status': 'prepared', 'lane': args.lane}), flush=True)
            return
        record['status'] = 'running'
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['PATH'] = str(Path(record['commands']['CADKernel'][0]).parent) + ':' + environment.get('PATH', '')
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        deadline = time.monotonic() + 1200
        for stage in (['CADKernel'] if record['kernelModuleRegenerated'] else []) + ['client-link', 'runtime']:
            verify(record['inputAndProductSHA256'])
            result = run(record['commands'][stage], output / (stage + '.log'), environment,
                         deadline=(time.monotonic() + 120) if stage == 'runtime' else deadline,
                         stage_limit=120 if stage == 'runtime' else 1200)
            record['steps'][stage] = result
            record['inputAndProductSHA256'][str(output / (stage + '.log'))] = result['logSHA256']
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
            require(result['exitCode'] == 0 and result['stopReason'] is None, stage + ' failed.')
            if stage in record['products']:
                record['inputAndProductSHA256'].update({p: digest(p) for p in record['products'][stage]})
            elif stage == 'client-link':
                record['inputAndProductSHA256'][record['executable']] = digest(record['executable'])
            else:
                lines = (output / 'runtime.log').read_text().splitlines()
                require(all(line in lines for line in record['expectedOutputLines']), 'Missing actual prepared-session oracle.')
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps({'lane': args.lane, 'stage': stage, 'exitCode': result['exitCode'],
                  'elapsedSeconds': result['elapsedSeconds'], 'peakRSSBytes': result['sampledPeakProcessTreeRSSBytes']}), flush=True)
        verify(record['inputAndProductSHA256'])
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
    except Exception as error:
        if record is not None:
            record['status'] = 'failed'
            record['failure'] = str(error)
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        print(str(error), flush=True)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
