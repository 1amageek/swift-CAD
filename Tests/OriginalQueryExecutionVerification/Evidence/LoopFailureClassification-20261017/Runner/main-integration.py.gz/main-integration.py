#!/usr/bin/env python3
import hashlib, json, os, shutil, subprocess, sys, time
from pathlib import Path
BASE=Path(__file__).resolve().parent
CANDIDATE=Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
MAIN=Path('/Users/1amageek/Desktop/3D/swift-CAD')
sys.path.insert(0,str(CANDIDATE/'Tests/OriginalQueryExecutionVerification'))
from native_tests import run, RSS_BYTES

def sha(path):
 with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(c,m):
 if not c:raise RuntimeError(m)
def verify(files):
 for p,h in files.items():require(sha(p)==h,'Changed Main dependency: '+p)

out=BASE/'main-delivery';out.mkdir(exist_ok=False)
origin_path=BASE/'native/receipt.json';origin=json.loads(origin_path.read_text())
require(origin['status']=='passed' and origin['sourcesProductsAndLogsUnchanged'],'Final actual Native proof missing.')
require(sha(origin_path)=='7df30599acc819e24c05bfe3b65de53482d574cc7b64f3ccd1e999ac34c4848e','Final actual Native receipt changed.')
files=dict(origin['inputAndProductSHA256']);files[str(origin_path)]=sha(origin_path)
verify(files)
authority=BASE.parent/'u1-mass-direct-20261016/main-authority-r1/receipt.json'
require(sha(authority)=='2f2c8a793521ef5c0ee4a51cfbe084ad28f77d7c811c6e9c88e7b3e86640ec88','Parent Main authority changed.')
sources=json.loads(authority.read_text())['sourceSHA256']
changes=json.loads((BASE/'import-only-comparison.json').read_text())['changes']
for p,v in changes.items():
 require(sources[p]==v['beforeSHA256'],'Parent Main source differs: '+p)
 sources[p]=v['afterSHA256']
require(len(sources)==3927,'Current six-module source inventory changed.')
for p,h in sources.items():
 require(sha(MAIN/p)==h,'Main production source changed: '+p)
 files[str(MAIN/p)]=h
fixture=origin['fixture']['path'];require(sha(MAIN/fixture)==origin['fixture']['sha256'],'Main public fixture differs.')
copy=out/'snapshot'/fixture;copy.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(MAIN/fixture,copy)
files[str(MAIN/fixture)]=sha(copy);files[str(copy)]=sha(copy);files[str(Path(__file__))]=sha(Path(__file__))
command=list(origin['commands']['client-link'])
old_fixture=[v for v in command if v.endswith('.swift')];require(len(old_fixture)==1,'Unexpected Native fixture closure.')
command=[str(copy) if v==old_fixture[0] else v for v in command]
executable=out/'MainLoopFailureClassification';command[command.index('-o')+1]=str(executable)
record={'status':'running','sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=MAIN,text=True).strip(),'sourceRoot':str(MAIN),'sourceParityCount':3927,'actualCompiledKernelScope':origin['sourceSHA256'],'publicOracles':origin['expectedOutputLines'],'productionModulesGenerated':0,'inputAndProductSHA256':files,'commands':{'client-link':command,'runtime':[str(executable)]},'steps':{},'bounds':{'compileLinkSeconds':1200,'runtimeSeconds':120,'processTreeRSSBytes':RSS_BYTES,'jobs':1}}
receipt=out/'integration.json'
def save():receipt.write_text(json.dumps(record,indent=2)+'\n')
save();environment=dict(os.environ);environment.pop('TOOLCHAINS',None)
try:
 deadline=time.monotonic()+1200
 for stage in ['client-link','runtime']:
  verify(files)
  step=run(record['commands'][stage],out/(stage+'.log'),environment,deadline=(time.monotonic()+120) if stage=='runtime' else deadline,stage_limit=120 if stage=='runtime' else 1200)
  record['steps'][stage]=step;save()
  require(step['exitCode']==0 and step['stopReason'] is None,'Main '+stage+' failed.')
  files[str(out/(stage+'.log'))]=step['logSHA256']
  if stage=='client-link':files[str(executable)]=sha(executable)
  else:
   lines=(out/'runtime.log').read_text().splitlines()
   require(all(v in lines for v in record['publicOracles']),'Main public oracle missing.')
  save();print(json.dumps({'stage':stage,'seconds':step['elapsedSeconds'],'exitCode':step['exitCode']}),flush=True)
 verify(files);record['status']='passed';save()
except Exception as error:
 record['status']='failed';record['failure']=str(error);save();raise
