# Mass Direct Admission Review

One comprehensive Root review covers the frozen production source map, complete
document decomposition, original and new mathematical bodies, public callers,
initial four shared groups and two Native controls. This is the single broad
review; finding corrections receive only targeted confirmation.

| Invariant | Source assessment |
|---|---|
| Public witness | Both document-unit and explicit-unit direct operations are actual protocol requirements; ordinary entries delegate once |
| One owner and limits | Existing allocation scope includes request setup; contribution and local work delta retain the same budget and original ceilings |
| Mathematics | Original unit powers, tensor arithmetic order, Jacobi32 candidate policy, interval reconstruction/frame/residual proof remain unchanged |
| Work and storage | Actual variable scans, dictionary insertion, matrix/scratch/COW/result arrays and fixed loops use existing direct storage admission |
| Publication | Result validation borrows the caller; final immutable fields retain array owners and include validator consumption before terminal checks |
| Snapshot | All14 fields/defaults/receipt initialization/native coding bodies remain original; inverse composition evidence31f8a6c7 confirms the move |
| Failure | Original producer causes propagate; exhaustion/cancel cannot publish partial output; missing cache remains an explicit native codec refusal |

No production counterexample remains in this source review. Actual compile/link
and runtime remain pending; source review alone is not implementation acceptance.

## F1: Default-density consumer branch lacks runtime coverage

The initial shared fixture always supplies component density. Its throwing
attribute witness proves non-use, but does not execute the changed admitted
contains/filter path with a successfully resolved value. Add one lawful injected
producer that reads an actual authored CADIR density assignment and corresponding
body/document identity on the same execution, then exercise density=nil through
the actual Mass requirement and independent mass/tensor oracle. This does not
establish the default resolver's source/cache/assembly algorithm. Its uncached raw
input must retain its actual inconsistentArtifact refusal.

## State and Ownership Matrix

| Logical state | Targets | Storage/isolation | Read | Mutation | Release |
|---|---|---|---|---|---|
| Moment call observer | Native/ASAN/WASM/Embedded | Same Sendable class, Mutex<State> | snapshot/withLock | visit and complete/withLock | Invocation scope; after-lower callback observer has no budget reference |
| Cancellation ordinal | Native/ASAN/WASM/Embedded | Same Sendable class, Mutex<Int> | count/withLock | check increment/withLock | Invocation callback retains observer; no reverse budget ownership |
| Evaluated snapshot | All targets | Same14 value/COW/receipt fields, same Sendable contract | Existing value access | Existing value mutation entry points | Existing retained source/assembly/cache owners |

Real producers, oracle checks, throwing cancellation and external budget callbacks
execute outside locks. Native Codable conditional compilation changes transport
capability only; no platform removes storage, Sendable or synchronization.
