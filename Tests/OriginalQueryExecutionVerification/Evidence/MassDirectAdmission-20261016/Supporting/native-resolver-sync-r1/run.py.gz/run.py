#!/usr/bin/env python3
"""One actual synchronous resolver client using existing accepted Native products."""
from pathlib import Path
import hashlib,json,os,sys,time
D=Path('/Users/1amageek/.codex/verification-artifacts/swift-CAD/u1-mass-direct-20261016');OUT=Path(__file__).resolve().parent
TOOLS=Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification');sys.path.insert(0,str(TOOLS))
import native_tests as monitor
from typecheck import verify_collections_products
source=OUT/'ResolverSynchronousAdmission.swift';authority=D/'native-two-file-mass-r2/receipt.json';r=json.loads(authority.read_text());digest=monitor.digest
assert digest(authority)=='b5ed23f4bc18042779014c2681533729f76663b584bfb842233f6a43473558d6'
files={str(authority):digest(authority),str(source):digest(source),str(Path(__file__)):digest(Path(__file__)),str(TOOLS/'native_tests.py'):digest(TOOLS/'native_tests.py'),str(TOOLS/'typecheck.py'):digest(TOOLS/'typecheck.py')}
for path,sha in r['sourceSHA256'].items(): files[str(Path(r['sourceRoot'])/path)]=sha;files[str(authority.parent/'snapshot'/path)]=sha
for name,sha in r['products'].items(): files[str(authority.parent/'modules'/(name+'.swiftmodule'))]=sha
for name,sha in r['objects'].items(): files[str(authority.parent/'modules'/(name+'.o'))]=sha
col=Path(r['collectionsProductsReceipt']['path']);assert digest(col)==r['collectionsProductsReceipt']['sha256'];verify_collections_products(col);files[str(col)]=digest(col);files.update(json.loads(col.read_text()))
files[str(monitor.SWIFT_BIN/'swiftc')]=r['compilerSHA256'];files[str(monitor.SDK/'SDKSettings.json')]=r['sdkSettingsSHA256']
objects=[str(authority.parent/'modules'/(name+'.o')) for name in r['objects']]+[p for p in json.loads(col.read_text()) if p.endswith('.o')]
module_dirs=sorted({str(Path(p).parent) for p in files if p.endswith('.swiftmodule')})
flags=['-parse-as-library','-swift-version','6','-Onone','-target','arm64-apple-macosx27.0','-sdk',str(monitor.SDK),'-package-name','swift_cad','-DSWIFT_PACKAGE','-DDEBUG','-DNativeExchange']
for p in module_dirs: flags+=['-I',p]
exe=OUT/'ResolverSynchronousAdmission';command=[str(monitor.SWIFT_BIN/'swiftc')]+flags+[str(source)]+objects+['-o',str(exe)]
def verify():
 for p,sha in files.items(): assert Path(p).is_file() and digest(Path(p))==sha,p
verify();record={'status':'running','scope':'Synchronous Native public resolver exact/cache/source-refusal contract only; ordinary DocumentEvaluator preparation independently observed. Not cooperative-worker preparation or whole-query fingerprint admission proof.','sourceAuthority':{'path':str(authority),'sha256':digest(authority)},'sourceCount':len(r['sourceSHA256']),'sourceRoot':r['sourceRoot'],'inputAndProductSHA256':files,'modulesRegenerated':0,'source':{'path':str(source),'sha256':digest(source)},'commands':{'client-link':command,'runtime':[str(exe)]},'bounds':{'compileSeconds':1200,'runtimeSeconds':120,'aggregateRSSBytes':monitor.RSS_BYTES,'ownedCompilerProcesses':1},'steps':{}}
def save(): (OUT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
save();env=dict(os.environ);env.pop('TOOLCHAINS',None);env['PATH']=str(monitor.SWIFT_BIN)+':'+env.get('PATH','');env['SDKROOT']=str(monitor.SDK)
try:
 for name,cmd,limit in [('client-link',command,1200),('runtime',[str(exe)],120)]:
  verify();step=monitor.run(cmd,OUT/(name+'.log'),env,time.monotonic()+limit,limit);record['steps'][name]=step;save();assert step['exitCode']==0 and step['stopReason'] is None,name
  if name=='client-link':files[str(exe)]=digest(exe)
 expected=['PASS resolver genuine-cacheless same-caller','PASS resolver unbound-and-stale exact-refusals','PASS resolver genuine-cache same-caller'];text=(OUT/'runtime.log').read_text();assert all(x in text.splitlines() for x in expected)
 verify();record['postflightDrift']=[];record['expectedOutput']=expected;record['status']='passed';save();print('PASS',digest(OUT/'receipt.json'))
except Exception as error:
 record['status']='failed';record['failure']=str(error);record['postflightDrift']=[p for p,s in files.items() if not Path(p).is_file() or digest(Path(p))!=s];save();print('FAILED',str(error));raise SystemExit(1)
