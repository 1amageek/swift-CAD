#!/usr/bin/env python3
"""Recompile only actual Kernel22 for the three explicit-import fixes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
ORIGINAL = Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD')
sys.path.insert(0, str(ORIGINAL / 'Tests/OriginalQueryExecutionVerification'))
from native_tests import run, RSS_BYTES
ORIGINS = {'asan': '399a9413912166740dfe334d3dd39fcf4237df7e60a7564b05ef887d7a1b0bdb', 'wasm': 'ff9380e11c1f2fe1cf7392ae5c37b64c842e6c614e990d306d98ebd7904898d6', 'embedded': 'e2864fac4022142d6bb88ba50663c2796a0219307391e8e6e5b0f8233efd8703'}
CHANGES = {'Sources/CADKernel/IncrementalEvaluationGraphState.swift': ('b13a4a7289de393ea4e2543e150b22e4b1ed06b9037e11c4b819744dace80636', '2bda61623fefc665377ad79164c0773978c98677314a70e7a11844005c5b47bf'), 'Sources/CADKernel/DictionaryDelta.swift': ('3176f04886e7882636b0cefc13a772aee6da6c32f968401e2ed5a75f3e5574fb', '218839f380aefa527d9793458feb3aaa9b9a91197e7d25589f33b7e25a263292'), 'Sources/CADKernel/GeometricMeasurement/MassPropertyEvaluator.swift': ('4002b7620e698359ea89b2126f43857c1bb2eab837a571e8d47e711316818765', 'ea531e6590302f2e1e3c9fb0fb344d8f25b2cdee04eb6a13737449642cb8ad6a')}


def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def verify(files):
    for path, sha in files.items():
        require(digest(path) == sha, 'Pinned source, tool, SDK or product changed: ' + path)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', choices=['asan', 'wasm', 'embedded'], required=True)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--resume-plan', action='store_true')
    args = parser.parse_args()
    output = BASE / args.lane
    receipt_path = output / 'receipt.json'
    record = None
    try:
        if args.resume_plan:
            record = json.loads(receipt_path.read_text())
            require(record['status'] == 'prepared' and record['lane'] == args.lane, 'Only exact unexecuted plans may resume.')
        else:
            output.mkdir(parents=True, exist_ok=False)
            origin_path = BASE.parent / 'portable-final-r3' / args.lane / 'receipt.json'
            require(digest(origin_path) == ORIGINS[args.lane], 'Original actual lane receipt changed.')
            origin = json.loads(origin_path.read_text())
            full_path = Path(origin['acceptedCompileOrigin']['path']) if args.lane == 'asan' else origin_path
            full = json.loads(full_path.read_text())
            if args.lane == 'asan':
                require(digest(full_path) == origin['acceptedCompileOrigin']['sha256'], 'Successful ASAN compiler origin changed.')
            require(all(full['steps'][module]['exitCode'] == 0 and full['steps'][module].get('stopReason') is None and full['steps'][module]['command'] == full['commands'][module] for module in ['CADTopology', 'CADIR', 'CADModeling']), 'Actual successful lower/Modeling phases missing.')
            if args.lane == 'embedded':
                proof_path = origin_path.parent / 'failure-postflight.json'
                require(digest(proof_path) == '35bde1708cd0997f43bc1fc154da626809373067d473eb81f7c2596f753b4e5a', 'Embedded actual successful phase postflight changed.')
                require(origin['status'] == 'failed' and origin['steps']['CADKernel']['exitCode'] != 0, 'Expected prior Kernel import diagnostic missing.')
            else:
                require(origin['status'] == 'passed' and origin['sourcesProductsAndLogsUnchanged'], 'Actual final five-check lane origin was not accepted.')
            files = dict(origin['inputAndProductSHA256'])
            files[str(origin_path)] = digest(origin_path)
            files[str(full_path)] = digest(full_path)
            if args.lane == 'embedded':
                files[str(proof_path)] = digest(proof_path)
            comparison_path = BASE.parent / 'direct-import-finding-r1/comparison.json'
            require(digest(comparison_path) == '39213ef7b04f72547e09d3d402197c73f78dfbc5b4f77dd5542c2475d867ea0e', 'Root import-only inverse comparison changed.')
            comparison = json.loads(comparison_path.read_text())
            require(comparison['onlyImports'] and {row['path']: (row['beforeSHA256'], row['afterSHA256']) for row in comparison['rows']} == CHANGES and all(row['inverseByteEqual'] for row in comparison['rows']), 'Approved import-only source delta differs.')
            files[str(comparison_path)] = digest(comparison_path)
            for relative, (before, after) in CHANGES.items():
                path = str(SOURCE / relative)
                require(files[path] == before, 'Original Kernel source origin differs: ' + relative)
                require(digest(path) == after, 'Released current import source differs: ' + relative)
                files[path] = after
            fixture = SOURCE / 'Tests/CADKernelTests/MassPropertyDirectAdmissionChecks.swift'
            require(files[str(fixture)] == digest(fixture) == '7f98e796023a1608bb5f3c5010a5f121d8d82f980f89a3c9c7669f21e9b5e6a7', 'Final F4 fixture differs.')
            files[str(Path(__file__))] = digest(Path(__file__))
            require(RSS_BYTES == 10 * 1024**3, 'Canonical monitor bound differs.')
            verify(files)
            sources = {p: h for p, h in full['sourceSHA256'].items() if p.startswith('Sources/CADKernel/')}
            require(len(sources) == 22 and set(CHANGES).issubset(sources), 'Actual Kernel whole-file inventory differs.')
            sources.update({p: after for p, (_, after) in CHANGES.items()})
            native_path = BASE.parent / 'native-import-final-r3/receipt.json'
            require(digest(native_path) == '7e240e44aed9806c268c623d23bcfbe293afb092ec8c59ac626e340f6c1c5075', 'Final Native import-only authority changed.')
            native = json.loads(native_path.read_text())
            require(native['steps']['CADKernel']['exitCode'] == 0 and native['steps']['CADKernel'].get('stopReason') is None, 'Final Native Kernel was not accepted.')
            files[str(native_path)] = digest(native_path)
            for relative, sha in sources.items():
                require(native['sourceSHA256'][relative] == sha, 'Final Native Kernel source differs: ' + relative)
                files[str(native_path.parent / 'snapshot' / relative)] = sha
            for relative, sha in sources.items():
                copy = output / 'snapshot' / relative
                copy.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / relative, copy)
                files[str(copy)] = sha
            modules = output / 'modules'
            modules.mkdir()
            response = output / 'CADKernelSources.rsp'
            response.write_text(''.join('"' + str(output / 'snapshot' / p) + '"\n' for p in sorted(sources)))
            files[str(response)] = digest(response)
            old_kernel = full['commands']['CADKernel']
            flags = ['-I', str(modules)] + old_kernel[1:old_kernel.index('-module-name')]
            module = modules / 'CADKernel.swiftmodule'
            obj = modules / 'CADKernel.code.o'
            command = [old_kernel[0]] + flags + ['-module-name', 'CADKernel', '-emit-module', '-emit-module-path', str(module)]
            products = [str(module)]
            if args.lane != 'embedded':
                command += ['-emit-object', '-o', str(obj)]
                products.append(str(obj))
            command += ['@' + str(response)]
            executable = output / ('MassPropertyDirectAdmission' if args.lane == 'asan' else 'MassPropertyDirectAdmission.wasm')
            link = [origin['commands']['client-link'][0], '-I', str(modules)] + origin['commands']['client-link'][1:]
            link[link.index('-o') + 1] = str(executable)
            old_objects = [v for v in link if Path(v).name == 'CADKernel.code.o']
            require(len(old_objects) == (0 if args.lane == 'embedded' else 1), 'Unexpected original Kernel link model.')
            link = [str(obj) if v in old_objects else v for v in link]
            runtime = [str(executable)] if args.lane == 'asan' else origin['commands']['runtime'][:-1] + [str(executable)]
            record = {'status': 'prepared', 'scope': 'Only actual whole Kernel22 is regenerated for three explicit imports, then the same five final Mass groups. Exact accepted Core/Geometry/Topology/IR/Modeling products retained.', 'lane': args.lane, 'sourceRoot': str(SOURCE), 'sourceCount': {'CADKernel': 22}, 'sourceSHA256': sources, 'importCorrection': {'comparison': str(comparison_path), 'sha256': digest(comparison_path), 'changes': CHANGES}, 'acceptedLowerOrigin': {'path': str(origin_path), 'sha256': digest(origin_path), 'compilerOrigin': str(full_path), 'compilerOriginSHA256': digest(full_path), 'scope': 'Successful Topology/IR/Modeling compiler phases only; Embedded original Kernel failed and never accepted runtime.' if args.lane == 'embedded' else 'Actual previously accepted lower production compiler phases and five-check lane.'}, 'inputAndProductSHA256': files, 'commands': {'CADKernel': command, 'client-link': link, 'runtime': runtime}, 'products': products, 'expectedOutputLines': origin['expectedOutputLines'], 'executable': str(executable), 'steps': {}, 'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'processTreeRSSBytes': RSS_BYTES, 'jobs': 1, 'ownedCompilers': 1}, 'lowerOrModelingModulesRegenerated': False, 'runnerSHA256': digest(Path(__file__))}
        verify(record['inputAndProductSHA256'])
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        if args.prepare_only:
            print(json.dumps({'status': 'prepared', 'receipt': str(receipt_path)}), flush=True)
            return
        record['status'] = 'running'
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['PATH'] = str(Path(record['commands']['CADKernel'][0]).parent) + ':' + environment.get('PATH', '')
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        deadline = time.monotonic() + 1200
        for stage in ['CADKernel', 'client-link', 'runtime']:
            verify(record['inputAndProductSHA256'])
            result = run(record['commands'][stage], output / (stage + '.log'), environment, deadline=(time.monotonic() + 120) if stage == 'runtime' else deadline, stage_limit=120 if stage == 'runtime' else 1200)
            record['steps'][stage] = result
            record['inputAndProductSHA256'][str(output / (stage + '.log'))] = result['logSHA256']
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
            require(result['exitCode'] == 0 and result.get('stopReason') is None, stage + ' failed.')
            if stage == 'CADKernel':
                record['compiledProductSHA256'] = {p: digest(p) for p in record['products']}
                record['inputAndProductSHA256'].update(record['compiledProductSHA256'])
            elif stage == 'client-link':
                record['executableSHA256'] = digest(record['executable'])
                record['inputAndProductSHA256'][record['executable']] = record['executableSHA256']
            else:
                lines = (output / 'runtime.log').read_text().splitlines()
                require(all(line in lines for line in record['expectedOutputLines']), 'Missing final actual Mass oracle.')
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
            print(json.dumps({'stage': stage, 'exitCode': result['exitCode'], 'elapsedSeconds': result['elapsedSeconds'], 'peakRSSBytes': result['sampledPeakProcessTreeRSSBytes']}), flush=True)
        verify(record['inputAndProductSHA256'])
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        receipt_path.write_text(json.dumps(record, indent=2) + '\n')
    except Exception as error:
        if record is not None:
            record['status'] = 'failed'
            record['failure'] = str(error)
            receipt_path.write_text(json.dumps(record, indent=2) + '\n')
        print(str(error), flush=True)
        raise SystemExit(1)


if __name__ == '__main__':
    main()
