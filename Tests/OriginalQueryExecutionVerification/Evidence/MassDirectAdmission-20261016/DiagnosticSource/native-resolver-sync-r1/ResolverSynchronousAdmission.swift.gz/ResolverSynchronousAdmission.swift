import Foundation
import CADCore
import CADGeometry
import CADIR
import CADTopology
import CADModeling
import CADKernel

@main
struct ResolverSynchronousAdmission {
    struct Failure: Error { let message: String }
    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw Failure(message: message) }
    }
    static func mark(_ text: String) {
        FileHandle.standardError.write(Data((text + "\n").utf8))
    }
    static func document() -> CADDocument {
        let id = FeatureID()
        let feature = FeatureNode(id: id, operation: .primitive(PrimitiveFeature(definition: .box(BoxPrimitive(
            width: .constant(.length(1, unit: .meter)), depth: .constant(.length(2, unit: .meter)),
            height: .constant(.length(3, unit: .meter)))))), outputs: [FeatureOutput(role: .body)])
        let products = [AssemblyProduct(name: "real part"), AssemblyProduct(name: "shared assembly")]
        let formations = products.map { AssemblyProductFormation(productID: $0.id) }
        let leaf = AssemblyDefinition(formationID: formations[0].id, features: [id])
        let middle = AssemblyDefinition(formationID: formations[1].id,
            children: [AssemblyOccurrence(name: "leaf usage", definitionID: leaf.id)])
        return CADDocument(units: .meters, designGraph: DesignGraph(nodes: [id: feature], order: [id]),
            assembly: DocumentAssembly(products: products, formations: formations, definitions: [leaf, middle], roots: [
                AssemblyOccurrence(name: "first", definitionID: middle.id),
                AssemblyOccurrence(name: "second", definitionID: middle.id,
                    placement: .translated(by: Vector3D(x: 5, y: 0, z: 0)))]))
    }
    static func main() throws {
        let source = document(), evaluator = DocumentEvaluator(tolerance: .standard)
        mark("RESOLVER_SYNC exact preparation begin")
        let exact = try evaluator.evaluateExact(source)
        mark("RESOLVER_SYNC exact preparation end")
        try require(exact.caches.brep == nil && exact.meshes.isEmpty && exact.validatedSourceReceipt != nil,
            "The exact producer did not retain a genuine cacheless source receipt.")
        var execution = try OriginalQueryExecution.independentGeometry()
        let owner = execution.budget
        try execution.consumeWork(13)
        let resolver: any ProductAttributeResolving = ProductAttributeResolver()
        let resolved = try resolver.resolve(exact, limits: .standard, using: &execution)
        try require(!resolved.values.isEmpty && execution.budget === owner && execution.activeContributionCount == 0,
            "The genuine exact-source resolution lost its values or caller owner.")
        print("PASS resolver genuine-cacheless same-caller")
        let unbound = EvaluatedDocument(document: source, parameters: exact.parameters, brep: exact.brep,
            meshes: exact.meshes, caches: exact.caches, subshapes: exact.subshapes, lineage: exact.lineage,
            configuration: exact.configuration, assembly: exact.assembly)
        do {
            _ = try resolver.resolve(unbound, limits: .standard, using: &execution)
            throw Failure(message: "Public unbound construction was accepted.")
        } catch let error as ProductAttributeError {
            try require(error == .inconsistentArtifact("Missing or stale producer source/exact B-rep association."),
                "Unbound source did not preserve its precise typed refusal.")
        }
        var changed = source
        guard let part = changed.assembly?.definitions.first(where: { !$0.features.isEmpty }) else {
            throw Failure(message: "The genuine assembly lost its feature owner.")
        }
        changed.productAttributes = ProductAttributes(assignments: [ProductAttributeAssignment(
            target: ProductAttributeTarget(kind: .part, definitionID: part.id), value: .opacity(0.5))])
        var stale = EvaluatedDocument(document: changed, parameters: exact.parameters, brep: exact.brep,
            meshes: exact.meshes, caches: exact.caches, subshapes: exact.subshapes, lineage: exact.lineage,
            configuration: exact.configuration, assembly: exact.assembly)
        stale.validatedBRep = exact.validatedBRep
        do {
            _ = try resolver.resolve(stale, limits: .standard, using: &execution)
            throw Failure(message: "Changed source was accepted through an unrelated exact B-rep.")
        } catch let error as ProductAttributeError {
            try require(error == .inconsistentArtifact("Missing or stale producer source/exact B-rep association."),
                "Stale source did not preserve its precise typed refusal.")
        }
        print("PASS resolver unbound-and-stale exact-refusals")
        mark("RESOLVER_SYNC cached preparation begin")
        let materialized = try evaluator.evaluate(source)
        mark("RESOLVER_SYNC cached preparation end")
        try require(materialized.caches.brep != nil, "The ordinary producer did not publish its actual B-rep cache.")
        let cached = try resolver.resolve(materialized, limits: .standard, using: &execution)
        try require(!cached.values.isEmpty && execution.budget === owner && execution.activeContributionCount == 0
            && execution.localWork == owner.snapshot.work && execution.localWork > 13,
            "Cached resolution lost its original caller accounting or values.")
        print("PASS resolver genuine-cache same-caller")
        print("RESOLVER_SYNC cumulativeWork=\(execution.localWork) prior=13 bytes=\(owner.snapshot.storageBytes)")
    }
}
