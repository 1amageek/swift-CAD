import Foundation
import CADCore
import CADGeometry
import CADIR
import CADTopology
@testable import CADKernel

@main
struct ResolverSynchronousAdmission {
    struct Failure: Error { let message: String }
    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw Failure(message: message) }
    }
    static func main() throws {
        let source = CADDocument(units: .meters)
        FileHandle.standardError.write(Data("RESOLVER_ZERO exact preparation begin\n".utf8))
        let exact = try DocumentEvaluator(tolerance: .standard).evaluateExact(source)
        FileHandle.standardError.write(Data("RESOLVER_ZERO exact preparation end\n".utf8))
        try require(exact.validatedSourceReceipt != nil && exact.caches.brep == nil && exact.brep.bodies.isEmpty,
            "The zero-feature producer did not publish its genuine exact source association.")
        var execution = try OriginalQueryExecution.independentGeometry()
        let owner = execution.budget
        try execution.consumeWork(13)
        let resolver: any ProductAttributeResolving = ProductAttributeResolver()
        let value = try resolver.resolve(exact, limits: .standard, using: &execution)
        try require(value.values.isEmpty && value.localGeometry.isEmpty && value.documentID == source.id
            && execution.budget === owner && execution.activeContributionCount == 0,
            "The genuine zero-feature result changed its empty semantics or caller ownership.")
        print("PASS resolver zero-feature genuine-associated same-caller")
        let unbound = EvaluatedDocument(document: source, parameters: exact.parameters, brep: exact.brep,
            meshes: exact.meshes, caches: exact.caches, subshapes: exact.subshapes, lineage: exact.lineage,
            configuration: exact.configuration, assembly: exact.assembly)
        do {
            _ = try resolver.resolve(unbound, limits: .standard, using: &execution)
            throw Failure(message: "Unbound zero-feature construction was accepted.")
        } catch let error as ProductAttributeError {
            try require(error == .inconsistentArtifact("Missing or stale producer source/exact B-rep association."),
                "Unbound source did not preserve its exact typed refusal.")
        }
        var changed = source
        changed.units = .millimeters
        var stale = EvaluatedDocument(document: changed, parameters: exact.parameters, brep: exact.brep,
            meshes: exact.meshes, caches: exact.caches, subshapes: exact.subshapes, lineage: exact.lineage,
            configuration: exact.configuration, assembly: exact.assembly)
        stale.validatedBRep = exact.validatedBRep
        do {
            _ = try resolver.resolve(stale, limits: .standard, using: &execution)
            throw Failure(message: "Changed-unit source was accepted through an unrelated exact B-rep.")
        } catch let error as ProductAttributeError {
            try require(error == .inconsistentArtifact("Missing or stale producer source/exact B-rep association."),
                "Changed-unit source did not preserve its exact typed refusal.")
        }
        try require(execution.budget === owner && execution.activeContributionCount == 0
            && execution.localWork == owner.snapshot.work && execution.localWork > 13,
            "The source refusals lost the original caller accounting.")
        print("PASS resolver zero-feature unbound-and-stale-unit exact-refusals")
        print("RESOLVER_ZERO cumulativeWork=\(execution.localWork) prior=13 bytes=\(owner.snapshot.storageBytes)")
    }
}
