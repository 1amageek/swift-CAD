#!/usr/bin/env python3
"""Compile actual Topology142/IR818 and the finite Bridge Modeling closure; run four unchanged error-classification checks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
HARNESS = Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0, str(HARNESS))
from native_tests import run, RSS_BYTES

INPUTS = {'Tests/CADModelingTests/BridgeSurfaceFailureClassificationChecks.swift': '3cf36b8a0e4e9d39ca573fcdb5a3fe6d8b1f242006204e52fc85da745023c916', 'Tests/OriginalQueryExecutionVerification/BridgeSurfaceFailureClassificationPortable.swift': '833e57da72af879acd4b361a8089f66fae9bab6ca80aa0b80603e331caa20ebd'}
EXPECTED = ['PASS actualRuledBuilderPublishesANonemptyBridge', 'PASS actualRuledBuilderWorkRefusalKeepsItsCauseAndFeatureContext', 'PASS actualRuledBuilderStorageRefusalKeepsItsCauseAndFeatureContext', 'PASS actualRuledBuilderCancellationKeepsItsCause']


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', required=True, choices=['asan', 'wasm', 'embedded'])
    args = parser.parse_args()
    output = BASE / args.lane
    output.mkdir(exist_ok=False)
    pins = {}
    record = {'status': 'preparing', 'lane': args.lane, 'scope': 'Actual full Topology142/IR818 and finite whole-file Bridge Modeling closure. Four ERROR classification oracles only; whole-feature direct accounting remains incomplete. No Kernel/Exchange port.',
              'moduleRegeneration': 1, 'coreGeometryRegeneration': 0, 'steps': {}, 'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'processTreeRSSBytes': RSS_BYTES, 'jobs': 1},
              'inputAndProductSHA256': pins, 'expectedOutputLines': EXPECTED}

    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    def pin(path, expected=None):
        path = Path(path)
        observed = digest(path)
        require(expected is None or observed == expected, 'Input/product hash differs: ' + str(path))
        require(str(path) not in pins or pins[str(path)] == observed, 'Conflicting input pin: ' + str(path))
        pins[str(path)] = observed
        return observed

    def verify():
        return [path for path, expected in pins.items() if not Path(path).is_file() or digest(path) != expected]

    try:
        geometry_receipt = ROOT / 'current-geometry' / args.lane / 'receipt.json'
        geometry = json.loads(geometry_receipt.read_text())
        selected = geometry['lanes'][args.lane]
        authority = ROOT / 'native-current-geometry-r2/receipt.json'
        pin(authority, 'e204846e7c7cab172f79257ef812847d774ffcc6c6369c86639da1a613a8d4d8')
        source_authority = json.loads(authority.read_text())
        require(geometry['status'] == 'compiled-only' and geometry['compileCore'], 'Current Core and Geometry require their actual fresh successful compiler phases.')
        require(geometry['sourceSHA256'] == source_authority['sourceSHA256'], 'Geometry source authority differs.')
        require(all(not geometry[name] for name in ['currentDrift', 'snapshotDrift', 'productDrift']), 'Geometry origin has drift.')
        record['geometryOrigin'] = {'path': str(geometry_receipt), 'sha256': pin(geometry_receipt)}
        record['sourceAuthority'] = {'path': str(authority), 'sha256': pins[str(authority)], 'scope': 'Actual successful Native current Core and Geometry source authority'}
        record['productionSourceSHA256'] = geometry['sourceSHA256']
        record['productionSourceRoot'] = str(geometry_receipt.parent / 'snapshot')
        require(geometry['sourceCount'] == {'CADCore': 67, 'CADGeometry': 2171}, 'Production input counts differ.')
        for relative, expected in geometry['sourceSHA256'].items():
            pin(geometry_receipt.parent / 'snapshot' / relative, expected)
        phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-compile')
        require(phase['exitCode'] == 0 and phase['stopReason'] is None and phase['command'] == selected['commands']['compile'], 'Geometry compiler phase is not accepted.')
        pin(phase['log'], phase['logSHA256'])
        response = Path(phase['command'][-1][1:])
        pin(response, selected['responseSHA256'])
        require(set(shlex.split(response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADGeometry/')}, 'Geometry compiler inventory differs.')
        for mapping in [selected['compiledProductSHA256'], selected['compiledCoreProductSHA256'], selected['platformArchiveSHA256']]:
            for path, expected in mapping.items():
                pin(path, expected)
        for path, item in selected['dependencies'].items():
            pin(path, item['sha256'])
            pin(item['source'], item['sha256'])
        core_phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-core-compile')
        require(core_phase['exitCode'] == 0 and core_phase['stopReason'] is None and core_phase['command'] == selected['commands']['core-compile'], 'Current Core compiler phase differs.')
        pin(core_phase['log'], core_phase['logSHA256'])
        core_response = Path(core_phase['command'][-1][1:])
        pin(core_response, selected['coreResponseSHA256'])
        require(set(shlex.split(core_response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADCore/')}, 'Current Core compiler inventory differs.')
        record['retainedCoreCompilerPhase'] = core_phase
        product_map = ROOT / 'current-geometry/products.json'
        pin(product_map, 'd09b7659aca7757e57f16805d1a1a637d5327b023d99b688a70133c5fc93b0d8')
        require(json.loads(product_map.read_text())['lanes'][args.lane]['receiptSHA256'] == pins[str(geometry_receipt)], 'Current product-map authority differs.')
        pin(HARNESS / 'native_tests.py')
        pin(Path(__file__))
        for relative, expected in geometry['toolSHA256'].items():
            pin(Path(phase['command'][0]).parent / relative, expected)
        for path, expected in geometry['wasmSDK']['metadataSHA256'].items():
            pin(Path(geometry['wasmSDK']['path']) / path, expected)
        pin(Path(geometry['nativeSDK']['path']) / 'SDKSettings.json', geometry['nativeSDK']['SDKSettings.json'])
        pin(geometry['nativeLinker']['path'], geometry['nativeLinker']['sha256'])
        native_path = ROOT / 'native-full-r14/receipt.json'
        pin(native_path, 'bed585f663ab6a9a04ef0d9e7055b2409f486d9bde91fa54ebe3b7b3cb69d3c3')
        native = json.loads(native_path.read_text())
        for name in ['CADTopology', 'CADIR', 'CADModeling']:
            require(native['steps'][name]['exitCode'] == 0 and native['steps'][name]['stopReason'] is None, 'Native source authority failed: ' + name)
        require({p:h for p,h in native['sourceSHA256'].items() if p.startswith(('Sources/CADCore/', 'Sources/CADGeometry/'))} == geometry['sourceSHA256'], 'Native/lower source subset differs.')
        model_plan = BASE / 'candidate-model-paths.json'
        pin(model_plan)
        model_paths = json.loads(model_plan.read_text())
        inventories = {
            'CADTopology': {p:h for p,h in native['sourceSHA256'].items() if p.startswith('Sources/CADTopology/')},
            'CADIR': {p:h for p,h in native['sourceSHA256'].items() if p.startswith('Sources/CADIR/')},
            'CADModeling': {p:native['sourceSHA256'][p] for p in model_paths},
        }
        require(len(inventories['CADTopology']) == 142 and len(inventories['CADIR']) == 818, 'Full module inventory differs.')
        require(inventories['CADTopology']['Sources/CADTopology/BoundedRepair/BRepEdgeGeometryClassifier.swift'] == '8c48964048fc5de0977ef10e13df6e08de188efc3a7af09be79799071044adf4', 'Classifier source differs.')
        require(inventories['CADModeling']['Sources/CADModeling/BridgeSurface/BridgeSurfaceFeatureEvaluator.swift'] == '7fef7bdb89033f4f4086663bcbe5974a3393faa5b4298052a07cceaa7567666d', 'Bridge source differs.')
        bridge_path = 'Sources/CADModeling/BridgeSurface/BridgeSurfaceFeatureEvaluator.swift'
        keypath_freeze_path = ROOT / 'bridge-keypath-binding-source-r1/source-freeze.json'
        pin(keypath_freeze_path, '31fc60f3b88301f8eef644e3a33073b6f5e3332d3a204c5564f388ada8dc97ec')
        keypath_freeze = json.loads(keypath_freeze_path.read_text())
        require(inventories['CADModeling'][bridge_path] == keypath_freeze['sourceBeforeSHA256'], 'Native14 metadata baseline differs.')
        current_bridge = (SOURCE / bridge_path).read_bytes()
        require(hashlib.sha256(current_bridge).hexdigest() == keypath_freeze['sourceAfterSHA256'], 'Current getter finding source differs.')
        require(current_bridge.count(b'feature.outputs.map { $0.role }') == 1, 'Exactly the reported getter replacement is required.')
        before_getter = current_bridge.replace(b'feature.outputs.map { $0.role }', b'feature.outputs.map(\\.role)', 1)
        require(hashlib.sha256(before_getter).hexdigest() == keypath_freeze['sourceBeforeSHA256'], 'Getter inverse changed original body.')
        inventories['CADModeling'][bridge_path] = keypath_freeze['sourceAfterSHA256']
        record['nativeSourceAuthority'] = {'path': str(native_path), 'sha256': pins[str(native_path)], 'scope': 'Native14 source baseline only; the one Bridge stored getter differs under the separate exact inverse proof. No new Native success claimed.'}
        record['getterOnlySourceDelta'] = {'freeze': str(keypath_freeze_path), 'sha256': pins[str(keypath_freeze_path)], 'source': bridge_path, 'beforeSHA256': keypath_freeze['sourceBeforeSHA256'], 'afterSHA256': keypath_freeze['sourceAfterSHA256'], 'wholeFileExactInverse': True}
        modules = output / 'modules'
        modules.mkdir()
        prefix = selected['commands']['compile'][:selected['commands']['compile'].index('-module-name')]
        freeze_path = ROOT / 'bridge-import-binding-source-r1/source-freeze.json'
        pin(freeze_path, 'de8a20453872467548154231c24e7d1d4bfc803ea97b92a81586db6ada9a1755')
        freeze = json.loads(freeze_path.read_text())
        changed = {p: item for p, item in freeze['files'].items() if p.endswith('.swift')}
        require(len(changed) == 2, 'Only the two actual import findings may change.')
        previous_path = ROOT / ('bridge-portable-r3' if args.lane == 'embedded' else 'bridge-portable-r2') / args.lane / 'receipt.json'
        expected_previous = {'asan': 'aa3d12c232c3226ac46bd9c39e41163983996e5bbefc1dafa5c85ab9fdbb1a4f', 'wasm': '5c3b0c0c9c8476a3bda604377de7b51d33362e63b404b977e0ef2fffdd40a037', 'embedded': 'ff22d4a7a97d05b718eac40d7daa18c7fa140eee425fd606497bdc59df67ecc6'}
        pin(previous_path, expected_previous[args.lane])
        previous = json.loads(previous_path.read_text())
        require(not previous['postflightDrift'], 'Prior attempt had drift.')
        require(previous['status'] == ('failed' if args.lane == 'embedded' else 'passed'), 'Prior behavioral/diagnostic scope differs.')
        if args.lane == 'embedded':
            require(previous['failure'].startswith('CADModeling failed'), 'Expected the actual getter compiler stop.')
        prior_model = {p:h for p,h in previous['productionSourceSHA256'].items() if p.startswith('Sources/CADModeling/')}
        require(set(prior_model) == set(inventories['CADModeling']), 'The actual whole-file Modeling closure changed.')
        actual_changed = {p for p,h in prior_model.items() if inventories['CADModeling'][p] != h}
        require(actual_changed == ({bridge_path} if args.lane == 'embedded' else set(changed)), 'Source delta escaped the finding scope.')
        retired_live = {}
        for path, expected in previous['inputAndProductSHA256'].items():
            relative = str(Path(path).relative_to(SOURCE)) if Path(path).is_relative_to(SOURCE) else None
            if relative in actual_changed:
                require(expected == prior_model[relative], 'Original live source premise differs.')
                retired_live[path] = expected
            else:
                pin(path, expected)
        require(len(retired_live) == len(actual_changed), 'Exactly the changed live-source bindings must be replaced explicitly.')
        for relative, item in changed.items():
            current = (SOURCE / relative).read_bytes()
            expected_imported = before_getter if relative == bridge_path else current
            require(hashlib.sha256(expected_imported).hexdigest() == item['afterSHA256'], 'Direct-import finding source differs.')
            require(expected_imported.count(b'import HashTreeCollections\n') == 1, 'Exactly one direct import required.')
            inverse = expected_imported.replace(b'import HashTreeCollections\n', b'', 1)
            require(hashlib.sha256(inverse).hexdigest() == item['beforeSHA256'], 'Import inverse changed original body.')
        record['sourceCompatibility'] = {'importFreeze': str(freeze_path), 'sha256': pins[str(freeze_path)], 'priorReceipt': str(previous_path), 'priorSHA256': pins[str(previous_path)], 'retiredLiveSourcePins': retired_live, 'changedSources': sorted(actual_changed), 'wholeBodyInverseVerified': True, 'oldReceiptsUnmodified': True}
        origin_path = ROOT / ('bridge-portable-r1' if args.lane == 'asan' else 'bridge-portable-r2') / args.lane / 'receipt.json'
        expected_origins = {'asan':'5d3b8c357cd703ed4585d606027eca15ece79d0a0d3e3fc3503cfb59e135d16e', 'wasm':'5c3b0c0c9c8476a3bda604377de7b51d33362e63b404b977e0ef2fffdd40a037', 'embedded':'b68d245583a2e00933e24a435eeda5b8ffc15979880b6e91da770bcc9b0d789e'}
        pin(origin_path, expected_origins[args.lane])
        origin = json.loads(origin_path.read_text())
        for name in ['CADTopology', 'CADIR']:
            step = origin['steps'][name]
            require(step['exitCode'] == 0 and step['stopReason'] is None, 'Only actual successful compiler phases may be reused.')
            require({p:h for p,h in origin['productionSourceSHA256'].items() if p.startswith('Sources/' + name + '/')} == inventories[name], 'Reused phase source inventory differs.')
            response_path = Path(origin['commands'][name][-1][1:])
            require(set(shlex.split(response_path.read_text())) == {str(origin_path.parent / 'snapshot' / p) for p in inventories[name]}, 'Actual prior compiler response differs.')
        record['reusedCompilerOrigin'] = {'path': str(origin_path), 'sha256': pins[str(origin_path)], 'acceptedPhases': ['CADTopology', 'CADIR'], 'wholeOriginSuccessClaim': args.lane == 'wasm'}
        module_commands = {}
        emitted = {}
        for module, inventory in inventories.items():
            if origin is not None and module in ['CADTopology', 'CADIR']:
                for relative, expected in inventory.items():
                    pin(SOURCE / relative, expected)
                record['productionSourceSHA256'].update(inventory)
                emitted[module] = origin['products'][module]
                for product in emitted[module]:
                    pin(product, origin['compiledProductSHA256'][product])
                continue
            actual = {str(p.relative_to(SOURCE)) for p in (SOURCE / 'Sources' / module).rglob('*.swift')}
            if module != 'CADModeling':
                require(actual == set(inventory), 'Actual whole production inventory differs: ' + module)
            else:
                require(set(inventory) <= actual, 'Selected whole-file Modeling input missing.')
            for relative, expected in inventory.items():
                pin(SOURCE / relative, expected)
                destination = output / 'snapshot' / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / relative, destination)
                pin(destination, expected)
            record['productionSourceSHA256'].update(inventory)
            response = output / (module + 'Sources.rsp')
            response.write_text(''.join('"' + str(output / 'snapshot' / relative) + '"\n' for relative in sorted(inventory)))
            pin(response)
            target = modules / (module + '.swiftmodule')
            command = [prefix[0], '-I', str(modules)] + prefix[1:] + ['-module-name', module, '-emit-module', '-emit-module-path', str(target)]
            emitted[module] = [str(target)]
            if args.lane != 'embedded':
                object_file = modules / (module + '.code.o')
                command += ['-emit-object', '-o', str(object_file)]
                emitted[module].append(str(object_file))
            if origin is not None:
                command[1:1] = ['-I', str(Path(origin['products']['CADIR'][0]).parent)]
            command += ['@' + str(response)]
            module_commands[module] = command
        record['moduleSourceCounts'] = {name: len(paths) for name, paths in inventories.items()}
        record['products'] = emitted
        record['priorCompileLinkSeconds'] = previous['coreGeometryCompileSeconds'] + sum(step['elapsedSeconds'] for name, step in previous['steps'].items() if name != 'runtime')
        record['coreGeometryCompileSeconds'] = record['priorCompileLinkSeconds']
        record['priorRuntimeSeconds'] = previous['steps'].get('runtime', {}).get('elapsedSeconds', 0)
        copied = []
        for relative, expected in INPUTS.items():
            pin(SOURCE / relative, expected)
            destination = output / 'snapshot' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / relative, destination)
            pin(destination, expected)
            copied.append(str(destination))
        link = []
        replaced = 0
        for value in selected['commands']['link']:
            if value.endswith('/snapshot/Tests/OriginalQueryExecutionVerification/FullGeometryPortable.swift'):
                link.extend(copied)
                replaced += 1
            else:
                link.append(value)
        require(replaced == 1, 'Expected one original standalone client source in link command.')
        old_executable = selected['products'][-1]
        executable = output / ('BridgeClassification' if args.lane == 'asan' else 'BridgeClassification.wasm')
        link[link.index('-o') + 1] = str(executable)
        runtime = [str(executable) if item == old_executable else item for item in selected['commands']['runtime']]
        for item in runtime:
            if item.endswith('.mjs'):
                pin(item)
        link = [link[0], '-I', str(modules)] + link[1:]
        if origin is not None:
            link[1:1] = ['-I', str(Path(origin['products']['CADIR'][0]).parent)]
        if args.lane != 'embedded':
            position = link.index('-o')
            link[position:position] = [path for paths in emitted.values() for path in paths if path.endswith('.code.o')]
        record['commands'] = dict(module_commands, **{'client-link': link, 'runtime': runtime})
        record['executable'] = str(executable)
        record['fixtureSHA256'] = INPUTS
        record['status'] = 'running'
        save()
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['PATH'] = str(Path(prefix[0]).parent) + os.pathsep + environment.get('PATH', '')
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        deadline = time.monotonic() + max(0, 1200 - record['coreGeometryCompileSeconds'])
        for name, command in record['commands'].items():
            step = run(command, output / (name + '.log'), environment,
                       deadline=time.monotonic() + 120 if name == 'runtime' else deadline,
                       stage_limit=120 if name == 'runtime' else 1200)
            record['steps'][name] = step
            pin(output / (name + '.log'), step['logSHA256'])
            if name in emitted and step['exitCode'] == 0 and step['stopReason'] is None:
                record.setdefault('compiledProductSHA256', {}).update({path: pin(path) for path in emitted[name]})
            if name == 'client-link' and step['exitCode'] == 0:
                record['executableSHA256'] = pin(executable)
            save()
            require(step['exitCode'] == 0 and step['stopReason'] is None, name + ' failed; inspect actual log.')
        observed = [line for line in (output / 'runtime.log').read_text().splitlines() if line.startswith('PASS ')]
        require(observed == EXPECTED, 'Actual Bridge classification oracle output differs.')
        record['postflightDrift'] = verify()
        require(not record['postflightDrift'], 'Source/tool/product/log drift after runtime.')
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        save()
        print(json.dumps({'status': record['status'], 'receipt': str(output / 'receipt.json'), 'oracles': len(observed)}))
        return 0
    except Exception as error:
        record['status'] = 'failed'
        record['failure'] = str(error)
        record['postflightDrift'] = verify()
        save()
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
