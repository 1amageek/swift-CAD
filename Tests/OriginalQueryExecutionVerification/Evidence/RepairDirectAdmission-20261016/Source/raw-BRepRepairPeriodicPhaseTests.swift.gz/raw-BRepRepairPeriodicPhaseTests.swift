import CADCore
import Foundation
import Testing
@testable import CADGeometry
@testable import CADTopology

/// Bounded observations of existing intrinsic-period chart proof and its correspondence consumer.
@Suite("Periodic repair phase observation")
struct BRepRepairPeriodicPhaseTests {
    private let tolerance = ModelingTolerance.standard
    private let workLimit = 262_144

    private func execution(_ budget: OriginalQueryBudget) throws -> OriginalQueryExecution {
        .init(budget: budget,limits: try .init(maximumValueDepth: 32,
            maximumCoefficientDepth: 32,remainingSourceDepth: 16,maximumSubdivisionDepth: 32))
    }
    private func stage(_ name: String,budget: OriginalQueryBudget,
        execution: borrowing OriginalQueryExecution,detail: String = "") throws {
        let cost = budget.snapshot
        let text = "REPAIR_PERIODIC_PHASE \(name) work=\(cost.work) bytes=\(cost.storageBytes) cells=\(cost.cellVisits) valueDepth=\(execution.valueDepth) coefficientDepth=\(execution.coefficientDepth) sourceDepth=\(execution.sourceDepth) geometricDepth=\(execution.geometricDepth) \(detail)\n"
        let data = Data(text.utf8)
        FileHandle.standardError.write(data)
        // The focused runner owns a dedicated stage file for this one diagnostic.
        if let path = ProcessInfo.processInfo.environment["G01_DIAGNOSTIC_STAGE_LOG"] {
            let output = try FileHandle(forWritingTo: URL(fileURLWithPath: path))
            do { _ = try output.seekToEnd(); try output.write(contentsOf: data) }
            catch { try output.close(); throw error }
            try output.close()
        }
    }
    private func original(_ error: any Error) -> any Error {
        if let retained = error as? OriginalQueryFailure { return original(retained.originalError) }
        if case .admissionRejected(let retained)? = error as? ExactScalarFailure { return original(retained) }
        return error
    }
    private func observation(_ error: any Error) -> OriginalQueryResourceObservation? {
        if let retained = error as? OriginalQueryFailure {
            return retained.context.resource ?? observation(retained.originalError)
        }
        if case .admissionRejected(let retained)? = error as? ExactScalarFailure { return observation(retained) }
        return nil
    }
    private func recordFailure(_ error: any Error,label: String,budget: OriginalQueryBudget,
        execution: borrowing OriginalQueryExecution) throws {
        try stage("\(label).failure",budget: budget,execution: execution,
            detail: "original=\(String(reflecting: original(error))) retained=\(String(reflecting: error))")
        guard case .resourceLimit(.work)? = original(error) as? ExactScalarFailure,
            let resource = observation(error),resource.axis == .work,resource.limit == .known(workLimit) else { throw error }
        #expect(budget.snapshot.work <= workLimit)
    }
    private func unwrap(_ charts: [SurfaceParameterCurve],on host: Surface3D,period: Double) throws -> Bool {
        let budget = try OriginalQueryBudget(workLimit: workLimit)
        var admission = try execution(budget)
        try stage("unwrap.cold.begin",budget: budget,execution: admission)
        do {
            let result = try SurfaceParameterLoopUnwrapper().unwrap(charts,on: host,tolerance: tolerance,
                context: "Original periodic repair phase observation",maximumSubdivisionDepth: 32,
                remainingSourceDepth: 16,maximumAlgebraicDepth: nil,using: &admission)
            try stage("unwrap.success",budget: budget,execution: admission,
                detail: "shifts=\(result.map { [$0.uShift,$0.vShift] })")
            #expect(result.count == 4)
            if result.count == 4 {
                #expect(result[0].uShift == 0 && result[0].vShift == 0)
                for item in result.dropFirst() { #expect(item.uShift == period && item.vShift == 0) }
            }
            return true
        } catch {
            try recordFailure(error,label: "unwrap",budget: budget,execution: admission)
            return false
        }
    }
    private func bound(_ label: String,curve: Curve3D,host: Surface3D,chart: SurfaceParameterCurve) throws {
        let budget = try OriginalQueryBudget(workLimit: workLimit)
        var admission = try execution(budget)
        try stage("\(label).bound.cold.begin",budget: budget,execution: admission)
        do {
            let result = try OriginalBoundedCurveSurfaceCorrespondence.deviationBound(curve: curve,
                from: 0,to: 1,surface: host,parameterCurve: chart,
                options: .init(maximumSubdivisionDepth: 32,maximumCellCount: 1_048_576,
                    maximumDeviation: tolerance.distance * 8),tolerance: tolerance,
                maximumSpanCount: 1_048_576,maximumSubdivisionDepth: 32,remainingSourceDepth: 16,
                maximumAlgebraicDepth: 32,using: &admission)
            try stage("\(label).bound.success",budget: budget,execution: admission,detail: "bound=\(result)")
            #expect(result.isFinite && result <= tolerance.distance * 8)
        } catch { try recordFailure(error,label: "\(label).bound",budget: budget,execution: admission) }
    }

    @Test(.timeLimit(.minutes(1)))
    func intrinsicCylinderUnwrapAndRetainedSideShiftHaveSeparateColdObservations() throws {
        let period = Double.pi * 2
        let host = Surface3D.cylinder(.init(origin: .origin,axis: .unitZ,radius: 1))
        let charts: [SurfaceParameterCurve] = [
            .constantV(v: 0,uStart: period-0.25,uEnd: period+0.25),
            .constantU(u: 0.25,vStart: 0,vEnd: 1),
            .constantV(v: 1,uStart: 0.25,uEnd: -0.25),
            .constantU(u: -0.25,vStart: 1,vEnd: 0)]
        guard try unwrap(charts,on: host,period: period) else { return }
        // Exact side-one payload from the existing public periodic repair fixture.
        let side = charts[1]
        let curve = Curve3D.surfaceLift(.init(surface: host,parameterCurve: side))
        try bound("originalSide",curve: curve,host: host,chart: side)
        try bound("periodShiftedSide",curve: curve,host: host,
            chart: .periodicTranslation(base: side,uShift: period,vShift: 0))
    }
}
