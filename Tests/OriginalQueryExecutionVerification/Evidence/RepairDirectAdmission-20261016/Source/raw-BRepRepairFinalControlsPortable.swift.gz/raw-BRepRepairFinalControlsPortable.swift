import CADCore
import CADGeometry
import CADTopology
import HashTreeCollections

@main
struct BRepRepairFinalControlsPortable {
    static func main() throws {
        try BRepRepairExecutionChecks.shellSewing()
        print("PASS repair final canonical shell edge")
        try BRepRepairExecutionChecks.pruning()
        print("PASS repair final unreachable source pruning")
        try BRepRepairRollbackChecks.originalDisplacementRollbackRestoresBothCandidateAndCollapsedLedger()
        print("PASS repair final original displacement rollback")
    }
}
