import CADCore
import CADTopology
import Foundation
import Testing
@testable import CADGeometry

/// A bounded phase observation, not acceptance of complete square repair.
@Suite("Constant-UV repair correspondence phase observation")
struct BRepRepairConstantUVPhaseTests {
    private let tolerance = ModelingTolerance.standard
    private let workLimit = 262_144

    private func execution(_ budget: OriginalQueryBudget) throws -> OriginalQueryExecution {
        .init(budget: budget, limits: try .init(maximumValueDepth: 32,
            maximumCoefficientDepth: 32, remainingSourceDepth: 16,
            maximumSubdivisionDepth: 32))
    }

    private func stage(_ name: String, budget: OriginalQueryBudget,
        execution: borrowing OriginalQueryExecution, detail: String = "") throws {
        let cost = budget.snapshot
        let text = "REPAIR_UV_PHASE \(name) work=\(cost.work) bytes=\(cost.storageBytes) cells=\(cost.cellVisits) valueDepth=\(execution.valueDepth) coefficientDepth=\(execution.coefficientDepth) sourceDepth=\(execution.sourceDepth) geometricDepth=\(execution.geometricDepth) \(detail)\n"
        let data = Data(text.utf8)
        FileHandle.standardError.write(data)
        // The focused runner owns a dedicated stage file for this one diagnostic.
        if let path = ProcessInfo.processInfo.environment["G01_DIAGNOSTIC_STAGE_LOG"] {
            let output = try FileHandle(forWritingTo: URL(fileURLWithPath: path))
            do {
                _ = try output.seekToEnd()
                try output.write(contentsOf: data)
            } catch {
                try output.close()
                throw error
            }
            try output.close()
        }
    }

    private func originalFailure(_ error: any Error) -> any Error {
        if let failure = error as? OriginalQueryFailure { return originalFailure(failure.originalError) }
        if case .admissionRejected(let retained)? = error as? ExactScalarFailure {
            return originalFailure(retained)
        }
        return error
    }

    private func resourceObservation(_ error: any Error) -> OriginalQueryResourceObservation? {
        if let failure = error as? OriginalQueryFailure {
            return failure.context.resource ?? resourceObservation(failure.originalError)
        }
        if case .admissionRejected(let retained)? = error as? ExactScalarFailure {
            return resourceObservation(retained)
        }
        return nil
    }

    private func continuity(_ label: String, curve: Curve3D, surface: Surface3D,
        chart: SurfaceParameterCurve, range: ScalarInterval) throws {
        let budget = try OriginalQueryBudget(workLimit: workLimit)
        var admission = try execution(budget)
        try stage("\(label).prepare.source.begin", budget: budget, execution: admission)
        let source = try PreparedCurveDifferentialEncloser(curve: curve, tolerance: tolerance,
            remainingSourceDepth: 16, maximumSubdivisionDepth: 32,
            maximumAlgebraicDepth: 32, using: &admission)
        try stage("\(label).prepare.source.end", budget: budget, execution: admission)
        let liftedCurve = Curve3D.surfaceLift(.init(surface: surface, parameterCurve: chart))
        try stage("\(label).prepare.lift.begin", budget: budget, execution: admission)
        let lift = try PreparedCurveDifferentialEncloser(curve: liftedCurve, tolerance: tolerance,
            remainingSourceDepth: 16, maximumSubdivisionDepth: 32,
            maximumAlgebraicDepth: 32, using: &admission)
        try stage("\(label).prepare.lift.end", budget: budget, execution: admission)
        try observeContinuity("\(label).continuity.source", prepared: source, range: range,
            budget: budget, using: &admission)
        try observeContinuity("\(label).continuity.lift", prepared: lift, range: range,
            budget: budget, using: &admission)
    }

    private func observeContinuity(_ label: String, prepared: borrowing PreparedCurveDifferentialEncloser,
        range: ScalarInterval, budget: OriginalQueryBudget,
        using admission: inout OriginalQueryExecution) throws {
        try stage("\(label).begin", budget: budget, execution: admission)
        let admitted = try admission.withProofScope(maximum: ExactScalarDepth(value: 32, coefficient: 32)) { execution in
            try prepared.admittingContinuousFirstOrder(over: range, tolerance: tolerance,
                maximumSubdivisionDepth: 32, remainingSourceDepth: 16, using: &execution) != nil
        }
        try stage("\(label).end", budget: budget, execution: admission, detail: "admitted=\(admitted)")
    }

    private func actualBound(_ label: String, curve: Curve3D, surface: Surface3D,
        chart: SurfaceParameterCurve, trim: CurveTrim) throws {
        // This cold admission shares no paid preparation or query cache with the observation above.
        let budget = try OriginalQueryBudget(workLimit: workLimit)
        var admission = try execution(budget)
        let options = CurveSurfaceCorrespondenceValidationOptions(maximumSubdivisionDepth: 32,
            maximumCellCount: 1_048_576, maximumDeviation: tolerance.distance * 8)
        try stage("\(label).bound.cold.begin", budget: budget, execution: admission)
        do {
            let bound = try OriginalBoundedCurveSurfaceCorrespondence.deviationBound(curve: curve,
                from: trim.startParameter, to: trim.endParameter, surface: surface,
                parameterCurve: chart, options: options, tolerance: tolerance,
                maximumSpanCount: 1_048_576, maximumSubdivisionDepth: 32,
                remainingSourceDepth: 16, maximumAlgebraicDepth: 32, using: &admission)
            try stage("\(label).bound.success", budget: budget, execution: admission, detail: "bound=\(bound)")
            #expect(bound.isFinite && bound <= tolerance.distance * 8)
        } catch {
            try stage("\(label).bound.failure", budget: budget, execution: admission,
                detail: "original=\(String(reflecting: originalFailure(error))) retained=\(String(reflecting: error))")
            guard case .resourceLimit(.work)? = originalFailure(error) as? ExactScalarFailure,
                let observation = resourceObservation(error), observation.axis == .work,
                observation.limit == .known(workLimit) else { throw error }
            #expect(budget.snapshot.work <= workLimit)
        }
    }

    @Test(.timeLimit(.minutes(1)))
    func constantVAndPolylineObserveTheSameBottomSourceWithColdBounds() throws {
        // Exact bottom-edge payloads of square() and polylineSquare(); the 3D source and trim are identical.
        let curve = Curve3D.line(.init(origin: .origin, direction: .unitX))
        let surface = Surface3D.plane(.init(origin: .origin, normal: .unitZ, uDirection: .unitX))
        let trim = CurveTrim(startParameter: 0, endParameter: 1)
        let range = try ScalarInterval(lower: trim.startParameter, upper: trim.endParameter)
        let charts: [(String,SurfaceParameterCurve)] = [
            ("constantV", .constantV(v: 0,uStart: 0,uEnd: 1)),
            ("polyline", .polyline([.init(u: 0,v: 0), .init(u: 1,v: 0)]))]
        for (label,chart) in charts {
            try continuity(label, curve: curve, surface: surface, chart: chart, range: range)
            try actualBound(label, curve: curve, surface: surface, chart: chart, trim: trim)
        }
    }
}
