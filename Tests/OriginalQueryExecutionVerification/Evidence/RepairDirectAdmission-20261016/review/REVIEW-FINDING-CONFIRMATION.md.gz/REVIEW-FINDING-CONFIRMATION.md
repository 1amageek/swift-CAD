# U1.NUMERIC.REPAIR finding-only confirmation

Status: **source confirmation passed; final runtime pending**. This is the one targeted confirmation of the prior review's observed acceptance failures. It is not another comprehensive review. No production, fixture or PROGRESS edits, compilation or test execution were performed.

## Confirmed fixes

| Prior concrete stop | Finding-only confirmation |
|---|---|
| R1: three short line trim inputs fail the existing minimum span contract | Short physical segments are now genuine unit-clamped degree-one Native curves with original endpoint controls/weights1 and trim[0,1]. No CurveTrim guard, tolerance or allowance changed. Explicit trim/open-kind checks precede the actual action. The cumulative case now participates in a real face-owned loop. Real rollback still requires exactly one rollback diagnostic, identical accepted sew candidate, removed rejected change rows, subsequent prune, preserved original model, and greater retained charges than the no-collapse control. |
| Measured work differs by one across square fresh-query sorts | Exact N/N-1 uses a genuine three-edge triangle and the same positive ownership-deduplication action. All caller-prefix, exact work/storage equality, independent axes and strict per-resource N-1 failures remain; no cap or expected-error relaxation. The previous square positive action remains in other behavioral checks. This narrows the input premise to the documented constant-comparison-count sort, rather than asserting deterministic work for arbitrary fresh dictionary order. |
| Opposite directed-use control requires whole seam equality | New seam reader accepts only exactly two points after existing source validation; the sole nonzero segment has the same exact length and total length, hence a globally affine normalized law. Original rational endpoints/direction/transport are compared and the existing exact support-period theorem remains authoritative. Equal zero displacement remains false. Multi-segment/nonlinear law handling is unchanged. The original control continues to require unchanged distinct use, no repair change, invalid after-report and explicit diagnostics. |
| Period-translated cylinder chart exhausted bounded residual work | Bounded facade still validates the complete spatial curve, support and pcurve before structural inspection. Each peeled outer periodicTranslation was therefore proved by OriginalSurfacePeriodShift on the same source, depth and A. Only original hosted full directed[0,1] support/base-law equality publishes zero; foreign base continues to the existing residual proof. Returned UV source expression/owner is unchanged. Wrapper visits, structural scans and terminal checkpoints are paid. |
| Polyline analytic signed volume lacked a selected local algebra policy | Exactly one existing analytic pcurve-loop unwrap call now selects32, with source16/subdivision32 retained. The lower nil guard is unchanged. Effective value/coefficient limits still intersect independently; actual solid-repair zero/zero caller control is added without widening axes. No volume formula or alternate repair-volume solver was introduced. |

The new periodic shared checks require raw/positive/negative/nested period whole-use exact zero, unchanged source values, invalid half-period refusal, foreign base reaching unresolved residual work, source-depth refusal, exact entry/final cancellation debit boundaries and retained-source lifetime. Portable main invokes the same shared checks as Native. These are behavioral obligations; their presence is not runtime success.

All five previously inspected principal bodies (outer repairer, engine, audit, edge length, prepared continuity) match the hashes in REVIEW-DRAFT.md exactly. The new production delta is confined to the three causal source files below. No new shared state, Mutex/Sendable branch, unchecked receipt, retry or budget owner is added.

## Final behavioral evidence

Pending final Native r4 and ASAN/normal-WASM/Embedded owner receipts. Prior r3 seven failures remain historical failed diagnostics, not accepted evidence. This confirmation does not infer full-family continuity/inverse coverage, raw Mass validation completion or whole U1 completion.

## Confirmed input hashes

| Path | SHA-256 |
|---|---|
| `Sources/CADGeometry/OriginalCurveSurfaceCorrespondence/OriginalBoundedCurveSurfaceCorrespondence.swift` | `9bc26db8901430132a36cc60367a9525e143077495d10d0786f402a4ea52d36f` |
| `Sources/CADTopology/OriginalSourceValidation/OriginalPeriodicSeamProof.swift` | `459b4bf0765dd697c2732a3911d1c29bcba8139be0544ee06fdc43d02feea0ba` |
| `Sources/CADTopology/TrimmedAnalyticSurfaceVolumeEvaluator.swift` | `9da705be85d77786c05ac48e4c6862a40ba072fbdfa23639c7dda806c884b747` |
| `Tests/CADTopologyTests/BRepRepairExecutionChecks.swift` | `db06d49f6ab2954701ad88228a928607006356fbe141a4a7811e40ced6a93f4d` |
| `Tests/CADTopologyTests/BRepRepairRollbackChecks.swift` | `29ba1c49afeb3479d26ad704dc438f39ca66069631d772d568c7b21a02e38201` |
| `Tests/CADTopologyTests/BRepRepairExecutionFixture.swift` | `f0aeb3c3149ba09f4484c382743c32543bee2503f30b441112cc66ff5ead4c11` |
| `Tests/CADTopologyTests/sharedPeriodicRepairCorrespondenceChecks.swift` | `62487555a71d32bb15aa2f5cfd0b9df4c0ee635d08ec48d0eba7587808e0bc87` |
