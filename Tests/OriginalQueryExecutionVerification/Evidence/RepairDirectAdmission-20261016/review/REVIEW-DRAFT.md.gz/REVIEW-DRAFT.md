# U1.NUMERIC.REPAIR scoped review draft

Status: source review completed; complete acceptance remains **pending / not green** because the actual current Native action run has seven failures and the final portable clients have not yet been accepted. No production source, fixture, PROGRESS, compiler or runtime was changed or launched by this reviewer.

## Fixed scope

Candidate HEAD `c968` composition: 13 public repair actions; request admission; before/after injected direct validator witnesses; action engine; original-source displacement/entity audit; rollback; edge-length direct witness; closed endpoint algebra selection; only constant-U/V extension of the existing bare-plane affine positional-continuity capability. This does not complete raw Mass validation, unsupported inverse charts, all general continuity families or whole U1.

```text
Caller A -> request -> before report (same-budget local Topology scope)
         -> ordered action -> candidate + collapsed-source ledger
         -> task-original audit -> accept / restore both staged values
         -> after report -> unresolved diagnostics -> final checkpoint -> result
```

## Finding R1: invalid short-line fixture prevents real collapse / rollback evidence

The new `smallEdge` input in `BRepRepairExecutionChecks.swift` authors a unit-direction line with trim `[0, tolerance.distance / 4]`. `cumulativeCollapseAndAbortRetainTheTaskOriginalSource` uses line spans `0.6 * tolerance.distance`; `BRepRepairRollbackChecks` uses a line span `0.75 * tolerance.distance`. Existing `CurveTrim.validate` (line arm, lines 87–90) rejects these parameter spans because a line requires `abs(end-start) > tolerance.distance`. Actual Native `native-final-actions-r3` reports `.invalidTrim` for all three routes before the claimed collapse/audit/rollback obligations can complete.

This is a concrete fixture-contract finding, not evidence to weaken `CurveTrim`, swallow the error or change the physical allowance. Author a legitimate tiny physical curve with a legal normalized parameter interval and preserve the independent displacement/whole-image/source-ledger oracles. The real rollback acceptance must still observe exactly the rejected collapse action, the restored sew candidate/ledger, successful later prune, unchanged task-original source, and retained charges.

## Source review conclusions

No additional production contract-breaking counterexample was identified in the fixed changed bodies. The following conclusions are source-local and are not substitutes for the pending actual action and target behavior:

| Contract | Source inspection |
|---|---|
| Ordinary/direct composition | Ordinary public repair and edge length each create one independent Geometry root and delegate to the same direct body. Non-generic protocol requirements carry the actual existential calls. No child root exists in direct action bodies. Removed collapsed/duplicate helper convenience entries do not leave duplicate active repair bodies. |
| Phase policies | Before/after reports and the two existing Topology helpers share the retained 32/32, source16, subdivision32 contribution on the same budget. Classifier scalar proof scopes preserve their old ambient32; arc options retain subdivision48 and nil local algebra selection. Caller effective scalar/source/subdivision limits remain independent intersections. |
| Request and order | All 13 action-to-scope predicates match their existing required-scope sets. Duplicate/empty actions and missing scopes remain typed invalid input. Existing action dependency order is fixed independently of request array order. |
| Reconstruction | Retained hosting source and complete directed incident correspondence remain authority. A missing inverse producer remains an explicit diagnostic; no point residual or proximity creates hosting identity. Closed station audit uses the existing singleton-capable prepared position bounds with explicit local algebra32 and unchanged caller axes. |
| Failure | `OriginalTopologyValidationFinding.classify` permits only established invalid-input/topology findings to become diagnostics; resource, cancellation, unsupported proof and unknown original causes rethrow. Candidate/result publication occurs only after after-report and terminal checkpoint. |
| Rollback | Candidate and collapsed-curve ledger snapshots restore together; rejected change suffix is removed; no work/storage refund exists. Every later action audits the retained task-original collapsed source. |
| Storage/lifetime | New variable traversals and collection outputs use the existing checked storage/work helpers; explicit COW charges precede coedge/ledger mutations. Result retains the real immutable model values. No unsafe view, borrowed-owner escape, new state or target-specific synchronization was added. |
| Geometry continuity | New capability is limited to validated `.callerLift` over bare stored plane with finite distinct constant-U/V endpoints on normalized domains, with source-depth admission and final checkpoint. It certifies C0 positional continuity only; whole correspondence still owns displacement proof. Other storage families/corner controls retain their previous path. |
| Shared state | Production changed types remain value/immutable owners. Existing budget/contribution state remains the same `Synchronization.Mutex` owner on all targets. New test trace/checkpoint classes retain unconditional Mutex and Sendable contracts. |

## Current behavioral evidence boundary

`native-final-constant-uv-r3/receipt.json` is passed: the genuine ordinary missing-spatial-curve constant-UV plane chart now completes (runtime 0.697344s). `native-final-actions-r3/receipt.json` is failed: 27 functions, seven issues; production/test/product drift arrays are all empty. Its log SHA is `6b0cd0d63a448bcba1c324b77c0d8c4094d996db979a6a1af9311e8d80fe960f`.

| Actual unresolved acceptance | Observed stop; no unproved causal conclusion |
|---|---|
| small-edge / cumulative collapse / real rollback | Three invalid short-line trim fixtures described in R1 |
| solid orientation | Original Euclidean polyline bounds require explicit local algebra admission; current actual 13-action evidence is not complete |
| opposite directed-use control | Retained whole chart-law seam equality is unsupported; explicit failure is preserved, but current fixture expects a returned unresolved result |
| exact N repeat | Fresh query at measured work15223 requests one additional work unit; cannot claim exact repeat boundary or a meter defect without the owner's cause observation |
| periodic restoration | Work reaches original 8,388,608 cap and requests1; no coverage success may be claimed from this stop |

Final Native and ASAN/normal-WASM/Embedded receipts must be appended here when supplied by the owners. The shared portable main invokes the actual same action, edge-length, rollback and affine-lift checks (23 printed groups); module compilation alone does not discharge these obligations. Review does not authorize cap increases, unsupported-to-success conversion, weakened old oracles or replay of an unchanged failure.

## Inspected fixed-source hashes

| Path | SHA-256 |
|---|---|
| `Sources/CADTopology/DefaultBRepRepairer.swift` | `2d2c4c5ec8e610c4fea408794703133a620516930632557d304b836c370a658d` |
| `Sources/CADTopology/BoundedRepair/BoundedBRepRepairEngine.swift` | `0e8999e9a095dbad35066fab4c5d1b6da7724666af5b71131de244d3af2a0d74` |
| `Sources/CADTopology/BoundedRepair/BRepRepairAudit.swift` | `7b068be170fab0bb86e5c28b11de80d4148ff7faafcad3ef9f0f81a3f6a35c55` |
| `Sources/CADTopology/DefaultBRepEdgeLengthEvaluator.swift` | `15266e272b9a4f3b48e861b85edfe5146ad476660a3460ab70a504f8dd4a9d61` |
| `Sources/CADGeometry/PreparedCurveDifferentialEncloser.swift` | `0840fc03668bb9235f3d712f97fb52030a4f2aa31a28ad892eb4ac2bce0940fd` |
| `Tests/CADTopologyTests/BRepRepairExecutionChecks.swift` | `206152b5d3a215607a566e25fd04bad1e20b14b178d062575e9438aa0ca4f659` |
| `Tests/CADTopologyTests/BRepRepairRollbackChecks.swift` | `96fd5737eb763a78b8ac48665f80ff6cc6411e903f1c4503be417b67b66e4371` |
| `Tests/CADTopologyTests/sharedBRepRepairAffineLiftChecks.swift` | `a3113ab296aa42c72250d7bf06666f0933124151dd7dfe2062a2c9c1f28fc1c3` |
