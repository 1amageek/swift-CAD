#!/usr/bin/env python3
"""Compile the actual Topology142 on exact retained Core/Geometry, then run four frozen volume caller checks."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/u1-parameter-table-20261017/swift-CAD')
HARNESS = Path('/Users/1amageek/Desktop/3D/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0, str(HARNESS))
from native_tests import run, RSS_BYTES

INPUTS = {'Tests/CADTopologyTests/VolumeMomentLoopAdmissionTests.swift': '88e32377739550032c63d740f799579542d1828ac45a185bfc10188b7e81d022', 'Tests/CADTopologyTests/VolumeCallerAdmissionChecks.swift': '5b898f1bab2a3523513defb72304988130ea6b4c94fcb1115c2b1e48ce17f3de', 'Tests/OriginalQueryExecutionVerification/VolumeCallerAdmissionPortable.swift': '25f0848d1fe76ffd0a9dc914dd6f3b6c156e6cb2e32679f902d8f70808d4a2b3'}
EXPECTED = ['PASS publicVolumesRetainTheirValuesAndMandatoryLowerCost', 'PASS exactCumulativeWorkAndStorageRefuseShortBudgets', 'PASS entryInProgressAndLastCheckpointCancellationPropagate', 'PASS missingReferencesAndSourceLifetimeRemainExplicit']


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', required=True, choices=['asan', 'wasm', 'embedded'])
    parser.add_argument('--reuse-topology-receipt', type=Path)
    args = parser.parse_args()
    output = BASE / args.lane
    output.mkdir(exist_ok=False)
    pins = {}
    record = {'status': 'preparing', 'lane': args.lane, 'scope': 'Actual Topology142 public volume same-owner numerical/resource/cancellation/lifetime four groups; no upper target or whole-NUMERIC acceptance.',
              'moduleRegeneration': 1, 'coreGeometryRegeneration': 0, 'steps': {}, 'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'processTreeRSSBytes': RSS_BYTES, 'jobs': 1},
              'inputAndProductSHA256': pins, 'expectedOutputLines': EXPECTED}

    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    def pin(path, expected=None):
        path = Path(path)
        observed = digest(path)
        require(expected is None or observed == expected, 'Input/product hash differs: ' + str(path))
        require(str(path) not in pins or pins[str(path)] == observed, 'Conflicting input pin: ' + str(path))
        pins[str(path)] = observed
        return observed

    def verify():
        return [path for path, expected in pins.items() if not Path(path).is_file() or digest(path) != expected]

    try:
        geometry_receipt = ROOT / 'current-geometry' / args.lane / 'receipt.json'
        geometry = json.loads(geometry_receipt.read_text())
        selected = geometry['lanes'][args.lane]
        authority = ROOT / 'native-current-geometry-r2/receipt.json'
        pin(authority, 'e204846e7c7cab172f79257ef812847d774ffcc6c6369c86639da1a613a8d4d8')
        source_authority = json.loads(authority.read_text())
        require(geometry['status'] == 'compiled-only' and geometry['compileCore'], 'Current Core and Geometry require their actual fresh successful compiler phases.')
        require(geometry['sourceSHA256'] == source_authority['sourceSHA256'], 'Geometry source authority differs.')
        require(all(not geometry[name] for name in ['currentDrift', 'snapshotDrift', 'productDrift']), 'Geometry origin has drift.')
        record['geometryOrigin'] = {'path': str(geometry_receipt), 'sha256': pin(geometry_receipt)}
        record['sourceAuthority'] = {'path': str(authority), 'sha256': pins[str(authority)], 'scope': 'Actual successful Native current Core and Geometry source authority'}
        record['productionSourceSHA256'] = geometry['sourceSHA256']
        record['productionSourceRoot'] = str(geometry_receipt.parent / 'snapshot')
        require(geometry['sourceCount'] == {'CADCore': 67, 'CADGeometry': 2171}, 'Production input counts differ.')
        for relative, expected in geometry['sourceSHA256'].items():
            pin(geometry_receipt.parent / 'snapshot' / relative, expected)
        phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-compile')
        require(phase['exitCode'] == 0 and phase['stopReason'] is None and phase['command'] == selected['commands']['compile'], 'Geometry compiler phase is not accepted.')
        pin(phase['log'], phase['logSHA256'])
        response = Path(phase['command'][-1][1:])
        pin(response, selected['responseSHA256'])
        require(set(shlex.split(response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADGeometry/')}, 'Geometry compiler inventory differs.')
        for mapping in [selected['compiledProductSHA256'], selected['compiledCoreProductSHA256'], selected['platformArchiveSHA256']]:
            for path, expected in mapping.items():
                pin(path, expected)
        for path, item in selected['dependencies'].items():
            pin(path, item['sha256'])
            pin(item['source'], item['sha256'])
        core_phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-core-compile')
        require(core_phase['exitCode'] == 0 and core_phase['stopReason'] is None and core_phase['command'] == selected['commands']['core-compile'], 'Current Core compiler phase differs.')
        pin(core_phase['log'], core_phase['logSHA256'])
        core_response = Path(core_phase['command'][-1][1:])
        pin(core_response, selected['coreResponseSHA256'])
        require(set(shlex.split(core_response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADCore/')}, 'Current Core compiler inventory differs.')
        record['retainedCoreCompilerPhase'] = core_phase
        product_map = ROOT / 'current-geometry/products.json'
        pin(product_map, 'd09b7659aca7757e57f16805d1a1a637d5327b023d99b688a70133c5fc93b0d8')
        require(json.loads(product_map.read_text())['lanes'][args.lane]['receiptSHA256'] == pins[str(geometry_receipt)], 'Current product-map authority differs.')
        pin(HARNESS / 'native_tests.py')
        pin(Path(__file__))
        for relative, expected in geometry['toolSHA256'].items():
            pin(Path(phase['command'][0]).parent / relative, expected)
        for path, expected in geometry['wasmSDK']['metadataSHA256'].items():
            pin(Path(geometry['wasmSDK']['path']) / path, expected)
        pin(Path(geometry['nativeSDK']['path']) / 'SDKSettings.json', geometry['nativeSDK']['SDKSettings.json'])
        pin(geometry['nativeLinker']['path'], geometry['nativeLinker']['sha256'])
        native_topology = ROOT / 'volume-caller-native-green-r1/receipt.json'
        pin(native_topology, 'cd44ab3641d5b687d75833590176fc7266d33e1067bc7ea69a9229041aac849d')
        native = json.loads(native_topology.read_text())
        require(native['steps']['CADTopology']['exitCode'] == 0 and native['steps']['CADTopology']['stopReason'] is None, 'Native Topology source authority is not accepted.')
        require({p: h for p, h in native['sourceSHA256'].items() if p.startswith(('Sources/CADCore/', 'Sources/CADGeometry/'))} == geometry['sourceSHA256'], 'Native lower source authority differs.')
        for relative, expected in geometry['sourceSHA256'].items():
            pin(SOURCE / relative, expected)
            pin(Path('/Users/1amageek/Desktop/3D/swift-CAD') / relative, expected)
            pin(native_topology.parent / 'snapshot' / relative, expected)
        inventories = {'CADTopology': {p: h for p, h in native['sourceSHA256'].items() if p.startswith('Sources/CADTopology/')}}
        require(len(inventories['CADTopology']) == 142, 'Actual module inventory count differs.')
        compile_flags = selected['commands']['compile']
        require(compile_flags[0] == '/Users/1amageek/Library/Developer/Toolchains/swift-6.4.0-RELEASE.xctoolchain/usr/bin/swiftc', 'Fixed compiler differs.')
        require('-Onone' in compile_flags and '-whole-module-optimization' in compile_flags, 'Debug WMO flags differ.')
        require(compile_flags[compile_flags.index('-target') + 1] == ('arm64-apple-macos27.0' if args.lane == 'asan' else 'wasm32-unknown-wasip1'), 'Target differs.')
        require(('Embedded' in compile_flags) == (args.lane == 'embedded'), 'Embedded lowering mode differs.')
        if args.lane == 'asan': require('-sanitize=address' in compile_flags, 'ASAN instrumentation is absent.')
        modules = output / 'modules'
        modules.mkdir()
        prefix = selected['commands']['compile'][:selected['commands']['compile'].index('-module-name')]
        module_commands = {}
        emitted = {}
        for module, inventory in inventories.items():
            actual = {str(p.relative_to(SOURCE)) for p in (SOURCE / 'Sources' / module).rglob('*.swift')}
            require(actual == set(inventory), 'Actual whole production inventory differs: ' + module)
            for relative, expected in inventory.items():
                pin(SOURCE / relative, expected)
                destination = output / 'snapshot' / relative
                destination.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / relative, destination)
                pin(destination, expected)
            record['productionSourceSHA256'].update(inventory)
            response = output / (module + 'Sources.rsp')
            response.write_text(''.join('"' + str(output / 'snapshot' / relative) + '"\n' for relative in sorted(inventory)))
            pin(response)
            target = modules / (module + '.swiftmodule')
            command = [prefix[0], '-I', str(modules)] + prefix[1:] + ['-module-name', module, '-emit-module', '-emit-module-path', str(target)]
            emitted[module] = [str(target)]
            if args.lane != 'embedded':
                object_file = modules / (module + '.code.o')
                command += ['-emit-object', '-o', str(object_file)]
                emitted[module].append(str(object_file))
            command += ['@' + str(response)]
            module_commands[module] = command
        record['moduleSourceCounts'] = {name: len(paths) for name, paths in inventories.items()}
        record['nativeTopologySourceAuthority'] = {'path': str(native_topology), 'sha256': pins[str(native_topology)], 'scope': 'Exact successful Native volume caller Topology142 source authority.'}
        record['products'] = emitted
        record['coreGeometryCompileSeconds'] = sum(phase['elapsedSeconds'] for phase in geometry['phases'])
        copied = []
        for relative, expected in INPUTS.items():
            pin(SOURCE / relative, expected)
            destination = output / 'snapshot' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / relative, destination)
            pin(destination, expected)
            copied.append(str(destination))
        link = []
        replaced = 0
        for value in selected['commands']['link']:
            if value.endswith('/snapshot/Tests/OriginalQueryExecutionVerification/FullGeometryPortable.swift'):
                link.extend(copied)
                replaced += 1
            else:
                link.append(value)
        require(replaced == 1, 'Expected one original standalone client source in link command.')
        old_executable = selected['products'][-1]
        executable = output / ('VolumeCallerAdmission' if args.lane == 'asan' else 'VolumeCallerAdmission.wasm')
        link[link.index('-o') + 1] = str(executable)
        runtime = [str(executable) if item == old_executable else item for item in selected['commands']['runtime']]
        for item in runtime:
            if item.endswith('.mjs'):
                pin(item)
        if args.lane != 'asan': pin(runtime[0])
        link = [link[0], '-I', str(modules), '-D', 'VOLUME_MOMENT_PORTABLE'] + link[1:]
        if args.lane != 'embedded':
            position = link.index('-o')
            link[position:position] = [path for paths in emitted.values() for path in paths if path.endswith('.code.o')]
        if args.reuse_topology_receipt:
            reused_path = args.reuse_topology_receipt.resolve()
            prior = json.loads(reused_path.read_text())
            pin(reused_path)
            require(prior['status'] == 'passed' and prior['lane'] == args.lane and not prior['postflightDrift'], 'Topology compilation origin is not accepted.')
            require(prior['productionSourceSHA256'] == record['productionSourceSHA256'], 'Reused Topology production sources differ.')
            previous = prior['steps']['CADTopology']
            require(previous['exitCode'] == 0 and previous['stopReason'] is None, 'Original Topology compiler failed.')
            require([value.replace(str(reused_path.parent), str(output)) for value in previous['command']] == module_commands['CADTopology'], 'Reused Topology flags differ.')
            pin(reused_path.parent / 'CADTopology.log', previous['logSHA256'])
            pin(reused_path.parent / 'CADTopologySources.rsp')
            for relative, expected in inventories['CADTopology'].items():
                pin(reused_path.parent / 'snapshot' / relative, expected)
            for path, expected in prior['compiledProductSHA256'].items():
                pin(path, expected)
                destination = modules / Path(path).name
                shutil.copyfile(path, destination)
                pin(destination, expected)
            record['reusedTopologyOrigin'] = {'path': str(reused_path), 'sha256': pins[str(reused_path)], 'compilerPhase': previous,
                'scope': 'Exact Topology production compiler phase/products only; old client source/runtime is not reused.'}
            record['moduleRegeneration'] = 0
            record['compiledProductSHA256'] = {path: pins[path] for path in emitted['CADTopology']}
            module_commands = {}
        record['commands'] = dict(module_commands, **{'client-link': link, 'runtime': runtime})
        record['executable'] = str(executable)
        record['fixtureSHA256'] = INPUTS
        record['status'] = 'running'
        save()
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['PATH'] = str(Path(prefix[0]).parent) + os.pathsep + environment.get('PATH', '')
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        deadline = time.monotonic() + 1200
        for name, command in record['commands'].items():
            step = run(command, output / (name + '.log'), environment,
                       deadline=time.monotonic() + 120 if name == 'runtime' else deadline,
                       stage_limit=120 if name == 'runtime' else 1200)
            record['steps'][name] = step
            pin(output / (name + '.log'), step['logSHA256'])
            if name in emitted and step['exitCode'] == 0 and step['stopReason'] is None:
                record.setdefault('compiledProductSHA256', {}).update({path: pin(path) for path in emitted[name]})
            if name == 'client-link' and step['exitCode'] == 0:
                record['executableSHA256'] = pin(executable)
            save()
            require(step['exitCode'] == 0 and step['stopReason'] is None, name + ' failed; inspect actual log.')
        observed = [line for line in (output / 'runtime.log').read_text().splitlines() if line.startswith('PASS ')]
        require(observed == EXPECTED, 'Actual four volume caller oracle output differs.')
        record['actualOutputLines'] = observed
        record['postflightDrift'] = verify()
        require(not record['postflightDrift'], 'Source/tool/product/log drift after runtime.')
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        save()
        print(json.dumps({'status': record['status'], 'receipt': str(output / 'receipt.json'), 'oracles': len(observed)}))
        return 0
    except Exception as error:
        record['status'] = 'failed'
        record['failure'] = str(error)
        record['postflightDrift'] = verify()
        save()
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
