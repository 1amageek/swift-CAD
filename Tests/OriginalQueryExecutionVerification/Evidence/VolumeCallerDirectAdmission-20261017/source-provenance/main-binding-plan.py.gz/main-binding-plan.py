"""Bind byte-identical Main sources to existing real compiler origins; never compile."""
from pathlib import Path
import hashlib,json,sys
MAIN=Path('/Users/1amageek/Desktop/3D/swift-CAD')
G=Path('/Users/1amageek/.codex/verification-artifacts/swift-CAD/u1-direct-gaps-green-20261017')
BASE=Path(__file__).resolve().parent
AUTH=G/'volume-caller-native-green-r1/receipt.json'
AUTH_SHA='cd44ab3641d5b687d75833590176fc7266d33e1067bc7ea69a9229041aac849d'
MODULES=['CADCore','CADGeometry','CADTopology']
def digest(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def check():
 require(digest(AUTH)==AUTH_SHA,'Original authority changed.')
 native=json.loads(AUTH.read_text());original=Path(native['sourceRoot'])
 actual={str(p.relative_to(MAIN)) for m in MODULES for p in (MAIN/'Sources'/m).rglob('*.swift')}
 require(actual==set(native['sourceSHA256']) and len(actual)==2380,'Main inventory changed.')
 require(digest(MAIN/'Package.swift')==native['packageManifestSHA256'],'Main Package changed.')
 require(digest(original/'Package.swift')==native['packageManifestSHA256'],'Original Package changed.')
 require(digest(Path(native['toolchain'])/'swiftc')==native['compilerSHA256'],'Compiler changed.')
 require(digest(Path(native['sdk'])/'SDKSettings.json')==native['sdkSettingsSHA256'],'SDK changed.')
 origins={}
 for name in MODULES:
  step=native['steps'][name];op=Path(step.get('reusedFrom',AUTH));origin=json.loads(op.read_text());fresh=origin['steps'][name]
  require(fresh['exitCode']==0 and fresh['stopReason'] is None and not fresh.get('reusedFrom'),'Origin is not fresh successful compiler.')
  require(fresh['command']==step['command'] and fresh['logSHA256']==step['logSHA256'],'Origin command/log changed.')
  for key in ['toolchain','compilerSHA256','compilerVersion','sdk','sdkSettingsSHA256','reusedProducts']:
   require(origin[key]==native[key],'Origin premise changed: '+key)
  command=fresh['command']
  require(command[0]==str(Path(native['toolchain'])/'swiftc') and '-Onone' in command and '-whole-module-optimization' in command,'Flags changed.')
  require(command[command.index('-target')+1]=='arm64-apple-macosx27.0' and command[command.index('-sdk')+1]==native['sdk'],'Target/SDK changed.')
  require(not any(v.startswith('@') for v in command),'Expected explicit whole-source command, not an unverified response.')
  source={p:h for p,h in native['sourceSHA256'].items() if p.startswith('Sources/'+name+'/')}
  require({str(Path(v).resolve()) for v in command if v.endswith('.swift')}=={str((op.parent/'snapshot'/p).resolve()) for p in source},'Compiler source inventory changed.')
  for prior in MODULES[:MODULES.index(name)+1]:
   require(origin['products'][prior]==native['products'][prior] and origin['objects'][prior]==native['objects'][prior],'Origin predecessor products differ.')
   for rel,h in native['sourceSHA256'].items():
    if rel.startswith('Sources/'+prior+'/'):
     require(origin['sourceSHA256'].get(rel)==h and digest(op.parent/'snapshot'/rel)==h,'Original compiler snapshot changed.')
  require(digest(op.parent/(name+'.log'))==fresh['logSHA256'],'Origin compiler log changed.')
  for rel,h in source.items():
   for p in [MAIN/rel,original/rel,AUTH.parent/'snapshot'/rel]:require(digest(p)==h,'Source bytes changed: '+str(p))
  for ext,key,flag in [('.swiftmodule','products','-emit-module-path'),('.o','objects','-o')]:
   for p in [Path(command[command.index(flag)+1]),AUTH.parent/'modules'/(name+ext)]:require(digest(p)==native[key][name],'Compiled product changed.')
  origins[name]={'path':str(op),'sha256':digest(op),'logSHA256':fresh['logSHA256'],'commandSHA256':hashlib.sha256(json.dumps(command).encode()).hexdigest(),'responseFile':'Not used: actual compiler command explicitly lists the whole source inventory.'}
 for p,h in native['reusedProducts'].items():require(digest(p)==h,'Dependency product changed.')
 for relative,expected in {'Tests/CADTopologyTests/VolumeCallerAdmissionChecks.swift': '5b898f1bab2a3523513defb72304988130ea6b4c94fcb1115c2b1e48ce17f3de', 'Tests/CADTopologyTests/VolumeCallerAdmissionTests.swift': '1edd4ddfba166dd378242d5132e83b63efb08fa824a34728ad733a614b0b798c', 'Tests/CADTopologyTests/VolumeMomentLoopAdmissionTests.swift': '88e32377739550032c63d740f799579542d1828ac45a185bfc10188b7e81d022'}.items():
  require(digest(MAIN/relative)==expected and digest(original/relative)==expected,'Final fixture changed: '+relative)
 return native,origins
native,origins=check()
if '--after' not in sys.argv:
 bound=json.loads(AUTH.read_text());bound['sourceRoot']=str(MAIN);bound['originalSourceRoot']=native['sourceRoot'];bound['nativeAuthority']={'path':str(AUTH),'sha256':AUTH_SHA};bound['compiledHere']=False;bound['status']='reuse-bound';bound['sourceEquivalentMapping']={p:{'main':str(MAIN/p),'original':str(Path(native['sourceRoot'])/p),'sha256':h} for p,h in native['sourceSHA256'].items()};bound['bindingPurpose']='Source-equivalent Main consumer binding only; original fresh compiler commands, products, logs and elapsed values are unchanged.'
 for name in MODULES:bound['steps'][name]['reusedFrom']=origins[name]['path']
 for name in ['snapshot','modules']:(BASE/name).symlink_to(AUTH.parent/name,target_is_directory=True)
 (BASE/'receipt.json').write_text(json.dumps(bound,indent=2)+'\n')
else:
 bound=json.loads((BASE/'receipt.json').read_text());require(bound['compiledHere'] is False and bound['status']=='reuse-bound','Binding misrepresents compilation.')
 for name in MODULES:
  actual=dict(bound['steps'][name]);actual.pop('reusedFrom',None);expected=dict(native['steps'][name]);expected.pop('reusedFrom',None);require(actual==expected,'Compiler step metadata was rewritten.')
record={'phase':'after' if '--after' in sys.argv else 'before','status':'source-equivalent','compiledHere':False,'nativeAuthority':{'path':str(AUTH),'sha256':AUTH_SHA},'bindingSHA256':digest(BASE/'receipt.json'),'MainProductionSources':2380,'sourceProductSDKFlagsAndOriginalSnapshotDrift':[],'fixtureSHA256':{'Tests/CADTopologyTests/VolumeCallerAdmissionChecks.swift': '5b898f1bab2a3523513defb72304988130ea6b4c94fcb1115c2b1e48ce17f3de', 'Tests/CADTopologyTests/VolumeCallerAdmissionTests.swift': '1edd4ddfba166dd378242d5132e83b63efb08fa824a34728ad733a614b0b798c', 'Tests/CADTopologyTests/VolumeMomentLoopAdmissionTests.swift': '88e32377739550032c63d740f799579542d1828ac45a185bfc10188b7e81d022'},'origins':origins}
(BASE/('after.json' if '--after' in sys.argv else 'before.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
