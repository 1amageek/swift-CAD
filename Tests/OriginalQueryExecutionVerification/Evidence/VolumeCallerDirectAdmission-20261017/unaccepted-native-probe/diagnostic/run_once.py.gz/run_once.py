from pathlib import Path
import json,os,sys,time,hashlib
B=Path(__file__).parent
R=B.parent/'volume-caller-native-red-r1'
H=Path('/Users/1amageek/.codex/worktrees/u1-parameter-table-20261017/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0,str(H))
from native_tests import run,SWIFT_BIN,SDK

def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
r=json.loads((R/'receipt.json').read_text());exe=r['testExecutable']['path']
assert sha(exe)==r['testExecutable']['sha256']
a=[str(SWIFT_BIN.parent/'libexec/swift/pm/swiftpm-testing-helper'),'--test-bundle-path',exe,'--package-path',str(R/'swift-cad'),'--scratch-path',str(R/'build'),'--jobs','1','--triple','arm64-apple-macosx27.0','--sdk',str(SDK),'-Xswiftc','-I','-Xswiftc',str(R/'accepted/modules'),'--enable-swift-testing','--disable-xctest','--disable-index-store','--verbose','--skip-build','--filter','VolumeCallerAdmissionTests','--xunit-output',str(B/'diagnostic.xml'),exe,'--testing-library','swift-testing']
c=[str(SWIFT_BIN/'lldb'),'--batch','--no-lldbinit','-o','settings set target.disable-aslr false','-o','settings set target.env-vars DYLD_FRAMEWORK_PATH=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/Library/Frameworks DYLD_LIBRARY_PATH=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/usr/lib','-o','command script import '+str(B/'capture_once.py'),'-o','capture-once','--']+a
pins={str(R/'receipt.json'):sha(R/'receipt.json'),exe:sha(exe),str(SWIFT_BIN/'lldb'):sha(SWIFT_BIN/'lldb'),a[0]:sha(a[0]),str(B/'capture_once.py'):sha(B/'capture_once.py')}
pins.update({p:v['sha256'] for p,v in r['acceptedProducts'].items()});pins.update({p:v['sha256'] for p,v in r['testSources'].items()})
# Original product/source maps contain exact SHA strings.
for p,h in pins.items():assert sha(p)==h,(p,h)
env=dict(os.environ);env.pop('TOOLCHAINS',None);env.update(PATH=str(SWIFT_BIN)+':/usr/bin:/bin:/usr/sbin:/sbin',SDKROOT=str(SDK),LANG='en_US.UTF-8',NO_COLOR='1')
out=dict(status='running',scope='One hot-stack diagnostic, same retained executable/filter/normal stack; no compile/source/fixture/cap changes.',compilerProcesses=0,inferiorLaunches=1,wallLimitSeconds=30,command=c,pins=pins)
(B/'receipt.json').write_text(json.dumps(out,indent=2)+'\n')
out['phase']=run(c,B/'debugger.log',env,time.monotonic()+30,30)
out['pinsUnchanged']=all(sha(p)==h for p,h in pins.items())
out['status']='captured-and-killed' if (B/'hot-stack.json').exists() and 'INFERIOR_KILLED' in (B/'debugger.log').read_text() else 'diagnostic-incomplete'
out['artifacts']={str(p):sha(p) for p in [B/'hot-stack.json',B/'debugger.log'] if p.exists()}
(B/'receipt.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status=out['status'],phase=out['phase'],receiptSHA256=sha(B/'receipt.json'))))
