import json,time
from pathlib import Path
import lldb

def capture(debugger,command,result,internal_dict):
 debugger.SetAsync(True)
 target=debugger.GetSelectedTarget()
 process=target.LaunchSimple(None,None,None)
 started=time.monotonic()
 while process.GetState() not in (lldb.eStateExited,lldb.eStateCrashed,lldb.eStateStopped) and time.monotonic()-started<8:
  time.sleep(.1)
 if process.GetState()==lldb.eStateRunning: process.Stop()
 end=time.monotonic()+2
 while process.GetState()==lldb.eStateRunning and time.monotonic()<end:time.sleep(.05)
 rows=[]
 for thread in process:
  fs=[]
  for frame in thread:
   line=frame.GetLineEntry()
   fs.append(dict(index=frame.GetFrameID(),name=frame.GetDisplayFunctionName(),pc=frame.GetPC(),sp=frame.GetSP(),fp=frame.GetFP(),source=str(line.GetFileSpec()),line=line.GetLine()))
  rows.append(dict(id=thread.GetThreadID(),stop=thread.GetStopDescription(2048),frames=fs))
 data=dict(pid=process.GetProcessID(),state=process.GetState(),observationSeconds=time.monotonic()-started,threads=rows)
 out=Path(__file__).parent/'hot-stack.json'
 out.write_text(json.dumps(data,indent=2)+'\n')
 result.PutCString('CAPTURED '+str(out))
 debugger.HandleCommand('thread backtrace all')
 process.Kill()
 result.PutCString('INFERIOR_KILLED')

def __lldb_init_module(debugger,internal_dict):
 debugger.HandleCommand('command script add -f capture_once.capture capture-once')
