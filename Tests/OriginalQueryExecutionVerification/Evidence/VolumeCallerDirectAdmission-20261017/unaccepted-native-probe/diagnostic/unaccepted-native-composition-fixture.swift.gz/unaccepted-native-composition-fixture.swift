import CADCore
import CADGeometry
import CADTopology
import HashTreeCollections

/// Real public-volume and selected-lower cost composition; no replacement geometry producer.
enum VolumeCallerAdmissionChecks {
    private typealias Shared = VolumeMomentLoopAdmissionChecks
    struct Failure: Error { let message: String }
    static let tolerance = Shared.tolerance

    static func require(_ condition: Bool, _ message: String) throws {
        guard condition else { throw Failure(message: message) }
    }

    static func execution(_ budget: OriginalQueryBudget) throws -> OriginalQueryExecution {
        try Shared.execution(budget)
    }

    static func nativePlaneCube() throws -> (model: BRepModel, bodyID: BodyID) {
        var input = Shared.cube()
        let faceID = FaceID(PortableIdentity128(high: 6, low: 1))
        guard let face = input.model.faces[faceID],
              let surface = input.model.geometry.surfaces[face.surfaceID],
              case let .plane(plane) = surface,
              let u = plane.uDirection else {
            throw Failure(message: "The original cube lost its authored first plane frame.")
        }
        let v = plane.normal.cross(u)
        // Exact dyadic degree-one source, not a fitted plane: S(u,v)=O+U*u+V*v.
        // The uniform i/32 knots and controls retain the original UV law on [0,1]^2.
        let controls = [0.0, 1.0].map { row in
            (0...32).map { column in plane.origin + u * (Double(column) / 32) + v * row }
        }
        let knots = [0.0, 0.0] + (1..<32).map { Double($0) / 32 } + [1.0, 1.0]
        input.model.geometry.surfaces[face.surfaceID] = .bSpline(BSplineSurface3D(
            uDegree: 1, vDegree: 1, uKnots: knots, vKnots: [0, 0, 1, 1], controlPoints: controls))
        return input
    }

    static func publicVolumePaysMandatorySelectedLowerCosts() throws {
        let plain = Shared.cube()
        var control = try execution(OriginalQueryBudget())
        let plainVolume = try plain.model.volume(of: plain.bodyID, tolerance: tolerance, using: &control)
        try require(abs(plainVolume - 1) <= tolerance.distance,
            "The original plain unit cube lost its independent volume.")

        let input = try nativePlaneCube()
        guard let body = input.model.bodies[input.bodyID], let shellID = body.shellIDs.first,
              let shell = input.model.shells[shellID], shell.faceIDs.count == 6 else {
            throw Failure(message: "The source-equivalent cube lost its six-face shell.")
        }

        // P is precisely the public base validate() called first by volume(of:using:).
        // P already includes its own line-only shell check and its first lower traversals.
        let preparationBudget = try OriginalQueryBudget()
        var preparation = try execution(preparationBudget)
        try preparation.consumeWork(13)
        try input.model.validate(tolerance: tolerance, using: &preparation)
        let p = preparationBudget.snapshot.work - 13

        // L is a separate mandatory second traversal in exactVolumeContribution:
        // one shell reference plus each face's exact plane; original implementations only.
        let lowerBudget = try OriginalQueryBudget()
        var lower = try execution(lowerBudget)
        try lower.consumeWork(13)
        let reference = try BRepShellReferencePointResolver().referencePoint(for: shell, in: input.model,
            context: "Line-only shell volume", using: &lower)
        try require(reference == Point3D(x: 0.5, y: 0.5, z: 0.5),
            "The genuine lower reference is not the cube's independent center.")
        for faceID in shell.faceIDs {
            guard let face = input.model.faces[faceID], let source = input.model.geometry.surfaces[face.surfaceID],
                  let _ = try DefaultPlanarSurfaceResolver().exactPlane(for: source,
                    tolerance: tolerance, using: &lower) else {
                throw Failure(message: "The actual lower did not retain an exact source plane.")
            }
        }
        let l = lowerBudget.snapshot.work - 13

        let queryBudget = try OriginalQueryBudget()
        var query = try execution(queryBudget)
        try query.consumeWork(13)
        let result = try input.model.volume(of: input.bodyID, tolerance: tolerance, using: &query)
        let v = queryBudget.snapshot.work - 13
        try require(abs(result - 1) <= tolerance.distance,
            "The same-law Native-plane cube lost its independent unit volume.")
        let minimum = p.addingReportingOverflow(l)
        try require(!minimum.overflow && p > 0 && l > 0, "The actual lower composition has no finite paid cost.")
        print("VOLUME_CALLER_COMPOSITION base=\(p) mandatorySecondLower=\(l) public=\(v) requiredMinimum=\(minimum.partialValue)")
        // Unrelated positive topology work cannot make a public query cheaper than its
        // actual base validation plus these unavoidable second lower operations.
        try require(v >= minimum.partialValue,
            "Public volume did not pay its mandatory real lower costs on the caller execution.")
        try require(query.localWork == queryBudget.snapshot.work,
            "Public volume lost its original caller attribution.")
    }
}
