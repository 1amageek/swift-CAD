import hashlib,json,os,sys,time
from pathlib import Path
from run import inspect_wasm,EXPECTED
H=Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0,str(H));from native_tests import run,RSS_BYTES
B=Path(__file__).resolve().parent;O=B.parent/'portable-memo-r7/embedded';P=B/'embedded';P.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
origin=json.loads((O/'receipt.json').read_text())
assert origin['status']=='failed' and origin['failure']=='Required actual IR witnesses missing.'
assert origin['steps']['client-link']['exitCode']==0 and origin['steps']['client-link']['stopReason'] is None
pins=dict(origin['inputAndProductSHA256']);pins[str(O/'receipt.json')]=sha(O/'receipt.json')
pins[str(B/'embedded-existing.py')]=sha(B/'embedded-existing.py');pins[str(B/'run.py')]=sha(B/'run.py')
exe=Path(origin['executable']);assert sha(exe)==origin['executableSHA256'];pins[str(exe)]=sha(exe)
for p,h in pins.items():assert sha(p)==h,p
parameters=inspect_wasm(exe,require_full_object=False);assert not parameters['overLimitTypes']
record={'status':'running','scope':'Actual Embedded final10oracle runtime; exact already linked binary and IR reused. All emitted function types checked; absent unreachable CADCommand witness receives no success claim.','originReceipt':{'path':str(O/'receipt.json'),'sha256':sha(O/'receipt.json')},'fixture':origin['fixture'],'sourceAuthority':origin['irSourceAuthority'],'inputAndProductSHA256':pins,'wasmFunctionParameters':parameters,'expectedOutputLines':EXPECTED,'steps':{'client-link':origin['steps']['client-link']},'bounds':{'runtimeSeconds':120,'RSSBytes':RSS_BYTES}}
def save(): (P/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
save();env=dict(os.environ);env.pop('TOOLCHAINS',None);env['PATH']=str(Path(origin['commands']['client-link'][0]).parent)+':'+env['PATH']
result=run(origin['commands']['runtime'],P/'runtime.log',env,time.monotonic()+120,120);record['steps']['runtime']=result;record['inputAndProductSHA256'][str(P/'runtime.log')]=result['logSHA256']
lines=(P/'runtime.log').read_text().splitlines();okay=result['exitCode']==0 and result['stopReason'] is None and all(s in lines for s in EXPECTED)
observation=next((s for s in lines if s.startswith('PASS memo task-group readers=')),None)
if observation:
 fields=dict(s.split('=',1)for s in observation.split()if '='in s)
 okay=okay and fields['readers']=='8'and 1<=int(fields['peak-computations'])<=int(fields['computations'])<=8
 record['taskGroupObservation']=observation
else:okay=False
for p,h in pins.items():assert sha(p)==h,p
record['sourcesProductsAndLogsUnchanged']=True;record['status']='passed'if okay else'failed';save();print(record['status'],result['elapsedSeconds'],flush=True)
