#!/usr/bin/env python3
"""Verify full production Topology and IR, then the actual retained fingerprint memo."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import time

SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
ORIGINAL = Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD')
HARNESS = ORIGINAL / 'Tests/OriginalQueryExecutionVerification'
sys.path.insert(0, str(HARNESS))
from native_tests import run, RSS_BYTES

PREFIX_HELPER = Path('/Users/1amageek/.codex/verification-artifacts/swift-CAD/u1-os-callers-20261016/portable-memo-r1')
sys.path.insert(0, str(PREFIX_HELPER))
from prefix import load_core_geometry_prefix

BIN = Path('/Users/1amageek/Library/Developer/Toolchains/swift-6.4.0-RELEASE.xctoolchain/usr/bin')
BASE = Path(__file__).resolve().parent
FIXTURE = SOURCE / 'Tests/OriginalQueryExecutionVerification/ValidatedDocumentFingerprintMemoPortable.swift'
EXPECTED = [
    'PASS memo bridge-value hash-codec-source-identity',
    'PASS memo sketch-reference-keys actual-chain-order',
    'PASS memo actual-document-cancellation',
    'PASS memo actual-platform-clock',
    'PASS memo actual-boundary-math certificate-angle-refusal',
    'PASS memo failure-retry completed-reuse',
    'PASS memo reentrant-compute first-completed-publication',
    'PASS memo retained-owner',
    'PASS memo all',
]

def digest(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def inspect_wasm(path, require_full_object=True):
    raw = path.read_bytes()
    def integer(pos):
        value = shift = 0
        while True:
            byte = raw[pos]; pos += 1; value |= (byte & 127) << shift
            if byte < 128: return value, pos
            shift += 7
    def string(pos):
        size, pos = integer(pos)
        return raw[pos:pos + size].decode('utf-8'), pos + size
    sections = []; pos = 8
    while pos < len(raw):
        kind = raw[pos]; size, pos = integer(pos + 1)
        sections.append((kind, pos, pos + size)); pos += size
    counts = []; functions = []; names = {}
    for kind, pos, end in sections:
        if kind == 1:
            size, pos = integer(pos)
            for _ in range(size):
                require(raw[pos] == 0x60, 'Unexpected Wasm function type encoding.'); pos += 1
                count, pos = integer(pos); counts.append(count); pos += count
                count, pos = integer(pos); pos += count
        elif kind == 2:
            size, pos = integer(pos)
            for _ in range(size):
                _, pos = string(pos); _, pos = string(pos)
                require(raw[pos] == 0, 'Unexpected nonfunction Wasm import.'); pos += 1
                type_index, pos = integer(pos); functions.append(type_index)
        elif kind == 3:
            size, pos = integer(pos)
            for _ in range(size):
                type_index, pos = integer(pos); functions.append(type_index)
        elif kind == 0:
            label, pos = string(pos)
            if label != 'name': continue
            while pos < end:
                subkind = raw[pos]; size, start = integer(pos + 1); pos = start + size
                if subkind != 1: continue
                count, start = integer(start)
                for _ in range(count):
                    index, start = integer(start); label, start = string(start); names[index] = label
    relevant = {name: counts[functions[index]] for index, name in names.items()
        if any(owner in name for owner in ['CADCommandO', 'FeatureOperationO', 'ResolvedDocumentObjectO'])
        and ('WOy' in name or 'WOe' in name)}
    require(not require_full_object or (relevant and all(any(owner in name for name in relevant)
        for owner in ['CADCommandO', 'FeatureOperationO', 'ResolvedDocumentObjectO'])), 'Required actual IR witnesses missing.')
    return {'maximumParameters': max(counts), 'overLimitTypes': {i: n for i, n in enumerate(counts) if n > 1000},
        'actualIRWitnessParameters': relevant}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', required=True, choices=['asan', 'wasm', 'embedded'])
    parser.add_argument('--core-geometry-receipt', required=True, type=Path)
    parser.add_argument('--native-receipt', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--reuse-topology', type=Path, required=True)
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--resume-plan', action='store_true')
    args = parser.parse_args()
    output = args.output.resolve()
    record_path = output / 'receipt.json'
    record = None

    def save():
        record_path.write_text(json.dumps(record, indent=2) + '\n')

    def verify_files(files):
        for path, expected in files.items():
            require(digest(path) == expected, 'Pinned input or product changed: ' + path)

    try:
        if args.resume_plan:
            record = json.loads(record_path.read_text())
            require(record['status'] == 'prepared', 'Only an unexecuted immutable plan can resume.')
            require(record['lane'] == args.lane, 'Lane changed.')
            require(record['coreGeometryReceipt']['path'] == str(args.core_geometry_receipt.resolve())
                    and record['nativeReceipt']['path'] == str(args.native_receipt.resolve()), 'Authority selection changed.')
            require(record['runnerSHA256'] == digest(Path(__file__)), 'Driver changed after preparation.')
        else:
            output.mkdir(parents=True, exist_ok=False)
            prefix_path = args.core_geometry_receipt.resolve()
            native_path = args.native_receipt.resolve()
            require(digest(PREFIX_HELPER / 'prefix.py') ==
                'c7500193e4e89811b7bee27e51d061c088a5d3cf6f076e5e60a32147b587aea2',
                'Shared immutable prefix loader changed.')
            accepted = load_core_geometry_prefix(prefix_path, native_path, args.lane, SOURCE)
            native, selected = accepted['native'], accepted['selected']
            sources, products = accepted['sources'], accepted['products']
            files = accepted['files']
            lane = args.lane
            files.update({str(Path(__file__).resolve()): digest(Path(__file__)),
                str(FIXTURE): digest(FIXTURE),
                str(HARNESS / 'native_tests.py'): digest(HARNESS / 'native_tests.py'),
                str(HARNESS / 'typecheck.py'): digest(HARNESS / 'typecheck.py')})
            require(RSS_BYTES == 10 * 1024**3, 'Canonical monitor RSS bound differs.')
            freeze_path = BASE.parent / 'ir-portable-fix-freeze-r3/source-freeze.json'
            require(digest(freeze_path) == 'da9e012a30f009cf7cac44e937ba690c630b12340e4bd80293c185d02b15680c', 'Root-approved IR freeze changed.')
            freeze = json.loads(freeze_path.read_text())
            require(freeze['sourceCount'] == 22 and freeze['testCount'] == 1, 'IR freeze scope changed.')
            files[str(freeze_path)] = digest(freeze_path)
            require(freeze['sourceSHA256'][str(FIXTURE.relative_to(SOURCE))] == 'e2acbfa4e073524230faf1c78284fbe10d9735f0b9ee48d348a1e3ba21b771d7' and digest(FIXTURE) == 'f0047e0f6c1aaa7eb04840b80d95d773d76ef118a1e6e05b8a28b2841f1b8144', 'Fixture differs from the exact approved direct-group.next correction.')
            topology = {}
            counts = {}
            for module in ['CADTopology', 'CADIR']:
                step = native['steps'][module]
                require(step['exitCode'] == 0 and step.get('stopReason') is None,
                    'Native source authority was not accepted: ' + module)
                inventory = {path: sha for path, sha in native['sourceSHA256'].items()
                    if path.startswith('Sources/' + module + '/')}
                if module == 'CADIR':
                    inventory.update({p: h for p, h in freeze['sourceSHA256'].items() if p.startswith('Sources/CADIR/')})
                actual = {str(path.relative_to(SOURCE)) for path in (SOURCE / 'Sources' / module).rglob('*.swift')}
                require(set(inventory) == actual, 'Source inventory changed: ' + module)
                counts[module] = len(inventory)
                topology.update(inventory)
            require(counts['CADTopology'] == 142, 'Topology inventory changed.')
            for path, sha in topology.items():
                files[str(SOURCE / path)] = sha
                files[str(native_path.parent / 'snapshot' / path)] = native['sourceSHA256'][path]
            compile_command = selected['commands']['compile']
            verify_files(files)
            snapshot = output / 'snapshot'
            for relative, sha in topology.items():
                target = snapshot / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / relative, target)
                require(digest(target) == sha, 'Topology copy changed.')
                files[str(target)] = sha
            client = snapshot / FIXTURE.relative_to(SOURCE)
            client.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(FIXTURE, client)
            files[str(client)] = digest(FIXTURE)
            destination = output / lane
            destination.mkdir()
            flags = compile_command[1:compile_command.index('-module-name')] + ['-I', str(destination)]
            require('-enable-testing' in flags, 'Actual memo requires the real testable IR module.')
            fresh_commands, fresh_products, fresh_objects = {}, [], []
            for module_name in ['CADTopology', 'CADIR']:
                response = destination / (module_name + 'Sources.rsp')
                response.write_text(''.join('"' + str(snapshot / path) + '"\n' for path in sorted(topology)
                    if path.startswith('Sources/' + module_name + '/')))
                files[str(response)] = digest(response)
                module = destination / (module_name + '.swiftmodule')
                object_file = destination / (module_name + '.code.o')
                command = [str(BIN / 'swiftc')] + flags + ['-module-name', module_name, '-emit-module', '-emit-module-path', str(module)]
                fresh_products.append(str(module))
                if lane != 'embedded':
                    command += ['-emit-object', '-o', str(object_file)]
                    fresh_products.append(str(object_file))
                    fresh_objects.append(str(object_file))
                command += ['@' + str(response)]
                fresh_commands[module_name + '-compile'] = command
            old_link = selected['commands']['link']
            objects = [value for value in old_link if value.endswith('.o')]
            require(not objects if lane == 'embedded' else len(objects) == 4, 'Unexpected library emission model.')
            for path in objects:
                require(path in products, 'Unreceipted link object: ' + path)
            executable = destination / ('FingerprintMemo' if lane == 'asan' else 'FingerprintMemo.wasm')
            link = [str(BIN / 'swiftc')] + flags + [str(client)]
            if lane != 'embedded':
                link += fresh_objects + objects
            link += ['-o', str(executable)] + old_link[old_link.index('-o') + 2:]
            runtime = [str(executable)] if lane == 'asan' else [selected['commands']['runtime'][0], selected['commands']['runtime'][1], str(executable)]
            if lane != 'asan':
                files[runtime[0]] = digest(runtime[0])
                files[runtime[1]] = digest(runtime[1])
            record = {'status': 'prepared', 'scope': 'Actual full Topology and IR compilation; production fingerprint memo lifecycle, reentrancy and scheduled concurrent access only.',
                'lane': lane, 'sourceRoot': str(SOURCE), 'sourceCount': {'CADCore': 67, 'CADGeometry': 2171, **counts},
                'coreGeometryReceipt': {'path': str(prefix_path), 'sha256': digest(prefix_path), 'scope': 'Successful selected lane only; immutable prefix may retain another lane running.'},
                'nativeReceipt': {'path': str(native_path), 'sha256': digest(native_path)},
                'inputAndProductSHA256': files, 'topologySourceSHA256': topology,
                'irSourceAuthority': {'path': str(freeze_path), 'sha256': digest(freeze_path), 'scope': 'Root-approved exact22source delta over the accepted Native base; actual new IR is compiled here.'},
                'fixture': {'path': str(FIXTURE), 'sha256': digest(FIXTURE), 'copy': str(client), 'expectedOutputLines': EXPECTED},
                'runnerSHA256': digest(Path(__file__)), 'monitor': {'path': str(HARNESS / 'native_tests.py'), 'sha256': digest(HARNESS / 'native_tests.py'), 'entry': 'run'},
                'commands': {**fresh_commands, 'client-link': link, 'runtime': runtime},
                'products': fresh_products, 'executable': str(executable),
                'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'aggregateRSSBytes': RSS_BYTES, 'ownedCompilerProcesses': 1},
                'steps': {}, 'coreGeometryOrCollectionsRegenerated': False}
            save()
        origin_path = args.reuse_topology.resolve()
        origin = json.loads(origin_path.read_text())
        require(origin['lane'] == args.lane and origin['coreGeometryReceipt'] == record['coreGeometryReceipt'], 'Topology lane or lower prefix differs.')
        topo = lambda inventory: {p: h for p, h in inventory.items() if p.startswith('Sources/CADTopology/')}
        require(topo(origin['topologySourceSHA256']) == topo(record['topologySourceSHA256']), 'Topology source changed.')
        phase = origin['steps']['CADTopology-compile']
        require(phase['exitCode'] == 0 and phase.get('stopReason') is None
            and phase['command'] == origin['commands']['CADTopology-compile'], 'Topology compile not accepted.')
        require([v.replace(str(output), str(origin_path.parent)) for v in record['commands']['CADTopology-compile']]
            == origin['commands']['CADTopology-compile'], 'Topology import/compiler/SDK flags differ beyond output paths.')
        retained = {p: h for p, h in origin['inputAndProductSHA256'].items()
            if p != origin['fixture']['path'] and not p.startswith(str(SOURCE / 'Sources/CADIR') + '/')
            and not Path(p).name.startswith('CADIR.')}
        verify_files(retained)
        products = {p: h for p, h in origin['compiledProductSHA256'].items() if Path(p).name.startswith('CADTopology.')}
        require(len(products) == (1 if args.lane == 'embedded' else 2), 'Unexpected actual Topology products.')
        require(all(retained[p] == h for p, h in products.items()), 'Topology module/object not pinned.')
        old_destination = str(Path(next(iter(products))).parent)
        record['commands']['CADIR-compile'].extend(['-I', old_destination])
        record['commands']['client-link'].extend(['-I', old_destination])
        old_objects = {Path(p).name: p for p in products if p.endswith('.o')}
        record['commands']['client-link'] = [old_objects.get(Path(v).name, v)
            if v.endswith('.o') else v for v in record['commands']['client-link']]
        record['products'] = [p for p in record['products'] if not Path(p).name.startswith('CADTopology.')] + list(products)
        record['steps']['CADTopology-compile'] = {**phase, 'reusedFrom': str(origin_path), 'reusedReceiptSHA256': digest(origin_path)}
        record['compiledProductSHA256'] = products
        record['inputAndProductSHA256'].update(retained)
        record['inputAndProductSHA256'][str(origin_path)] = digest(origin_path)
        record['topologyRegenerated'] = False
        record['acceptedTopologyProducts'] = products
        save()
        verify_files(record['inputAndProductSHA256'])
        if args.prepare_only:
            print(json.dumps({'status': 'prepared', 'receipt': str(record_path)}), flush=True)
            return
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['PATH'] = str(BIN) + ':' + environment.get('PATH', '')
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        record['status'] = 'running'
        deadline = time.monotonic() + 1200
        for name in ['CADIR-compile', 'client-link', 'runtime']:
            verify_files(record['inputAndProductSHA256'])
            if name == 'runtime':
                stage_deadline = time.monotonic() + 120
            else:
                stage_deadline = deadline
            result = run(record['commands'][name], output / (name + '.log'), environment,
                deadline=stage_deadline, stage_limit=120 if name == 'runtime' else 1200)
            record['steps'][name] = result
            record['inputAndProductSHA256'][str(output / (name + '.log'))] = result['logSHA256']
            save()
            require(result['exitCode'] == 0 and result['stopReason'] is None, name + ' failed')
            if name in ['CADTopology-compile', 'CADIR-compile']:
                record['compiledProductSHA256'] = {path: digest(path) for path in record['products'] if Path(path).is_file()}
                record['inputAndProductSHA256'].update(record['compiledProductSHA256'])
            if name == 'client-link':
                record['executableSHA256'] = digest(record['executable'])
                if args.lane != 'asan':
                    record['wasmFunctionParameters'] = inspect_wasm(Path(record['executable']))
                    require(not record['wasmFunctionParameters']['overLimitTypes'], 'Raw WASM still exceeds the actual engine1000parameter bound.')
                record['inputAndProductSHA256'][record['executable']] = record['executableSHA256']
            if name == 'runtime':
                lines = (output / 'runtime.log').read_text().splitlines()
                require(all(value in lines for value in EXPECTED), 'Missing actual memo lifecycle oracle output.')
                observation = next((line for line in lines if line.startswith('PASS memo task-group readers=')), None)
                require(observation is not None, 'Missing actual task-group observation.')
                record['taskGroupObservation'] = observation
                fields = dict(part.split('=', 1) for part in observation.split() if '=' in part)
                require(fields['readers'] == '8' and 1 <= int(fields['computations']) <= 8
                    and 1 <= int(fields['peak-computations']) <= int(fields['computations']), 'Invalid task-group counts.')
                record['observedPhysicalComputeOverlap'] = int(fields['peak-computations']) > 1
            save()
            print(json.dumps({'phase': name, 'exitCode': result['exitCode'], 'elapsedSeconds': result['elapsedSeconds'],
                'peakRSSBytes': result['sampledPeakProcessTreeRSSBytes']}), flush=True)
        verify_files(record['inputAndProductSHA256'])
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        save()
    except Exception as error:
        if record is not None:
            record['status'] = 'failed'
            record['failure'] = str(error)
            save()
        print(str(error), flush=True)
        raise SystemExit(1)

if __name__ == '__main__':
    main()
