#!/usr/bin/env python3
"""One actual Native client against the existing accepted Core/Geometry products."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import time

ROOT = Path(__file__).resolve().parent
DURABLE = ROOT.parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
RECEIPT = DURABLE / 'native-upper-r4/receipt.json'
FREEZE = ROOT / 'inputs.json'
spec = importlib.util.spec_from_file_location('actual_native_monitor', ROOT / 'monitor.py')
monitor = importlib.util.module_from_spec(spec)
spec.loader.exec_module(monitor)
monitor.ROOT = ROOT
monitor.ENV.pop('TOOLCHAINS', None)
TOOL = monitor.SWIFT_BIN
SDK = monitor.SDK
h = monitor.digest
started = time.monotonic()
record = dict(status='preparing', scope='Actual Native CADIR fingerprint memo, bridge value, reference keys, cancellation, clock and boundary client; no whole-package claim.',
              sourceReceipt=dict(path=str(RECEIPT), sha256=h(RECEIPT)), sourceSHA256={},
              acceptedProducts={}, steps={}, compilerLimitSeconds=1200, runtimeLimitSeconds=120,
              aggregateRSSLimitBytes=10 * 1024**3, monitorSHA256=h(ROOT / 'monitor.py'))

def require(value, message):
    if not value:
        raise RuntimeError(message)

def save():
    record['elapsedSeconds'] = time.monotonic() - started
    (ROOT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

def product(path, expected):
    require(h(path) == expected, 'Accepted dependency product changed: ' + str(path))
    destination = ROOT / 'accepted' / path.name
    shutil.copyfile(path, destination)
    require(h(destination) == expected, 'Copied product changed.')
    record['acceptedProducts'][str(destination)] = dict(origin=str(path), sha256=expected)
    return destination

def step(name, command, limit):
    value = monitor.run(command, ROOT / (name + '.log'), limit)
    record['steps'][name] = value
    save()
    require(value['exitCode'] == 0 and value['stopReason'] is None, name + ' failed')

try:
    production = json.loads(RECEIPT.read_text())
    require(Path(production['sourceRoot']) == SOURCE, 'Production source owner differs.')
    require(production['toolchain'] == str(TOOL) and production['sdk'] == str(SDK), 'Toolchain/SDK differs.')
    require(production['compilerSHA256'] == h(TOOL / 'swiftc')
            and production['sdkSettingsSHA256'] == h(SDK / 'SDKSettings.json'), 'Compiler/SDK metadata changed.')
    require(h(SOURCE / 'Package.swift') == production['packageManifestSHA256'], 'Production manifest changed.')
    (ROOT / 'accepted').mkdir()
    objects = []
    record['moduleOrigins'] = {}
    for name in ['CADCore', 'CADGeometry', 'CADTopology', 'CADIR']:
        accepted = production['steps'][name]
        require(accepted['exitCode'] == 0 and accepted.get('stopReason') is None, 'Unaccepted module: ' + name)
        origin_path = Path(accepted.get('reusedFrom', RECEIPT)).resolve()
        origin = json.loads(origin_path.read_text())
        original = origin['steps'][name]
        require(not original.get('reusedFrom') and original['exitCode'] == 0 and original.get('stopReason') is None
                and original['command'] == accepted['command'], 'Original successful compiler invocation differs.')
        for key in ['toolchain', 'compilerSHA256', 'compilerVersion', 'sdk', 'sdkSettingsSHA256', 'reusedProducts']:
            require(origin[key] == production[key], 'Original compiler/dependency premise differs: ' + key)
        for predecessor in ['CADCore', 'CADGeometry', 'CADTopology', 'CADIR'][:['CADCore', 'CADGeometry', 'CADTopology', 'CADIR'].index(name) + 1]:
            require(origin['products'][predecessor] == production['products'][predecessor], 'Reused dependency product differs.')
            prefix = 'Sources/' + predecessor + '/'
            require({p:v for p,v in origin['sourceSHA256'].items() if p.startswith(prefix)} == {p:v for p,v in production['sourceSHA256'].items() if p.startswith(prefix)}, 'Reused dependency source differs.')
        command = original['command']
        require(command[0] == str(TOOL / 'swiftc') and '-emit-object' in command and '-emit-module' in command,
                'Not actual module/object compiler invocation.')
        require(command[command.index('-target') + 1] == 'arm64-apple-macosx27.0'
                and command[command.index('-sdk') + 1] == str(SDK), 'Compiler target/SDK differs.')
        sources = {p: v for p, v in production['sourceSHA256'].items() if p.startswith('Sources/' + name + '/')}
        actual = {str(p.relative_to(SOURCE)) for p in (SOURCE / 'Sources' / name).rglob('*.swift')}
        require(actual == set(sources), 'Actual source inventory differs: ' + name)
        require({p: v for p, v in origin['sourceSHA256'].items() if p in sources} == sources,
                'Original source inventory differs.')
        require({str(Path(p).resolve()) for p in command if p.endswith('.swift')}
                == {str((origin_path.parent / 'snapshot' / p).resolve()) for p in sources}, 'Compiler input paths differ.')
        for path, expected in sources.items():
            require(h(SOURCE / path) == expected and h(RECEIPT.parent / 'snapshot' / path) == expected
                    and h(origin_path.parent / 'snapshot' / path) == expected, 'Source snapshot differs: ' + path)
        record['sourceSHA256'].update(sources)
        require(h(origin_path.parent / (name + '.log')) == original['logSHA256'], 'Successful compiler log changed.')
        for key, flag in [('products', '-emit-module-path'), ('objects', '-o')]:
            require(origin[key][name] == production[key][name]
                    and h(Path(command[command.index(flag) + 1])) == production[key][name], 'Original product differs.')
        product(RECEIPT.parent / 'modules' / (name + '.swiftmodule'), production['products'][name])
        objects.append(product(RECEIPT.parent / 'modules' / (name + '.o'), production['objects'][name]))
        record['moduleOrigins'][name] = dict(path=str(origin_path), sha256=h(origin_path))
    collections, descriptor = monitor.verify_collections_products(Path(production['collectionsProductsReceipt']['path']))
    require(descriptor == production['collectionsProductsReceipt'], 'Fresh Collections dependency differs.')
    record['collectionsProductsReceipt'] = descriptor
    for name in ['InternalCollectionsUtilities', 'HashTreeCollections']:
        source = next(Path(p) for p in production['reusedProducts'] if Path(p).name == name + '.swiftmodule')
        require(collections[str(source)] == production['reusedProducts'][str(source)], 'Collections authority differs.')
        require(h(RECEIPT.parent / 'modules' / source.name) == collections[str(source)], 'Imported Collections differs.')
        product(source, collections[str(source)])
        objects.append(product(source.with_suffix('.o'), collections[str(source.with_suffix('.o'))]))
    freeze = json.loads(FREEZE.read_text())
    require(freeze['sourceFreeze'] is not None and freeze['sourceFreezeSHA256'] is not None, 'Final source freeze has not been pinned.')
    require(h(Path(freeze['sourceFreeze'])) == freeze['sourceFreezeSHA256'], 'Final source freeze changed.')
    fixture = SOURCE / freeze['client']
    copied = ROOT / fixture.name
    require(h(fixture) == freeze['clientSHA256'] == h(copied), 'Frozen client source changed.')
    record['fixture'] = dict(path=str(fixture), copy=str(copied), sha256=h(fixture),
                             freeze=str(FREEZE), freezeSHA256=h(FREEZE), expectedOutput=freeze['expectedOutput'])
    record['runnerSHA256'] = h(Path(__file__))
    step('compiler-version', [str(TOOL / 'swiftc'), '--version'], 30)
    require((ROOT / 'compiler-version.log').read_text() == production['compilerVersion'], 'Compiler banner differs.')
    executable = ROOT / 'ValidatedDocumentFingerprintMemoPortable'
    command = [str(TOOL / 'swiftc'), '-parse-as-library', '-swift-version', '6', '-Onone',
               '-whole-module-optimization', '-num-threads', '0', '-j1', '-g', '-enable-testing',
               '-tools-directory', str(TOOL), '-Xclang-linker',
               '-fuse-ld=/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/ld',
               '-package-name', 'swift_cad', '-target', 'arm64-apple-macosx27.0', '-sdk', str(SDK),
               '-I', str(ROOT / 'accepted'), str(copied), *map(str, objects), '-o', str(executable)]
    step('client-compile-link', command, max(1, 1200 - (time.monotonic() - started)))
    record['executableSHA256'] = h(executable)
    step('runtime', [str(executable)], 120)
    lines = (ROOT / 'runtime.log').read_text().splitlines()
    require(all(line in lines for line in freeze['expectedOutput']), 'Missing actual oracle PASS lines.')
    import re
    dynamic = [re.fullmatch(r'PASS memo task-group readers=8 computations=(\d+) peak-computations=(\d+)', line) for line in lines]
    dynamic = [m for m in dynamic if m]
    require(len(dynamic) == 1 and 1 <= int(dynamic[0][1]) <= 8 and 1 <= int(dynamic[0][2]) <= int(dynamic[0][1]), 'Invalid task-group observation.')
    record['taskGroupObservation'] = dict(readers=8, computations=int(dynamic[0][1]), peakComputations=int(dynamic[0][2]))
    record['matchedOracleCount'] = len(freeze['expectedOutput']) + 1
    require(all(h(SOURCE / p) == expected for p, expected in record['sourceSHA256'].items()), 'Current production drift.')
    require(all(h(Path(p)) == item['sha256'] and h(Path(item['origin'])) == item['sha256']
                for p, item in record['acceptedProducts'].items()), 'Products drifted.')
    require(h(fixture) == freeze['clientSHA256'] == h(copied) and h(FREEZE) == record['fixture']['freezeSHA256'],
            'Client or freeze drifted.')
    require(monitor.verify_collections_products(Path(descriptor['path']))[1] == descriptor, 'Dependency drifted.')
    require(h(RECEIPT) == record['sourceReceipt']['sha256'], 'Production receipt drifted.')
    record['sourcesAndProductsUnchanged'] = True
    record['status'] = 'passed'
    save()
    print(json.dumps(dict(status='passed', receipt=str(ROOT / 'receipt.json'))))
except Exception as error:
    record['status'] = 'failed'
    record['failure'] = str(error)
    save()
    print(str(error), flush=True)
    raise SystemExit(1)
