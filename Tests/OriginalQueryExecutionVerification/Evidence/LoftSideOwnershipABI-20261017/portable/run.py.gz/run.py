#!/usr/bin/env python3
"""Run the actual one-source Loft module and six shared ownership controls on frozen Core/Geometry products."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
HARNESS = Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0, str(HARNESS))
from native_tests import run, RSS_BYTES

MODEL_INPUT = 'Sources/CADModeling/Loft/LoftSideSurfaceSource.swift'
MODEL_SHA = 'ae3e63a76d5c165284dee311fd5f6d4f82dac8b98130ced502de75f7f9cdedcb'
INPUTS = {
    'Tests/CADModelingTests/LoftPlaneDerivativeOwnershipChecks.swift': 'dc6cb7db5ad849fdc2e6ee49982e999a8a833df0e467281532e21dc4a2828694',
    'Tests/OriginalQueryExecutionVerification/LoftPlaneDerivativeOwnershipPortable.swift': '2e891f0affc0079bc6ba78777ba7afcae5364ea97d7ebd6bc2e44611da03bb8b',
}
EXPECTED = [
    'PASS loft original source copy and guarantee lifetime',
    'PASS loft each typed payload capacity refuses before certification',
    'PASS loft source cases and actual value layouts',
    'PASS loft actual converter cumulative storage N and N-minus-1',
    'PASS loft actual converter refusal prevents side publication',
    'PASS loft actual converter cancellation and retained source lifetime',
]


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', required=True, choices=['asan', 'wasm', 'embedded'])
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--resume-plan', action='store_true')
    args = parser.parse_args()
    if args.resume_plan:
        return execute(args.lane)
    require(args.prepare, 'Choose --prepare or --resume-plan.')
    output = BASE / args.lane
    output.mkdir(exist_ok=False)
    pins = {}
    record = {'status': 'preparing', 'lane': args.lane, 'scope': 'Actual LoftSideSurfaceSource whole source and six shared ownership controls on current Core67/Geometry2171; no other Modeling, IR, Kernel, Exchange or whole-task acceptance.',
              'moduleRegeneration': 1, 'lowerModuleRegeneration': 0, 'steps': {}, 'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'processTreeRSSBytes': RSS_BYTES, 'jobs': 1},
              'inputAndProductSHA256': pins, 'expectedOutputLines': EXPECTED}

    def save():
        (output / 'plan.json').write_text(json.dumps(record, indent=2) + '\n')

    def pin(path, expected=None):
        path = Path(path)
        observed = digest(path)
        require(expected is None or observed == expected, 'Input/product hash differs: ' + str(path))
        require(str(path) not in pins or pins[str(path)] == observed, 'Conflicting input pin: ' + str(path))
        pins[str(path)] = observed
        return observed

    def verify():
        return [path for path, expected in pins.items() if not Path(path).is_file() or digest(path) != expected]

    try:
        geometry_receipt = ROOT / 'current-geometry' / args.lane / 'receipt.json'
        geometry = json.loads(geometry_receipt.read_text())
        selected = geometry['lanes'][args.lane]
        authority = ROOT / 'native-current-geometry-r2/receipt.json'
        pin(authority, 'e204846e7c7cab172f79257ef812847d774ffcc6c6369c86639da1a613a8d4d8')
        source_authority = json.loads(authority.read_text())
        require(geometry['status'] == 'compiled-only' and geometry['compileCore'], 'Current Core and Geometry require their actual fresh successful compiler phases.')
        require(geometry['sourceSHA256'] == source_authority['sourceSHA256'], 'Geometry source authority differs.')
        require(all(not geometry[name] for name in ['currentDrift', 'snapshotDrift', 'productDrift']), 'Geometry origin has drift.')
        record['geometryOrigin'] = {'path': str(geometry_receipt), 'sha256': pin(geometry_receipt)}
        record['sourceAuthority'] = {'path': str(authority), 'sha256': pins[str(authority)], 'scope': 'Actual successful Native current Core and Geometry source authority'}
        record['productionSourceSHA256'] = geometry['sourceSHA256']
        record['productionSourceRoot'] = str(geometry_receipt.parent / 'snapshot')
        require(geometry['sourceCount'] == {'CADCore': 67, 'CADGeometry': 2171}, 'Production input counts differ.')
        for relative, expected in geometry['sourceSHA256'].items():
            pin(geometry_receipt.parent / 'snapshot' / relative, expected)
        phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-compile')
        require(phase['exitCode'] == 0 and phase['stopReason'] is None and phase['command'] == selected['commands']['compile'], 'Geometry compiler phase is not accepted.')
        pin(phase['log'], phase['logSHA256'])
        response = Path(phase['command'][-1][1:])
        pin(response, selected['responseSHA256'])
        require(set(shlex.split(response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADGeometry/')}, 'Geometry compiler inventory differs.')
        for mapping in [selected['compiledProductSHA256'], selected['compiledCoreProductSHA256'], selected['platformArchiveSHA256']]:
            for path, expected in mapping.items():
                pin(path, expected)
        for path, item in selected['dependencies'].items():
            pin(path, item['sha256'])
            pin(item['source'], item['sha256'])
        core_phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-core-compile')
        require(core_phase['exitCode'] == 0 and core_phase['stopReason'] is None and core_phase['command'] == selected['commands']['core-compile'], 'Current Core compiler phase differs.')
        pin(core_phase['log'], core_phase['logSHA256'])
        core_response = Path(core_phase['command'][-1][1:])
        pin(core_response, selected['coreResponseSHA256'])
        require(set(shlex.split(core_response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADCore/')}, 'Current Core compiler inventory differs.')
        record['retainedCoreCompilerPhase'] = core_phase
        product_map = ROOT / 'current-geometry/products.json'
        pin(product_map, 'd09b7659aca7757e57f16805d1a1a637d5327b023d99b688a70133c5fc93b0d8')
        require(json.loads(product_map.read_text())['lanes'][args.lane]['receiptSHA256'] == pins[str(geometry_receipt)], 'Current product-map authority differs.')
        upper_map = ROOT / 'ir-prefix-clients-r2/products.json'
        pin(upper_map, '4f9c08841532da5cfb48480dc602fefce9597f063f12b8a6191ebf23b38bf74d')
        upper = json.loads(upper_map.read_text())
        require(upper['lowerProducts']['sha256'] == pins[str(product_map)], 'Current 4f9 product-map lower authority differs.')
        native = ROOT / 'native-full-r6/receipt.json'
        pin(native, 'd19500908ae949676d9ef7cd9eeff6eec6b800f86046b510aa43b79538dca05c')
        native_record = json.loads(native.read_text())
        require(native_record['steps']['CADModeling']['exitCode'] == 0 and native_record['sourceSHA256'][MODEL_INPUT] == MODEL_SHA,
                'Actual current Native Modeling source authority differs.')
        for relative, expected in geometry['sourceSHA256'].items():
            require(native_record['sourceSHA256'][relative] == expected, 'Native/lower exact subset differs: ' + relative)
            pin(SOURCE / relative, expected)
        record['currentNativeSourceSubsetAuthority'] = {'path': str(native), 'sha256': pins[str(native)], 'scope': 'Exact Core/Geometry and one real Loft source subset only.'}
        record['currentProductMap'] = {'path': str(upper_map), 'sha256': pins[str(upper_map)], 'usedProducts': 'Core/Geometry only; no Topology/IR modules used.'}
        pin(HARNESS / 'native_tests.py')
        pin(Path(__file__))
        for relative, expected in geometry['toolSHA256'].items():
            pin(Path(phase['command'][0]).parent / relative, expected)
        for path, expected in geometry['wasmSDK']['metadataSHA256'].items():
            pin(Path(geometry['wasmSDK']['path']) / path, expected)
        pin(Path(geometry['nativeSDK']['path']) / 'SDKSettings.json', geometry['nativeSDK']['SDKSettings.json'])
        pin(geometry['nativeLinker']['path'], geometry['nativeLinker']['sha256'])
        pin(SOURCE / MODEL_INPUT, MODEL_SHA)
        model_source = output / 'snapshot' / MODEL_INPUT
        model_source.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(SOURCE / MODEL_INPUT, model_source)
        pin(model_source, MODEL_SHA)
        model_response = output / 'CADModelingSources.rsp'
        model_response.write_text('"' + str(model_source) + '"\n')
        pin(model_response)
        modules = output / 'modules'
        modules.mkdir()
        geometry_module = next(Path(path) for path in selected['compiledProductSHA256'] if Path(path).name == 'CADGeometry.swiftmodule')
        model_compile = selected['commands']['compile'][:]
        model_compile = [model_compile[0], '-I', str(geometry_module.parent)] + model_compile[1:]
        model_compile[model_compile.index('-module-name') + 1] = 'CADModeling'
        module_path = modules / 'CADModeling.swiftmodule'
        model_compile[model_compile.index('-emit-module-path') + 1] = str(module_path)
        model_products = [str(module_path)]
        if args.lane != 'embedded':
            model_object = modules / 'CADModeling.code.o'
            model_compile[model_compile.index('-o') + 1] = str(model_object)
            model_products.append(str(model_object))
        else:
            require('-emit-object' not in model_compile, 'Embedded accepted strategy must remain serialized module only.')
        model_compile[-1] = '@' + str(model_response)
        record['moduleSources'] = {'CADModeling': {MODEL_INPUT: MODEL_SHA}}
        record['modelProducts'] = model_products
        record['linkStrategy'] = 'Embedded serialized lower and Modeling modules; no Swift objects' if args.lane == 'embedded' else 'Actual lower and one-source Modeling modules and objects'
        copied = []
        for relative, expected in INPUTS.items():
            pin(SOURCE / relative, expected)
            destination = output / 'snapshot' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / relative, destination)
            pin(destination, expected)
            copied.append(str(destination))
        link = []
        replaced = 0
        for value in selected['commands']['link']:
            if value.endswith('/snapshot/Tests/OriginalQueryExecutionVerification/FullGeometryPortable.swift'):
                link.extend(copied)
                replaced += 1
            else:
                link.append(value)
        require(replaced == 1, 'Expected one original standalone client source in link command.')
        link = [link[0], '-I', str(modules)] + link[1:]
        if args.lane != 'embedded':
            link.insert(link.index('-o'), str(model_object))
        old_executable = selected['products'][-1]
        executable = output / ('LoftOwnership' if args.lane == 'asan' else 'LoftOwnership.wasm')
        link[link.index('-o') + 1] = str(executable)
        runtime = [str(executable) if item == old_executable else item for item in selected['commands']['runtime']]
        for item in runtime:
            if item.endswith('.mjs'):
                pin(item)
        runtime_tool = shutil.which(runtime[0]) if not Path(runtime[0]).is_absolute() else runtime[0]
        if args.lane != 'asan':
            require(runtime_tool is not None, 'Actual runtime executable missing.')
            pin(runtime_tool)
        prior = sum(item['elapsedSeconds'] for item in geometry['phases'] if item['name'] in [args.lane + '-core-compile', args.lane + '-compile'])
        record['priorCoreGeometryCompileSeconds'] = prior
        record['commands'] = {'CADModeling': model_compile, 'client-link': link, 'runtime': runtime}
        record['executable'] = str(executable)
        record['fixtureSHA256'] = INPUTS
        record['postflightDrift'] = verify()
        require(not record['postflightDrift'], 'Preparation input drift.')
        record['status'] = 'prepared-not-executed'
        save()
        print(json.dumps({'status': record['status'], 'plan': str(output / 'plan.json'), 'remainingCompileLinkSeconds': 1200 - prior}))
        return 0
    except Exception as error:
        record['status'] = 'preparation-failed'
        record['failure'] = str(error)
        record['postflightDrift'] = verify()
        save()
        raise


def execute(lane):
    output = BASE / lane
    plan_path = output / 'plan.json'
    record = json.loads(plan_path.read_text())
    require(record['status'] == 'prepared-not-executed', 'Only a prepared plan may start.')
    require(not (output / 'receipt.json').exists(), 'Preserve the existing actual run receipt.')
    pins = record['inputAndProductSHA256']
    pins[str(plan_path)] = digest(plan_path)
    def drift():
        return [path for path, expected in pins.items() if not Path(path).is_file() or digest(path) != expected]
    def pin(path):
        value = digest(path)
        require(str(path) not in pins or pins[str(path)] == value, 'Conflicting product or log hash.')
        pins[str(path)] = value
        return value
    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    require(not drift(), 'Preflight source/product/tool/plan drift.')
    try:
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        environment['PATH'] = str(Path(record['commands']['CADModeling'][0]).parent) + os.pathsep + environment.get('PATH', '')
        deadline = time.monotonic() + max(0, 1200 - record['priorCoreGeometryCompileSeconds'])
        record['status'] = 'running'
        save()
        for name, command in record['commands'].items():
            step = run(command, output / (name + '.log'), environment,
                       deadline=time.monotonic() + 120 if name == 'runtime' else deadline,
                       stage_limit=120 if name == 'runtime' else 1200)
            record['steps'][name] = step
            pin(output / (name + '.log'))
            if name == 'CADModeling' and step['exitCode'] == 0 and step['stopReason'] is None:
                record['compiledProductSHA256'] = {path: pin(path) for path in record['modelProducts']}
            if name == 'client-link' and step['exitCode'] == 0:
                record['executableSHA256'] = pin(record['executable'])
            save()
            require(step['exitCode'] == 0 and step['stopReason'] is None, name + ' failed; inspect the actual log.')
        observed = [line for line in (output / 'runtime.log').read_text().splitlines() if line.startswith('PASS ')]
        require(observed == EXPECTED, 'Actual Loft ownership output differs.')
        record['postflightDrift'] = drift()
        require(not record['postflightDrift'], 'Postflight input/product/log drift.')
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        save()
        print(json.dumps({'status': 'passed', 'lane': lane, 'oracles': len(observed), 'receipt': str(output / 'receipt.json')}))
        return 0
    except Exception as error:
        record['status'] = 'failed'
        record['failure'] = str(error)
        record['postflightDrift'] = drift()
        save()
        raise



if __name__ == '__main__':
    raise SystemExit(main())
