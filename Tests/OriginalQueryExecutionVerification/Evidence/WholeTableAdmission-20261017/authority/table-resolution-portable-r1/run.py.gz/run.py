#!/usr/bin/env python3
"""Run only the two actual TABLE files and shared checks on borrowed lower products."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import time

ROOT = Path(__file__).resolve().parent
PLAN_SHA = "8fa479797579f4b085447ed1c556f8ba5bc1bc3394ce2243fe95bc4a847dbb74"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--lane", choices=["asan", "wasm", "embedded"], required=True)
    parser.add_argument("--execute", action="store_true", help="Requires the Root-assigned compiler slot.")
    args = parser.parse_args()
    plan_path = ROOT / "plan.json"
    require(sha(plan_path) == PLAN_SHA, "The immutable TABLE plan changed.")
    plan = json.loads(plan_path.read_text())
    lane = plan["lanes"][args.lane]
    source_root = Path(plan["sourceRoot"])
    native = plan["nativeAuthority"]
    require(sha(native["path"]) == native["sha256"], "The accepted TABLE Native authority changed.")
    authority = json.loads(Path(native["path"]).read_text())
    lower = {p: h for p, h in authority["sourceSHA256"].items()
             if p.split("/")[1] in plan["lowerSourceCounts"]}
    require(len(lower) == 3198, "The whole lower-source premise changed.")
    prefix = lane["prefixReceipt"]
    require(sha(prefix["path"]) == prefix["sha256"], "The accepted target prefix changed.")
    target = json.loads(Path(prefix["path"]).read_text())
    require(target["status"] == "passed" and not target["postflightDrift"], "The lower target prefix was not accepted.")
    require(target["productionSourceSHA256"] == lower, "Target and TABLE Native lower sources differ.")
    pins = dict(lane["borrowedProductAndLogSHA256"])
    pins.update(plan["monitorSourceSHA256"])
    pins[native["path"]] = native["sha256"]
    pins[str(plan_path)] = PLAN_SHA
    pins[str(Path(__file__).resolve())] = sha(__file__)
    for p, h in lower.items():
        pins[str(source_root / p)] = h
    for item in plan["sourceFreeze"]["files"]:
        pins[str(source_root / item["path"])] = item["sha256"]
    compiler = Path(lane["commands"]["CADModeling"][0]).parent
    for name, h in lane["compilerToolSHA256"].items():
        pins[str(compiler / name)] = h

    def verify():
        return [p for p, h in pins.items() if not Path(p).is_file() or sha(p) != h]

    require(not verify(), "TABLE input/tool/SDK/product preflight failed.")
    if not args.execute:
        print(json.dumps({"status": "prepared", "lane": args.lane, "productionWholeFiles": 2,
                          "clientWholeFiles": 2, "lowerSourcesMatched": len(lower), "pins": len(pins)}))
        return
    monitor_path = next(p for p in plan["monitorSourceSHA256"] if p.endswith("/native_tests.py"))
    sys.path.insert(0, str(Path(monitor_path).parent))
    spec = importlib.util.spec_from_file_location("table_native_monitor", monitor_path)
    monitor = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(monitor)
    output = Path(lane["output"])
    output.mkdir(parents=True, exist_ok=False)
    (output / "modules").mkdir()
    for relative in plan["productionWholeFiles"] + plan["clientWholeFiles"]:
        destination = output / "snapshot" / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source_root / relative, destination)
        pins[str(destination)] = sha(source_root / relative)
    record = {"status": "running", "lane": args.lane, "scope": plan["scope"],
              "planSHA256": PLAN_SHA, "nativeAuthority": native, "prefixReceipt": prefix,
              "productionWholeFiles": plan["productionWholeFiles"],
              "fixtureSHA256": {p: sha(source_root / p) for p in plan["clientWholeFiles"]},
              "sourceRoot": str(source_root), "lowerSourceCounts": plan["lowerSourceCounts"],
              "lowerRegeneration": 0, "copiedLowerProducts": 0,
              "bounds": plan["bounds"], "expectedOutputLines": plan["expectedOutputLines"],
              "inputAndProductSHA256": pins, "steps": {}}

    def save():
        (output / "receipt.json").write_text(json.dumps(record, indent=2) + "\n")

    save()
    env = dict(os.environ)
    env.pop("TOOLCHAINS", None)
    env["PATH"] = str(compiler) + os.pathsep + env.get("PATH", "")
    env["ASAN_OPTIONS"] = "halt_on_error=1:abort_on_error=1"
    deadline = time.monotonic() + plan["bounds"]["compileLinkSeconds"]
    try:
        for name, command in lane["commands"].items():
            runtime = name == "runtime"
            step = monitor.run(command, output / (name + ".log"), env,
                               time.monotonic() + 120 if runtime else deadline,
                               120 if runtime else 1200)
            record["steps"][name] = step
            pins[str(output / (name + ".log"))] = step["logSHA256"]
            save()
            require(step["exitCode"] == 0 and step["stopReason"] is None, name + " failed; inspect actual log.")
            if name == "CADModeling":
                products = [output / "modules/CADModeling.swiftmodule"]
                if args.lane != "embedded":
                    products.append(output / "modules/CADModeling.code.o")
                record["compiledProductSHA256"] = {str(p): sha(p) for p in products}
                pins.update(record["compiledProductSHA256"])
            if name == "client-link":
                executable = command[command.index("-o") + 1]
                record["executable"] = executable
                record["executableSHA256"] = sha(executable)
                pins[executable] = record["executableSHA256"]
            save()
        actual = [s for s in (output / "runtime.log").read_text().splitlines() if s.startswith("PASS ")]
        require(actual == plan["expectedOutputLines"], "Actual TABLE output differs from the eight fixed oracles.")
        record["postflightDrift"] = verify()
        require(not record["postflightDrift"], "TABLE source/tool/SDK/product/log postflight drift.")
        record["status"] = "passed"
    except Exception as error:
        record["status"] = "failed"
        record["failure"] = str(error)
        record["postflightDrift"] = verify()
        save()
        raise
    save()
    print(json.dumps({"status": record["status"], "receipt": str(output / "receipt.json")}))


if __name__ == "__main__":
    main()
