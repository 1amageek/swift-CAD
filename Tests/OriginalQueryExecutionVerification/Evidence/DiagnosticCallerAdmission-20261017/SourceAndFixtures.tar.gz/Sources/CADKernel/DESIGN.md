# CADKernel

## Purpose and Scope

`CADKernel` owns deterministic document evaluation, immutable evaluated
snapshots, topology lookup, and derived Mesh orchestration. It is a child of
the [Swift-CAD package design](../../DESIGN.md). Its machining composition child
is [RollingBallFillet](RollingBallFillet/DESIGN.md).

## Responsibilities and Boundaries

The module owns deterministic document evaluation, including geometry-aware
tessellation preflight and emission, alongside the snapshot-scoped
implementation of `EvaluatedDocument.stableSubshapeReference(for:)` and
topology resolution from `StableSubshapeReference`. It does not define
analytic geometry, construct primitive topology, serialize signature values,
or publish Rupa project state. Tessellation consumes the generic
`TessellationOptions` and `TessellationLimits` values from `CADIR`; it does not
interpret viewport, camera, UI, Agent, or Product LOD policy.

[Product Attribute Resolution](ProductAttributeResolution/DESIGN.md) owns the
read-only composition of product source attachments with validated local/world
topology. It consumes explicit property relations and source provenance under
one caller budget; it introduces no target-specificity precedence or inferred
physical density.

`SweepEvaluationPlanService.orderedPathSegments` exposes the existing section-
anchored path ordering for read-only consumers. The supplied evaluated document
must match the supplied source document; this method performs no evaluation.
It uses the same section resolver, exact section plane and open-chain builder
as sweep planning. Missing sources, closed/disconnected paths and unsupported
section planes remain typed failures. Placement measurements consume these
oriented segments so fractional lengths follow the constructed end of a sweep.
Core's placed sweep tests own the cross-package ordering/measurement check.

Sweep construction preflight consumes the original face loop and directed edge
source from `ResolvedModelingSection.face` through the
[Section Resolution](../CADModeling/SectionResolution/DESIGN.md) contract and
`ExactBSplineCurveSpanBuilder.loopSpans(from:section)`. Face and profile sections
retain closed-region and exact source-plane policy; curve sections retain their
authored open/closed flag. Face references require their evaluated source feature
in the same supplied snapshot and tolerance. A profile facade or a legacy Profile
conversion does not replace face source authority during construction admission. One sweep planning invocation owns one existing `CurvedSweepSourceBudget`: original span admission, certified curved open/closed paths, twist admission and face-section resolution share that same owner. Throws propagate through the same allowance, and a phase does not create a fresh proof budget. Mitred construction retains its explicit lower-port accounting gap until its actual producer accepts this admission; the composition does not claim whole-ledger completion from an outer debit.

`SketchCurveIntersector` is the public sketch curve intersection. It converts
each `SketchCurveGeometry2D` (line, circle, arc, cubic Bezier chain) to its exact
rational B-spline, intersects the pair with the certified two-dimensional curve
intersector and reports every root once with both curves' natural parameters:
the line fraction, the polar angle, or the chain parameter profile extraction
uses. Each root is refined by Newton steps confined to its certified enclosure,
which holds exactly one root; a step leaving it or a singular (tangent) Jacobian
keeps the certified midpoint. The second curve may reach its unbounded line or
full circle; a chain has no extension and is refused as an unsupported
capability. A root the proof budget (depth 32, 16,384 cells) cannot certify, such
as an inexact tangency or an overlap, is a typed `resourceLimitExceeded`
failure, and invalid geometry is `invalidInput`. `SketchCurveIntersectorTests`
own the parameters, reach, dedup and failure contracts; RupaCore Cut Curve tests
own the command-level cuts.

`SketchCurveProjector` is the public nearest point on a sketch curve, reported in
the intersector's natural parameters so a caller converts a projection and an
intersection alike. A line projects in closed form clamped to its ends; a circle
along the ray from its center; an arc along that ray while it crosses the arc,
otherwise at its nearer end. Each span of a cubic Bezier chain starts from its
nearest of 65 samples and converges by clamped Newton steps on
(B(t) − p) · B′(t) = 0, and the nearest of the spans' feet and ends is reported.
Non-finite input, a line no longer than the modeling distance and a radius at or
below it are `invalidInput`. `SketchCurveProjectorTests` own the line, circle,
arc-end, chain-foot and failure cases; RupaCore Trim and Split Segment consume it.

`SketchSplineCurve` is a sketch spline's exact planar geometry for any degree and
knots ([Sketch spline form](../CADIR/DESIGN.md#sketch-spline-form)): its clamped
`BSplineCurve2D` and its Bezier segments with their parameter intervals, a chain
being its own segments and explicit knots being decomposed by inserting every
interior knot up to multiplicity `degree`. Everything that reads a spline other
than a cubic chain goes through it: `SketchCurveExtractor` and
`SketchProfileExtractor` build the evaluated curve and the profile B-spline on the
spline's own knots and flatten it with `SketchSplineTessellator` (de Casteljau
halving until each segment's interior points lie within the modeling distance of
its chord), while a cubic chain keeps `CubicBezierSplineTessellator` and so its
exact earlier samples. `SketchCurveGeometry2D.sketchSpline` carries it to the
projector and the intersector with the B-spline parameter as its natural
parameter. `SketchCurveSampler.splineSamples(for:)`, `splineSample(for:parameter:)` and
`splineSegmentSample(for:segmentIndex:t:)`
sample it with the parameter normalized over the knot domain, the convention a
cubic chain already uses, and `turnBoundedSplineSamples` halves every step whose
tangents turn by more than a bound, so a curvature comb follows a tight bend.
The solver reads spline ends through the clamped end derivatives and holds
`smoothSplineEndpoints` to equal curvature vectors (true G2; it held equal handle
lengths before). `SketchSplineFormTests`, `SketchSplineCurveTests` and
`SketchSplineConstraintSolverTests` own these.

`SketchSplineCurve.degreeElevated(tolerance:)` raises a sketch spline's degree by one
exactly: every Bezier segment is elevated (Qᵢ = i/(n+1)·Pᵢ₋₁ + (1 − i/(n+1))·Pᵢ) and
the segments are joined at their parameter breaks with knots of multiplicity n + 1,
so shape and parameter are unchanged and a former smooth knot becomes a joint.
`SketchSplineDegreeElevationTests` own it.

`SketchSplineLeastSquaresFit.fit(_:degree:controlPointCount:shapeWeight:)` refits
a sketch spline as a clamped uniform B-spline of any degree with a chosen number
of control points (Rebuild's Points and Explicit Control), at most
`maximumControlPointCount`: the original is sampled on every knot span of its
own, however narrow (an even share of the samples per span, at least eight), the
samples take chord-length parameters, the ends
are the original's ends and the interior points solve by Cholesky the normal
equations of `shapeWeight` times the mean squared distance to the samples plus
`1 − shapeWeight` times the mean squared second difference of the control
points (1 is plain least squares, 0 the evenest polygon on the chord); a weight
outside 0...1 or an underdetermined system is `invalidInput`. The deviation
reported is the largest distance from the original to the fit by exact
projection, found span by span of the original: each span sampled a few times
per fitted span its chord covers, and each sampled local maximum refined by
golden-section search unless it cannot beat the largest found — the distance
rises between samples no faster than the original moves, which the derivative's
control points bound on a non-rational span. Even sampling of the whole domain
missed features on narrow spans and reported them fitted
(`aNarrowKnotSpanIsNeitherFittedBlindNorPassedUnchecked`). The same search runs back from the fit
to the original, span by span of the fit, and the larger distance is reported (its
place on the original is the foot of the fit's worst point): measured one way only,
a fit that strays where the original does not reach reported less than it strays
(`theDeviationCountsWhereTheFitStraysFromTheOriginal`).
`refit(_:deviation:keepsCorners:)` (Rebuild's Refit) takes the fewest cubic
control points, by doubling and then bisecting up to `maximumControlPointCount`
(`resourceLimitExceeded` beyond), whose fit stays within the deviation; with
corners kept, the original is trimmed at `cornerParameters(of:)` — knots of
multiplicity at least the degree whose control-polygon legs turn by more than
`cornerAngle` — and the refitted pieces are joined on [0, 1] with knots of
multiplicity three, so every corner stays at its point and sharp while the side
tangents follow within the deviation.
`SketchSplineLeastSquaresFitTests` own it.

`CubicBezierChainJoints.mergedSpan(of:atJoint:)` says whether the two spans that
meet at a chain joint are the halves of one cubic, and returns it: halves of Q
split at t meet with collinear handles in the ratio t : 1 − t, so t is read from
the joint's handles, Q's inner points follow from the outer handles, and Q split
at t must give back all seven points within the modeling distance. Any other
joint (a kink, a bend, a zero handle) is nil; a chain without that joint or with
non-finite points is `invalidInput`. `CubicBezierChainJointsTests` own these;
RupaCore's Delete Redundant Topology consumes it.

`CubicBezierChainExtension.naturalSpan(of:at:length:)` is Extend Curve's Natural
shape on a chain: the end span's own cubic continued past the end as one new
span, whose control points are the blossom values f(1,1,1), f(1,1,s), f(1,s,s),
f(s,s,s) of the end span, with s solving ∫₁ˢ |B′(u)| du = length by Newton steps on
the arc length (composite five-point Gauss–Legendre). The start end is the same
on the reversed span. A degenerate end tangent, a length not above the modeling
distance, a malformed chain or a length not reached is `invalidInput`.
`naturalSpan(ofSegment:at:length:)` does the same for an end Bezier segment of any
degree n, its n new points the blossoms f(1…1, s…s), so a sketch spline of any
degree and knots is continued on its own polynomial.
`CubicBezierChainExtensionTests` check it against the known pieces of one cubic
and one quintic.
Extend Curve's Arc, Soft and Reflective shapes are CADCore's
`CurvatureProfileExtension` and `BezierShapedExtension` (see
[CADCore](../CADCore/DESIGN.md#shaped-bezier-extension-contract)), so the
persisted expression and the kernel evaluate one implementation.
`CurvatureProfileExtensionTests` stay here and exercise it through CADKernel.

`CubicBezierChainOffset.offset(of:distance:)` offsets a chain to its left (the
tangent turned counterclockwise; a negative distance goes right) as a cubic chain
within the modeling distance: each span's offset O = B + d·N is fitted by cubic
Hermite pieces taking O and its exact derivative O′ = B′ + d·N′ at their ends, and
a piece whose eight interior samples stray further than the modeling distance is
halved. A fold (O′ turning against B′ where d·κ reaches 1), a span without a
tangent and a corner joint (whose offsets do not meet) without a gap fill are
`invalidInput`. With a gap fill (`offset(of:distance:gapFill:)`), spans whose
offsets meet form runs, and at each corner the two runs' offsets are intersected
by `SketchCurveIntersector`: where they cross both end at the crossing (the inside
of a turn), and where they part the `.round` fill is an arc about the corner at
the distance (cubic spans checked against the circle to the modeling distance)
the `.linear` fill their end tangents continued until they meet (refused if
parallel or meeting behind), and the `.natural` fill the tail's last cubic and the
head's first continued along their own polynomials (exact Hermite forms over
intervals past the ends, reaching up to 0.5, 1, 2, 4 and 8 span lengths in turn)
until they meet, refused when they do not. A closed chain stays closed; a closed chain of one
run joins its seam by intersecting its last third with its first third.
`offset(of: SketchSplineCurve, distance:gapFill:)` offsets a sketch spline of any
degree and knots the same way over its own Bezier segments (B, B′ and B″ by de
Casteljau on the points and their differences), so a spline is never offset as
the cubic chain its control points would make; the result is still a cubic chain.
`offset(spans:distance:gapFill:)` offsets consecutive Bezier spans of any degrees
(a line a two-point span), so a joined chain of lines, arcs and splines offsets as
one curve; `CubicBezierArcApproximation.chain` gives an arc as cubic spans with
4/3·tan(θ/4) handles, the fewest (up to 64) within the modeling distance.
`CubicBezierChainOffsetTests`, `CubicBezierChainOffsetGapFillTests` and
`NaturalGapFillAndArcChainTests` own these; RupaCore's Offset Planar Curve on
splines and joined chains consumes them.

`SurfaceQueryEvaluator.outwardFrame` returns a face point (the nearest point to
a query, or the point at a surface parameter) with the face's outward normal:
the surface normal oriented by the face's sense in its shell. Face orientation
is owned here; applications ask instead of reading `Face.orientation`.
`SurfaceOutwardFrameTests` prove every box face points out of the body.

`FaceUVNChart` is a face's UVN frame for Deform and Wrap: a point reads as its
nearest support-surface parameters (not clamped to the trim) normalized over the
face's own parameter extent (0 and 1 at its sides; a periodic parameter is
unwrapped to the extent's turn) and its signed height along the outward normal;
a coordinate places back at those parameters and height, and fails
(`invalidInput`) where a bounded support surface has no such parameters. It reads
any `SurfaceQueryModel` (an evaluated document, or an evaluation context while a
feature runs). The extent is CADTopology's `FaceParameterExtentResolver`: the
certified enclosures of the trimming curves, refined only where they overhang
points the curves reach until the overhang is a ten-millionth of the width, so it
holds every trimming curve and is the trim's own box; the certified
`DefaultFaceParameterBoundsResolver` stops at quarter-unit enclosures, which may
overhang by half a curve's span. (A polyline pcurve's enclosure bounds each
coordinate's speed by its own largest share of a segment, so a side running along
one parameter no longer spreads across the other.) `FaceParameterExtentResolverTests`
own the extent.
CADKernel consumes the sampled spatial curve fitting contract owned by
[CADModeling](../CADModeling/DESIGN.md#spatial-curve-fitting).
`FaceUVNChartTests` owns the kernel's face-chart behavior; fitter behavior is
verified in CADModeling's test target.

`SurfaceQueryEvaluator.project(_:along:onto:)` chooses, among the line's meetings
with the support surface in the requested range, only those inside the face's
trim when `respectsTrimBounds` (the default), for every surface kind: B-spline and
procedural faces through the face containment session, cylinders and non-planar
analytic surfaces the same way (`trimContainedDistances`), planes through their
straight-edged trim domain or, when a trim edge is curved (a disc), the containment
session in the surface's own parameters (`requireInsideFaceTrim`). A line meeting a sphere or cylinder twice therefore never lands on
the part of the support the face does not cover. `DirectionalProjectionTrimTests`
own this.

Original affine operation-word curve and surface queries retain the original
source and its factor sequence through the general closest/directional
producers. Control-point queries retain original native B-spline index, knots
and spans and apply the word only to the requested numerical value; conic-center
queries likewise transform the retained original center. A rounded transformed
control net never replaces query source authority. Existing convenience-query
policy gains no new hidden ceiling; bounded image/service callers retain their
explicit original invocation ledgers and lower failure contracts.

Original endpoint connector queries use the same complete original closest and
directional producers. Control-point, knot, span and exact-center shortcuts
cannot promote the connector construction spline into the corrected source law.

`BodySectionCurveEvaluator.sections(between:and:in:)` is where two bodies' faces
meet: the Boolean pipeline's union intersection graph (disjoint bodies give no face
pair) split and trimmed to both faces by its UV split graph, as curve pieces: a
transverse segment as a line, a closed intersection over its period or closed
domain, a trimmed chain segment over its parameters; tangent points and coincident
areas give none. `BodySectionCurveEvaluatorTests` own it.

`PlanarCurveExtrusionIntersector.trace(first:second:)` is where two planar curves'
extrusions (each along its plane's normal) meet, the curve projecting onto both
(Project Curve Curve): over the first curve's parameter it is P₁(w) + s·n₁ with its
projection on the second plane on the second curve. The trace starts on the second
curve's first crossing (in its parameter) at the first curve's lower end and follows
that branch by continuation over 256 steps; `point(at:)` solves by Newton from the
nearest step. Parallel planes and a first curve whose extrusion leaves the second's
partway fail. `PlanarCurveExtrusionIntersectorTests` own it.

## Related Designs

| Design | Relationship | Contract Used | Summary | Cautions |
|---|---|---|---|---|
| [Evaluated Document](EvaluatedDocument/DESIGN.md) | child | complete evaluated snapshot value and native codec | Retains every source/cache/assembly and exact receipt owner for actual consumers | Source decomposition preserves fields, defaults and native validation; Embedded retains the same value contract. |
| [Original Boundary Clipping](OriginalBoundaryClipping/DESIGN.md) | child | Immutable original face boundary issuance and parameter clipping | Binds validated face/support and directed coedges to one retained Native raw receipt | Parameter output retains its original model; complete image/fiber clipping and other boundary families remain separate acceptance |
| [Swift-CAD package](../../DESIGN.md) | parent | immutable exact evaluation | Defines kernel composition and Mesh separation. | Do not re-evaluate during a read. |
| [Whole Body Boolean](WholeBodyBoolean/DESIGN.md) | child | complete non-crossing operand selection and coincident representative ancestry | Composes original material and complete trim correspondence into one sewing request. | Vertex-only agreement is not whole coincidence. |
| [CADIR](../CADIR/DESIGN.md) | depends on | complete stable signature value | Provides validated reference values. | Every topology entry is eligible for a reference. |
| [CADModeling](../CADModeling/DESIGN.md) | depends on | exact generated B-rep | Supplies source topology and lineage. | Seam/pole topology remains present. |
| [Assembly Evaluation](AssemblyEvaluation/DESIGN.md) | child | retained local base, placed world topology and occurrence correspondence | Composes local feature evaluation with assembly source placement. | Incremental rollback uses local geometry; final indexes and meshes use world geometry. |
| [Product Attribute Resolution](ProductAttributeResolution/DESIGN.md) | child | immutable resolved properties, source chains and local/world target maps | Resolves CADIR-owned product attachments across every selected-definition occurrence of common geometry. | Retained exact source/cache/assembly correspondence must match; explicit override provenance follows the child contract. |
| [Rectangular B-spline Mesh](RectangularBSplineMesh/DESIGN.md) | child | original native rectangular basis and adaptive fidelity | Owns basis admission and selected-panel composition for the public tessellator. | Checked cumulative limits and cancellation remain in MeshTessellator; curved trims belong to separate contracts. |
| [RollingBallFillet](RollingBallFillet/DESIGN.md) | child | complete solid sewing request | Composes native source-face arrangements and blend boundaries. | A request is not a validated or publishable result. |
| [RectangularBSplineMesh](RectangularBSplineMesh/DESIGN.md) | child | original nonperiodic nonclamped rectangle admission and emission | Owns selected-panel mesh fidelity, compatible grids and retained face provenance. | Uses Geometry's original span authority; clamped routes remain unchanged. |
| [OriginalGraphBandMesh](OriginalGraphBandMesh/DESIGN.md) | child | source-bound correspondence and complete original reference-facet admission | Owns bounded graph-band topology binding, checked retained grids and mesh publication. | Actual Draft admission and public coverage remain required; lower receipts alone do not complete the mesh path. |
| [RupaCore](../../../RupaKit/Sources/RupaCore/DESIGN.md) | used by | evaluated body and Mesh measurements; edge queries; sketch curve intersections | Consumes the same snapshot outputs and certified sketch intersections. | Volume authority stays in exact B-rep; Core computes no intersection itself. |

The bounded graph-band branch retains its checked plan from preflight through
emission. Candidate chain labels are not proof: publication uses the child
receipts and preserves original selected normals under the existing face/shell
orientation sign. Its full contract belongs to the linked child design.

## Architecture

```mermaid
flowchart LR
    Document["CADDocument"] --> Evaluate["DocumentEvaluator"]
    Evaluate --> Snapshot["EvaluatedDocument"]
    Snapshot --> Lookup["Topology lookup"]
    Lookup --> Builder["Complete signature builder"]
    Builder --> Reference["Validated StableSubshapeReference"]
    Options["TessellationOptions\nfidelity"] --> Preflight["Checked geometry preflight"]
    Limits["TessellationLimits\nresource admission"] --> Preflight
    Preflight --> Emit["All-or-nothing Mesh emission"]
    Emit --> Snapshot
```

## Contracts and Invariants

Exact evaluation may intentionally defer caches and meshes. A successful native
evaluator retains its validated immutable source association alongside its exact
B-rep certificate; product attribute resolution consumes that producer-owned
association when no cache exists. Caller-constructed/decoded snapshots do not
acquire this authority merely by storing matching identifiers. Materialized
cache validation retains its existing contract. Assembly local/world validation
remains the assembly owner's separate contract.

Face arrangement accepts an explicit source-contact tolerance. Machining
supplies the modeling tolerance unchanged for crossing detection, source-edge
subdivision and junction matching. The existing Boolean default retains its
recovered-contact policy; this is not an implicit machining allowance. An
explicit policy must retain angle/relative tolerances and cannot demand a
distance stricter than the arrangement's input contract.

Two intersection edges on one face whose other supports are one surface (one
intersection curve split where that surface's faces meet, as a drilled
cylinder's wall crossing another cylinder's halves) lie on each other's support
all along, so they cross only where they end (`ExactTrimEdgeIntersector`;
`CrossedCylindersTests` own it with the drill's seam turned 0, 45 and 90
degrees).

An intersection curve may touch a face's boundary edge without entering the
neighbouring face (two equal cylinders in a tee touch on the line between the
upright's halves). The neighbour is carried whole, so
`ClosedIntersectionUnsplitFaceMaterializer` cuts each carried edge at the split
patches' vertices lying inside it, matching the split face's copy of the shared
edge (`CrossedCylindersTests`: equal tee and cross; a pipe half sunk in a box
face, joined or grooved).

Implicit contact/isoparametric crossing classification first uses the existing
whole-interval UV jet to exclude separated coordinate ranges, retaining the
same parameter-overlap resolution. An overlapping range is not admitted as a
crossing: endpoint monotonicity or the existing general intersector must prove
the result. This avoids constructing a 3D ruled search for disjoint boundaries.
The chart-preserving offset image is validated before its native UV certificate
is used. NativeTrimCrossingTests owns separation and endpoint regressions.

Certified straight twist preflight and evaluation use the same
[CertifiedTwist admission](../CADModeling/CertifiedTwist/DESIGN.md). Exact BRep
validation certifies the represented spline topology, not zero deviation from
the ideal rotation law; that deviation has a separate operation allowance.

Per-feature tessellation overrides use live body subshape ownership, never derived
topology IDs. They change only mesh generation. The complete option set participates
in cache identity; tessellation reserves prior bodies' usage before the next body.
Tests must show changed subdivision with identical exact geometry, independent
body quality, and cumulative resource refusal.

### Historical first rectangular adaptive admission

The following records the first bounded M1 implementation and its original
verification scope. Its old family refusals are superseded by the later
selected C0, double-periodic and periodic-C0 contracts below. Current M1
composition and remaining family boundaries are owned by
[Rectangular B-spline Mesh](RectangularBSplineMesh/DESIGN.md);
[Original Graph-band Mesh](OriginalGraphBandMesh/DESIGN.md) separately owns M2.

The bounded M1 rectangular B-spline grid admits positive-weight supports with
clamped C1 axes or one validated original periodic C1 axis and one clamped C1
axis; original internal knot multiplicities prove continuity. The geometry-owned original differential enclosure must
certify finite regular tangent/Hessian and unit-normal derivative bounds over
the complete retained rectangle. Mesh preflight selects anisotropic grid counts
from those bounds and retains the exact grid for emission; position tolerance,
normal-path angular tolerance and every triangle edge, including diagonals,
must satisfy the original options simultaneously. Hessian and normal derivative
bounds drive curvature-dependent refinement; point samples do not authorize
fidelity. The existing checked cumulative storage/count reservation, actual
emission charging, face provenance and upper cooperative cancellation contract
remain authoritative. No new lower-proof cancellation response-time guarantee
or private budget is introduced. The first bounded route refused periodic C0, nonclamped C0, double-periodic
and unproved regularity. Later selected-native contracts replace those family
refusals only where their own evidence applies. Trimmed interiors, adjacent-face
agreement and full M1 retain separate proof obligations.
The bounded periodic M1 extension admits exactly one periodic axis with validated
original-cycle C1 continuity; the other axis remains clamped C1. Periodic
B-spline rectangle admission uses original constant-U/V coedges with their
actual use orientation. Exact unwrapped UV endpoints must connect, four
alternating monotone sides must cover equal opposite ranges, and each side may
contain multiple original edges. The exact represented-endpoint periodic width is positive and no larger
than the original period. At rounded width equality, an error-free
TwoDifference residual rejects hidden excess without a numeric allowance. No sampled agreement or nearest-period unwrap chooses
the rectangle. Existing analytic-cylinder dispatch retains its contract.

| Stage | Assumption | Guarantee |
|---|---|---|
| Rectangle admission | Original oriented constant-coordinate coedges and exact unwrapped endpoint connectivity | Retained full rectangle, including split sides and seam-crossing native coordinates |
| Periodic admission | Existing validated repeated homogeneous controls, translated original knots and original-cycle C1 including the seam | Continuous original first derivatives; no assertion of second-derivative continuity |
| Geometry bound | Existing prepared original cycle cover certifies finite regular tangent/Hessian/normal bounds on that rectangle | The unchanged adaptive whole-triangle fidelity contract may consume those bounds |
| Preflight/emission | Same retained original rectangle and grid, checked cumulative budget | Face provenance and exact original inputs survive success, refusal and cancellation |

The independent degree-two cycle uses knots `[0,1,2,3,4]`, unit weights
and independent controls `(1,0),(0,1),(-1,0),(0,-1)`, extruded in a clamped
linear axis from z=0 to z=1. Its first span is
`C(t)=(1/2-t,1/2+t-t*t)`, with the remaining spans related by 90-degree
rotation. On the upper span, `y=3/4-x*x` and the unit normal is
`normalize(2*x,1,0)`. This literal geometry, not a production evaluator, owns
position, vertex/triangle normal and all-edge-length tests. Four-coedge
`3.5..4.5` and valid six-coedge `0..4` rectangles verify seam crossing,
full-period split sides, both axis roles, retained FaceRuns and extraction.
C0 seams, unconnected raw charts, period excess and unproved regularity must
fail explicitly. Cumulative count/byte/reservation and cancellation tests retain
the existing owner and original-input assertions. Double-periodic, C0 and
arbitrary trimmed charts remain full-M1/M2 gaps. Native owner verification passes all37 declarations across the four original
tessellation suites, including the periodic public fixtures and exact-width
refusal. Matching portable and full-M1/M2 closure remain separately required.

Independent tests measure triangle interior and edge deviations against literal
`S=(u,v,A*u*u)` and `S=(u,v,A*u*v)`, and normal angles against
`(-2*A*u,0,1)/sqrt(1+4*A*A*u*u)`. Changing only curvature, linear tolerance or
angular tolerance must change refinement while preserving exact B-rep input.
All triangle edges, original invocation budgets/reservations and existing
procedural fidelity regressions verify any shared grid-policy change.

1. Stable-reference creation uses the current immutable `EvaluatedDocument` and
   its topology map, lineage, and tolerance. It creates one complete signature
   and validates it before returning.
2. Faces, edges, vertices, bodies, periodic seams, and pole endpoints are not
   omitted or replaced with identity-only placeholders.
3. Topology resolution verifies the retained signature against the target
   model and returns typed failure for stale, missing, or mismatched topology.
4. Evaluation is reused for all reads in one operation; stable-reference
   creation never creates a second project/evaluation authority.
5. `MeshTessellator` performs a conservative checked geometry-aware estimate
   before reserving output storage. Cumulative vertex, index, triangle, and
   estimated byte limits are charged across the entire tessellation invocation,
   not only one face. Emission also charges actual usage before each output
   growth. Overflow and limit excess therefore fail before the allocation or
   growth they would exceed. A parametric face's grid cell emits both its triangles; one with
   no area (three of the cell's corners on one line, at a straight corner of the face) is left
   out since the other covers the cell, while a cell with neither fails the face.
6. Preflight and emission check cooperative cancellation at document, body,
   face, and bounded inner-loop checkpoints. Emission is all-or-nothing: a
   failed or cancelled invocation returns no Mesh map and cannot publish a
   partial evaluated document.
7. An incremental evaluation finalizes its B-rep through the exact per-body
   certificates it carried forward. When no rollback or rebuilt feature touched
   the model (a revision- or envelope-only change, or a document equal to the
   previous one), `BRepEditBuffer` returns the previous validated model itself
   instead of re-extracting and recomposing every body; any delta or replacement
   drops that baseline, so a changed model is always composed.
   `DocumentEvaluatorIncrementalTests` compares both paths with full evaluation.
   Exact B-rep incremental reuse is independent of tessellation fidelity and
   mesh artifact purpose. The exact evaluator reuses only compatible
   source/evaluator/modeling state. Mesh reuse is a separate admission step for
   each unchanged body: its cache metadata, complete fidelity configuration,
   purpose, recorded usage, and current limits must be accepted before the mesh
   enters the new result. A purpose or fidelity mismatch in `evaluate(reusing:)`
   is a cache miss, never an evaluation failure: the exact B-rep remains
   reusable, but that body is re-tessellated under the requested purpose and
   fidelity. The old artifact is never relabeled. Because a `MeshCache` records
   the whole `TessellationOptions` it was produced under, including its
   per-feature overrides, changing the fidelity of one feature re-tessellates
   every body while rebuilding no feature. A compatible
   artifact whose usage exceeds current limits is a typed
   `TessellationError.resourceExhausted`, matching fresh tessellation. The
   standalone `DocumentCaches.validateFreshness` contract retains typed purpose
   mismatch refusal for callers validating an artifact table directly.
   `DocumentEvaluationConfiguration` carries purpose and limits into every
   newly materialized `MeshCache`. `CADIR` owns the cache-boundary value
   contract; see `Sources/CADIR/DESIGN.md`.
   Admission of an unchanged body's artifact first checks the previous
   original source, its cache metadata and the exact retained mesh, then the
   current fidelity, purpose and limits. Immutable invocations own independent
   proof and storage ledgers; original body, face, use and station traversal is
   deterministic under the same backend. Parallel calls share no mutable plans
   and retain the same synchronization contract. Sequential per-document body
   reservation owns cumulative limits. Numerical reproducibility across
   backends requires separate target verification.

8. An `ImportedBRepFeature` retains its exchange IDs as source data, but the
   evaluator re-identifies every body, shell, face, loop, edge, vertex, curve,
   and surface with the importing feature's deterministic topology namespace
   before it enters the document B-rep. The remapped model is merged with the
   evaluation context using the same duplicate-rejecting combiner as primitive
   features. This preserves existing independent bodies in both incremental
   and non-incremental evaluation, permits the same exact source to be
   imported more than once, and keeps re-evaluation IDs stable for cache and
   delta reuse.
9. `MeshTessellator` records the generating face of every triangle it emits in
   `Mesh.faceRuns`. A run is appended for each face that emitted at least one
   triangle, in the body's `shellIDs` then `faceIDs` traversal order, so the
   runs partition the emitted triangles in emission order. Index compaction
   preserves triangle count and order, so it carries the runs unchanged. A
   body extracted for incremental re-tessellation copies its shells verbatim,
   so a reused mesh and a freshly tessellated one record the same runs and stay
   equal. `CADIR` owns the run value contract; see `Sources/CADIR/DESIGN.md`.

### Implemented Admission Mechanism

Face admission retains its rectangular grid bounds and certified step counts
alongside existing planar boundary preparation. Emission consumes this same
request-local preparation for the immutable model/options; it never repeats
the interval proof or independently chooses a new grid. The preparation is
released with the invocation and is not a persistent cache. Actual output
growth is still charged against the admitted budget.

Rolling-ball surfaces use the existing certified procedural-surface grid
admission in both preflight and emission. Their retained contact rails supply
the differential bounds; tessellation does not replace them with planar or
analytic approximations. Failure to certify bounds remains a typed failure.
Integration verification must cover a retained rolling-ball surface, mesh
fidelity and budget refusal; geometry-only evaluation is insufficient.
Closest-point queries reuse the bounded procedural projector. Cache identity
includes the entire encoded blend, including all rails and construction
tolerance, through the existing canonical encoding signature function.

Sewing connectivity compares endpoint-slot pairs before loading full edge uses.
The request-local slot table owns points; curve and pcurve values are read only
for endpoint-compatible candidates. Pair ordering, endpoint tolerance, exact
curve-span proof and union ordering remain unchanged. Storage is O(n) and the
pair scan remains O(n²); this removes repeated large-value copies, not the
quadratic search. Existing sewing success/refusal tests and the complete gear
path verify the change; phase timing separates sewing/evaluation from meshing.

### Canonical Sewer Execution Binding

`DefaultBRepSewer` supplies the actual direct `BRepSewing` witness. Its ordinary
entry creates one original query execution and delegates to the same assembly
body. Request validation, source edge-kind and complete curve-span proofs,
implicit component/pcurve transfer, endpoint union traversal and final exact
B-rep validation borrow that execution. Final validation retains its original
source-depth 16, subdivision 32 and algebra 32 ceilings, intersected with the
caller. The main stable ordering, endpoint slots, disjoint-set union/rank law,
face/coedge construction, manifold checks and issued parent lineage remain
unchanged; no independent canonical-parent initializer or new lineage solver is
introduced. Endpoint distance remains the explicit sewing acceptance policy,
not evidence of original intersection or transitive geometric identity. Complete
source span proof is still required before distinct edges share topology.
This finite witness binding does not complete all sewing families or redefine
intersection authority. Existing sewing success/refusal and same-execution
budget/cancellation fixtures own behavioral verification after module integration.

Planar boundary simplification retains an invocation-local circular index list.
Removing a point invalidates only its two neighbors' chord checks; traversal
returns to the previous neighbor instead of restarting at the loop origin.
Every replacement chord still checks all covered original samples against the
same deviation allowance. Storage is O(n); this removes index-array shifts
and unconditional prefix rescans, but does not claim linear runtime for
covered-sample checks. Cancellation is checked
at candidate and bounded covered-sample checkpoints. The complete 32-tooth
involute double-helical kernel test exercises this path without loosening
geometry or tessellation tolerances.

For nonperiodic surfaces, a four-edge parameter rectangle made of constant-U/V
curves has its extrema at the eight edge endpoints. Rectangle bounds evaluate
those endpoints directly, without tessellating spatial boundary curves. Periodic
surfaces retain sampled unwrapping; this optimization must not alter seam choice
or interpret a full-period edge as a zero-length interval.

Ear clipping resumes at the removed ear's previous neighbor rather than the
first polygon vertex. Every candidate still checks all surviving points using
the original geometric predicates; a full unsuccessful cycle remains a typed
failure. Each clipping iteration checks cancellation.

Ear containment uses robust orientation signs with zero determinant tolerance:
topological membership must not expand the triangle by a modeling-distance
band, which can reject every ear of a finely sampled concave boundary.
Exact boundary points still block an ear; indeterminate arithmetic throws
instead of accepting a triangle. Geometric degeneracy gates remain separate.
The exact coordinate bounding box rejects points before robust orientation
evaluation. Its bounds use only min/max of the same stored triangle vertices,
so it cannot discard an interior or boundary point and needs no tolerance.

Before each ear is sought, the tip of a spike leaves the polygon without a
triangle: the boundary doubles back there along a sliver narrower than the
modeling resolution, its turn lies within the same gate ear adoption and
`appendTriangle` apply, and removing it changes the polygon by less than the
resolution. Exact containment can accept an ear whose edge passes a vertex by a
rounding residue (an arc-line intersection a few ulps off the line), leaving
such a spike; kept, it ended among the last three vertices as a triangle the
adoption gate refused, failing the face. A vertex the boundary passes straight
through stays, because triangles already clipped may use it and removing it
would leave a T-junction. The same residue can leave the last three vertices
without area at the resolution, in the plane or on the surface; that sliver is
not emitted, and a face whose every triangle is such a sliver still fails. The
cylindrical union tests exercise the spike, the concave extrude test the
pass-through, and Rupa's trimmed-sheet automation test the last sliver.

Limits reach the tessellator through `MeshTessellator.init(tolerance:limits:)`,
defaulting to `TessellationLimits.standard`, and through
`DocumentEvaluator.init(tessellationLimits:)`, which configures only the
tessellator the evaluator constructs; an injected `Tessellating` owns whichever
initializer limits it was built with. `Tessellating` retains its existing
requirements and adds a request overload carrying `limits` and `reserving`.
The default overload validates that request and dispatches to the existing
requirement, preserving source compatibility for legacy conformers. The
production `MeshTessellator` lowers its initializer ceiling with the request
ceiling and seeds both preflight and emission budgets with the reserved usage.
`TessellationBudget` charges an invocation and rejects a charge on the first
dimension it would exceed, leaving every counter unchanged so a refused charge
cannot partially advance the budget.

The conservative per-face estimate is exact for a rectangular parametric grid
face, which emits `(u + 1)(v + 1)` vertices and `6uv` indices for the step
counts `parametricGridStepCounts` returns. A boundary-driven face — planar,
planar with holes, or trimmed parametric — with `n` sampled boundary points and
`h` holes emits at most `n + 2h + 1` vertices and `3(n + 2h)` indices, because
bridging a hole into the outer loop duplicates at most two boundary points and a
fan triangulation adds at most one interior point.

Convex trimmed spherical patches instead interpolate radial rings from a physical
interior point to the unchanged sampled boundary. Their center is computed in
physical space, not by averaging longitude across a pole or seam. With `k` radial
steps and `n` boundary samples, admission reserves `nk + 1` vertices and
`3n(2k - 1)` indices. Step count follows angular, chord and maximum-edge options.
The exact surface, boundary samples and face-run identity remain unchanged.
Rounded-box tests check spherical triangle interior error and radial normals,
not only triangle counts; native rendering checks the mounted output.

Preflight reserves no output storage, but it is not allocation-free. Planar
boundary samples are retained only after their face passes cumulative admission
and are passed unchanged to emission. This request-local preparation is bounded
by the admitted vertex count (one Point3D per sampled boundary vertex, plus loop
and face container overhead), and is released with the invocation on success,
failure or cancellation. It is not a persistent geometry cache. Nonplanar
sampling retains its existing path. The admitted estimate bounds the *geometric*
emission, and emission revalidates against it after every face rather than
trusting it.

The estimate does not model winding repair. When a triangle's vertex normals
disagree with its face normal, `appendTriangleWithNormalFallback` gives that
triangle its own flat-shaded corners, adding three vertices — and no indices —
beyond the geometry the estimate describes. The tessellator charges each
actual vertex/index growth immediately before the corresponding append, so the
fallback's three vertices and their bytes are refused before storage can grow.
`validateEmission(against:)` still excludes those duplicates from the geometric
estimate comparison. Storage is therefore bounded by the limits on every path,
while the preflight is still held to the geometry it claims to estimate: an
estimate wrong about the geometry is rejected, and an estimate silent about
winding repair cannot bypass the checked output budget.

Cancellation is observed through `Task.checkCancellation()` at document/body/
face boundaries and inside bounded grid, triangle, and sampled-output loops, so
a synchronous caller outside a task is unaffected and a cancelled task fails
with `CancellationError` before the next bounded unit of work.

Mesh compaction publishes each nonnegative remapped index through an exact checked
UInt32 conversion on every target. It does not convert UInt32.max to target-sized
Int. Out-of-range conversion retains the existing typed failure; triangle order,
attributes, FaceRun, caller limits and cancellation remain unchanged.

Besides the bounded planar preparation above, two transients remain outside the charged budget. `compactedMesh`
allocates one remapping table and the compacted attribute arrays for a body that
has already been admitted and emitted, and `DocumentCacheValidation` and
`EvaluatedDocumentValidation` re-tessellate to compare against the cache.
`DocumentCacheValidation.validateFreshness(limits:)` re-tessellates under the
limits its caller passes, and `EvaluatedDocument.validate(limits:)` defaults to
`TessellationLimits.hardCeiling` because a document admitted under a wider
ceiling than the caller's own must not be rejected by its own consistency check.
Neither can exceed the package ceiling; the charged ceilings therefore bound
emitted mesh size, not peak process memory. The measured peak-to-mesh ratio of 3.6x to 4.5x
recorded in `Sources/CADIR/DESIGN.md` is the basis on which
`TessellationLimits.hardCeiling` accounts for these transients.

When an evaluator reuses prior meshes, `makeMeshes` computes the checked
aggregate usage of meshes that remain retained and passes it as `reserving` to
the changed-body request. The production tessellator rejects any fresh
preflight or append that would exceed the remaining allowance. A legacy or
injected `Tessellating` may use the default compatibility overload and cannot
enforce that allowance before its own allocation, so `makeMeshes` still charges
the complete final mesh set at the publication boundary. This aggregate guard
covers reused-only, reused-plus-fresh, and injected-provider output; failure
discards the local result and publishes no evaluated document.

### Tessellation Fidelity

A refining path meets every bound of `TessellationOptions` together: the chord
bound (`linearTolerance`, the distance from a segment or facet to the exact
geometry), the turning bound (`angularTolerance`, how far the exact tangent or
normal turns across it) and `maxEdgeLength`. No path relies on a fine turning
bound to deliver the chord bound: a circle of radius `r` split into steps of
angle φ deviates by `r(1 − cos(φ/2))`, which grows with `r`, so circular
sampling takes the larger of the turning count and the chord count.

| Path | Chord | Turning | Edge length |
|---|---|---|---|
| Circle, arc and ellipse edges (`CircularCurveSamplingPolicy`; an ellipse by its major radius) | enforced | enforced | — |
| Cylinder and cone grids (curved along `u` at the largest radius; straight along `v`) | enforced | enforced | enforced |
| Sphere and torus grids (curved along both directions) | each direction takes half | each direction takes half | enforced |
| Offset, ruled and rolling-ball grids | certified combined bound | certified combined bound | enforced |
| Bounded curves (B-spline, lifts, intersections, conics) | certified | certified | enforced |
| Planar faces | boundary simplified within the bound | flat | — |
| Convex trimmed spherical patches | radial rings | radial rings | enforced |
| Other trimmed parametric faces | boundary only | boundary only | boundary only |
| Admitted C1 rectangular B-spline grids | certified combined Hessian bound | certified normal-path bound | enforced, including diagonals |

A facet spanning two curved directions accumulates both: its sagitta adds the
two directions' `a²/8ρ` terms and its normal turns by at most the sum of the two
turns, so a sphere or torus grid gives each direction half of each budget and
the facet meets the whole. Adjacent faces may sample a shared edge differently;
each stays within the chord bound of the exact edge, so a gap between them is at
most twice the bound. Other trimmed parametric faces do not refine their interiors. Unadmitted
B-spline charts and that trimmed branch retain `FIXME(INCOMPLETE_IMPLEMENTATION)`; these unsupported paths are not
covered by the fidelity contract until they refine against all three bounds.
`TessellationFidelityTests` prove the chord bound on large circles and on
doubly curved grids, and `TessellationStandardFeasibilityTests` prove that
`TessellationOptions.standard` admits the assembly its selection rule names.

## Runtime Flows

An immutable snapshot is evaluated once, topology entries are enumerated, each
signature is built and validated, and callers receive either the complete
reference or the exact typed failure. For a materialized Mesh artifact, the
kernel first derives conservative checked per-face/body counts and byte usage,
reserves only after aggregate admission succeeds, then charges each actual
growth while emitting and validating all bodies.
Cancellation or any face/body failure abandons the local result before the
caller can observe it.

## State, Ownership, and Lifecycle

The evaluator owns the immutable snapshot during its read. Signature values
outlive the read only as detached value data. No mutable project or source
document is retained by the reference.

## Failure, Concurrency, and Constraints

Missing topology, missing pcurves, invalid signatures, stale resolution,
overflow, limit exhaustion, and cancellation throw typed kernel errors or the
standard cancellation error. Reads do not mutate the source or invoke external
callbacks. The supplied snapshot is the sole read authority. Preflight owns no
UI scheduling and performs no retry; a caller that needs another fidelity
profile must submit a new explicit evaluation request.

## Verification and Change Impact

Shared B-spline chart crossings may use a certified implicit pcurve's strictly
monotone coordinate to prove that an isoparametric edge has at most one crossing.
This reduction requires exact endpoint-coordinate equality, full-span signed
derivative bounds, validated chart ownership, and model-space boundary agreement
at the unchanged distance tolerance. Unproven monotonicity or unsupported charts
retain the existing complete intersection path. NativeTrimCrossingTests owns the
captured helical contact/boundary regression.

Kernel tests must exercise every sphere body/face/edge/vertex stable-reference
path, deterministic JSON round-trip, invalid signature rejection, and planar or
cylindrical regression. `TessellationBudgetTests` proves the checked preflight
rejects out-of-range and cumulative charges before allocation, that limits set
to a model's exact emission are still refused because admission charges the
conservative estimate first, that a refused charge leaves the budget unchanged,
that emission beyond the admitted estimate is rejected, that cancellation is
observed both before an invocation starts and at an interior checkpoint once it
has started, and that the exact B-rep tessellates to identical meshes after a
refusal. `MeshTessellatorFaceRunTests` proves the emitted runs cover every
triangle of every body in traversal order, name the faces the body owns, and
are identical whether a body is tessellated fresh or re-tessellated after an
incremental extraction. `MeshCacheScopeTests` proves that a change confined to
the mesh request rebuilds no feature: a purpose change and a fidelity change
each retain the exact B-rep, re-tessellate the affected bodies, and record the
requested configuration on the new artifact. Per-checkpoint attribution between the body and face boundaries is not
separately observable through the public API; the interior-checkpoint test uses
a fixture whose tessellation is an order of magnitude longer than the delay
before cancellation. Mesh artifact reuse is separated from exact incremental
reuse by the cache tests.
Changes require rechecking primitive evaluation, tessellation configuration
identity, and RupaCore snapshot measurement.

## Boolean operands and material

Default Push Face composition injects the same `BRepSewing` and `ExactBooleanOperationApplicator` into [Face Offset](../CADModeling/FaceOffset/DESIGN.md). Intermediate growth uses deterministic `.pushFaceGrow` stage identities; temporary tool and stage identities cannot be published as feature identities or lineage parents. The child owns multi-face profile retention and final staged publication.

One Boolean pass (`BooleanPipeline.evaluate`) combines targets with one tool, each
operand's material taken as a `BooleanMaterials` pair says. The pass resolves a
`BooleanOperandSolidity` per operand from its body kind, role and material, and
every phase reads the same `BooleanOperandContext`.

| Operand | Default | Inside | Outside | Empty |
|---|---|---|---|---|
| solid | `volume` | `volume` | `complement` | `none` |
| sheet tool facing solid targets | `behindSheet` | `behindSheet` | `inFrontOfSheet` | `none` |
| any other sheet | `none` | `behindSheet` | `inFrontOfSheet` | `none` |

- Classification: `BooleanOperandPointClassifier` answers inside/outside/boundary
  against each operand's material: `DefaultBRepSolidPointClassifier` for a volume
  (inverted for its complement), `BRepSheetSidePointClassifier` for a sheet side
  (the first sheet face a ray from the point meets, along or against each sheet
  face's normal at its parameter midpoint and then three fixed oblique
  directions, says by its oriented normal whether the point is behind it; a point
  no ray reaches the sheet from, or directions that disagree, is a typed
  classification failure), and outside everywhere for `none`. Both classifiers
  share `BRepRayFaceCrossings`, which counts one crossing where a ray meets two
  faces at an edge they share but two where it passes faces lying on each other
  with opposite normals (solids touching along a face, as a slice's pieces do).
- Selection: `BooleanRegionSelectionRule` is the one keep/discard table for
  materials behind their faces; a face of an operand whose material lies in front
  of its faces (`isInverted`) turns a kept face (`oriented`). Coincident ownership
  compares material-outward normals and orients its actions the same way; faces of
  an empty operand that coincide with the other operand are refused as
  unsupported.
- Materialization: the special-case planners (orthogonal cells, convex planar,
  revolved, partial cylinder, disjoint union) are used only when both operands are
  volumes; otherwise the general exact path materializes the selected regions. Every
  planner keeps each face's material on the left of its loops about its outward normal
  (outlines counterclockwise, holes clockwise): a face turned over turns its loops with it
  (`BRepSewingPatchOrientationAdapter`), so a revolved tool's wall left facing into a hole
  and the hole's circle in the cap it opens wind as an extruded holed profile's do
  (`RevolvedBooleanLoopWindingTests`). The convex planar planner reads each operand face's
  winding from its own vertices and turns it counterclockwise about the face's outward
  normal, since a body extruded against its section's normal winds every loop the other way
  with its caps left `forward` (a drafted pocket sunk from a top face,
  `aDraftedToolCutsOrJoinsABoxExactly`). Its BSP fragments that lie on one plane and share
  edges are joined into one face (`PlanarBooleanFragmentMerger`): the shared edges cancel, the
  rest chain into one outline and its holes, and a vertex left on exactly two faces in the middle
  of a straight edge goes; a coplanar region whose edges do not chain into one outline (two
  outlines touching at a vertex) keeps its fragments as separate faces. A revolved tool standing on a cap of a convex
  planar target from outside, its own cap's disc inside that face (a boss drawn on the
  face, joined by Union or Extrude Join), is the revolved union of a tool protruding
  from that cap; any other boundary contact is refused as non-manifold (`BossJoinTests`).
  A revolved solid standing from outside on a planar face of any other solid, its cap's disc
  inside the face clear of its edges and holes and the face's plane bounding that solid (a
  boss on a holed plate, a stepped shaft), joins it (`StandingRevolvedUnionPlan`): every face
  of both is carried but the standing cap, the face taking the cap's boundary edges as a hole.
  A pointed cone (one cone's faces and its base's coplanar caps, every vertex its apex or on the
  base circle) stands on its base the same way; a box target reaches the plan once the convex
  planar and revolved plans refuse its tool, before the disjoint union
  (`aConeStandingOnAPlateJoinsItAndItsFootBlends`).
  Flush on a coaxial revolved solid's cap of its own radius (equal cylinders stacked), both caps
  go and each wall's rim on the shared circle is split where the other's is
  (`equalCylindersStackedJoinIntoOne`); any other disc reaching the face's edges is refused
  (`FIXME(INCOMPLETE_IMPLEMENTATION)`).
  A
  pass whose targets have no material produces a sheet body, any other a solid
  (`resultBodyKind`), and the sewing request must carry that kind. A face crossing
  an empty-shell operand is split along the crossing when both sides stay, and a
  boundary kept on both sides of one face gives its reverse use its own identity
  (`:reverse-use`).
- Operands that do not cross (`WholeBodyBooleanFacePatchMaterializer`) are decided
  whole: each body's boundary is classified against the other's material, and the
  rule keeps, turns or drops it. Each boundary lying in the other's material is a
  contradiction only between two volumes; a body inside another lies in the other's
  complement, so a contained tool subtracted as Outside leaves the tool's volume
  (`containedOperandsTakeComplementMaterials`). A boundary on the other's
  boundary without the reverse needs a partition and is refused.
- Callers without materials (patterns, sweeps, extrudes, mirrors, half-space
  cuts, section curves) keep two solids taken as their volumes.

`SheetBooleanTests` (SwiftCADTests) own solid−sheet difference, intersect,
Outside and reversed-normal flips, a sheet slice, sheet−solid trim and inside,
sheet−sheet split and empty intersection, the refused half-space union, a sheet
that does not reach across, the result port and material persistence; the
existing Boolean suites prove volumes are unchanged.

## Slice

Plasticity's Slice keeps every piece: the targets' parts out of and in the tool, and the tool's
parts outside the targets. A pass slices the targets only (`BooleanSliceSewingRequestBuilder`:
`target \ tool` and `target ∩ tool` from one intersection graph), so for solid operands of default
material `BooleanFeatureEvaluator` first takes the tool less each target in staged Difference
passes (`sliceToolRemainder`), restores the operands as they were (`FeatureEvaluationStages
.restoreBodies`), slices the targets, and adds the tool's pieces to the Slice's body as components
of their own, published as `sliceToolPiece.*` subshapes tracing to their stage names. A tool the
targets hold leaves no piece (the Difference's empty result). A Slice with a sheet operand or
operand materials keeps only the targets' pieces (`FIXME(INCOMPLETE_IMPLEMENTATION)` in
`BooleanFeatureEvaluator`: Plasticity's pieces for those materials are not determined). `PrimitiveSphereBooleanIntegrationTests` own overlapping,
separate and contained spheres.

## Region

`BooleanOperation.region` divides space by the faces of every operand, targets and
tools alike, and replaces them with one solid whose components are the bounded
cells. `BooleanFeatureEvaluator` places the operands and passes them all to one
pass without uniting tools; `ExactBooleanOperationApplicator` routes the pass to
`RegionBooleanEvaluator`. A Region takes no operand material (`validate`).

```text
operands ──pairwise──▶ intersection + UV split graphs
        ──every crossing, both sides kept──▶ SharedCurveFaceArrangement
        + unsplit faces (SourceBRepFacePatchBuilder)
        ──▶ BRepCellComplexBuilder ──▶ solid sewing request ──▶ sewn, operands removed
```

- Arrangement: every pair of operands is intersected; each transverse component
  splits the faces on both sides with keep/keep forced partitions, so a face
  crossed by several operands is split by all of them (in-face crossings are
  shared by `SharedCurveFaceArrangement`). Coincident components are refused
  (`unsupportedCapability`, `FIXME(INCOMPLETE_IMPLEMENTATION)` in the evaluator).
- Cells (`BRepCellComplexBuilder`): patches with an edge no other patch shares are
  dropped until none remains (sheet parts outside the cells go). Each patch has a
  front and a back side; around each edge (`BRepSewingEdgeFan`) the two sides
  facing each wedge between angle-consecutive patches bound one region, so the
  connected sides are closed shells, each face turned to face out of its region
  and renamed per side. A shell whose region-interior probe point it encloses (ray
  parity, `BRepRayFaceCrossings`) is a cell's outer shell; any other is a void of
  the smallest outer shell enclosing it, re-emitted in the void convention (faces
  out of the cavity, shell reversed), or the unbounded region's boundary, dropped.
  No bounded cell is an `emptyResult`.
- Results publish stable-key subshapes (`OrthogonalBooleanFacePatchBuilder`
  naming) with remapped sewn and Boolean lineage; operand subshapes are removed
  (`BRepBodyTopologyRemoval`, shared with the exact Boolean evaluator).

`RegionBooleanTests` (SwiftCADTests) own overlapping cubes (three cells with their
volumes), a nested cube (a cell and a voided cell), a sheet dividing a cube,
separate cubes, and the refused material.

## Extract

`ExtractFeatureEvaluator` copies part of a body beside it: the source's exact
faces (`DefaultBRepFacePatchExtractor`) filtered to one component's shells, or to
the chosen faces regrouped into sheet shells by connectivity, are sewn under the
extraction's identity and merged into the model; the source body and its
subshapes are untouched, and every copied subshape's lineage leads to the source
subshape it copies. Components are ordered by the smallest identity of their
faces, so an index names the same piece on every evaluation; a source whose
component count is no longer the one the extraction was made for is refused
(`invalidInput`). Faces that close are copied as a solid (`.solidFaces`, a
`.body` output, only of a solid source): on a manifold body chosen faces close
exactly when they are every face of each shell they lie on (`ExtractFaceSet`), so
the copy takes whole shells, a chosen outer shell keeping the chosen voids inside
it and a void chosen without its outer shell bounding a solid of the cavity's
shape (its faces already face out of the cavity). Faces that do not close make
the solid they bound with the faces around them (Plasticity's Alternative
Duplicate, `ExtractFacePlugBuilder`): a staged copy of the body is healed over
them (`FaceRemovalPlanner`), the opening — their edges shared with faces not
chosen, pieces of one curve joined end to end — is imprinted on it
(`BRepFaceImprinter`), and its faces off the source's boundary (classified by
`DefaultBRepSolidPointClassifier`) cap the chosen faces; caps outside the source
make a pocket's plug (the chosen faces turned to face the void), caps inside it a
boss's block (the caps turned), and caps on both sides, or none, are refused
(`invalidInput`). Every edge is split where another patch's edge ends on it
(`BRepSewingEdgeSubdivider`) before sewing, so the two sides meet edge for edge;
the chosen faces trace to their source faces and the caps are generated. Faces
the healing cannot grow the faces around over, and caps on both sides, stay
refused (`FIXME(INCOMPLETE_IMPLEMENTATION)`). `ExtractFaceClosure` answers, for callers
that must declare the output before appending, whether faces close and whether
they make a solid at all (they close, or the plug builds; a plug refused with
`invalidInput` or `topologyFailure` means a sheet).
`ExtractFeatureTests` own slice pieces, the refused count, face sheets, closed
faces and cavities, a pocket's plug, a boss's block and a notch's block by volume, persistence and
the selection contract.

## Unjoin Faces

`UnjoinFacesFeatureEvaluator` separates a body in its place, consuming it: the
source's exact faces (`DefaultBRepFacePatchExtractor`) become the shells of one
sheet body, each chosen face (`.faces`, resolved through `ExtractFaceSet`) or
every face (`.everyFace`) a shell of its own and the faces left regrouped into one
shell per connected piece (`BRepSewingPatchShellPartitioner`). Every face keeps
its geometry, trim and side; the source body and every subshape within it
(`BodyTopologyScope`) are removed, and each new face's lineage leads to the face
it separates. A caller that presents one object per piece extracts the pieces by
component (`ExtractSelection.component`). `UnjoinFacesFeatureTests` own every
face, chosen faces and pieces, the round trip back to a solid through Join, a
foreign face refused and persistence.

## Imprint

`BRepFaceImprinter` splits faces of one body along curves that lie on them and
keeps every piece, the body staying the same solid or sheet. Each curve is an
exact edge on one face (a model-space curve and its parameter curve there) whose
ends lie on the face's boundary, on another curve, or close a chain. It reuses
the Boolean arrangement (`BooleanOpenFaceArrangementBuilder`) with both sides of
every curve kept and partitioning forced, in two passes: the first finds where
each face's arrangement splits its curves and edges, and every such point is
shared, so the second splits each edge the same way on both of its faces; a
neighbouring face no curve reaches is re-segmented at those points without being
split (`forcedAction: .keep`), which keeps solids sewable. Faces keep their
surfaces and sides, every shell keeps its role, and the source body with every
subshape in it is replaced. `BRepFaceCurveClipper` gives the pieces of a
parameter curve inside a face (split where it crosses the face's edges and kept
where its middle is inside), halving a piece that closes on itself; a curve
along one of the face's own edges is refused, or yields nothing when the caller
expects that (Untrim keeping edges). Its edge endpoints use the original
lift evaluation so an original-image pcurve retains its exact source-space
spatial law without a rounded inverse-UV roundtrip. `BRepImprintCompletion` carries a curve on
from an end inside its face along its own direction in the parameters until the
face's boundary or another curve (`ImprintCompletion.edge`).

`IsoparamFeatureEvaluator` imprints parameter lines at fractions of a face's
extent, reaching a twentieth past it within the surface's domain and clipped to
the face; subdividing a B-spline surface first inserts each line's knot up to the
degree, keeping its shape and parameters. `IsoparamPlacementQuery` answers where a line
through a point of a face lies: the point's nearest face parameter along the line's direction as
a fraction of that extent, refused on the border (Rupa places a clicked Isoparam with it).
`ImprintBodyFeatureEvaluator` imprints
the exact Boolean intersection of a tool's faces with a target's
(`BooleanPipeline.completeIntersectionGraph`, `uvSplitGraph`,
`BooleanFaceArrangementBoundary.edges`) and leaves the tool as it is; several tools imprint
at once, each tool's crossings completed among themselves so one tool's lines run on across
another's; a placed tool is first moved into the target's frame in an unpublished
`imprintToolPlacement` stage, and Imprint Curve Body imprints a placed curve as
its rigid image, so both imprint where they are shown. Coincident finite tool
outlines consume the shared original trim arrangement; unresolved contact or
correspondence remains a typed failure.
`UntrimFaceFeatureEvaluator` composes original native sheet production,
face-local closed/singular sewing admission, and kept-edge imprint publication
through [Singular Sheet Boundary](SingularSheetBoundary/DESIGN.md). That child
owns domain policy, pole/apex handling and source lineage; the source target
body remains retained.
[Original Imprint](OriginalImprint/DESIGN.md) owns curve/tool sweep preparation, original complete reach bounds, finite coincident outlines and scratch-source lineage. The module composes its retained curves through BRepFaceImprinter and completion. Partial occlusion and normal projection still require complete original whole-interval producers; sampled candidates are not their completion evidence. Existing ImprintFeatureTests own deferred behavior.

## Edge Offset

[Original Edge Offset](OriginalEdgeOffset/DESIGN.md) owns the selected original-curve offset producer composed by EdgeOffset and FaceLoopOffset. It consumes Modeling's whole native planar offset certificate and exact original face pcurve correspondence before imprint publication. [Natural Curve Join](../CADModeling/NaturalCurveJoin/DESIGN.md) owns endpoint-law continuation. General surface metric offsets and complete gap laws remain source gaps; sampled projection is not their publication authority. Existing EdgeOffsetFeatureTests own deferred route behavior.

## Hollow

`ShellFeatureEvaluator` walls a solid by a uniform thickness, Plasticity's sign: negative
inside it, positive outside it (the solid itself becomes the cavity). Copies of the solid are
sewn from its own faces (`DefaultBRepFacePatchExtractor`) in unpublished `hollowInnerBody`
stages, their faces tracing to the solid's through the sewing lineage, and their faces pushed
(`FaceSurfaceOffsetter`, `FaceSurfaceReplacementRebuilder`). Inward, one copy has every face
pushed in by the thickness and each opened face out by it, so it reaches through the openings;
the solid less the copy (`BooleanPipeline`, difference) is the hollow, the opened faces left as
rims. Outward, an outer copy has every face but the opened ones pushed out, a second copy only the
opened ones pushed out (reaching through the outer copy's openings), and the outer less the
second replaces the solid: its subshapes are removed and the result's lineage composed through
the copies to the solid's faces. With no face opened the cavity is closed, its own shell. An
inward thickness a face cannot be pushed in by (a round narrower than it, a wall it passes) is
refused with the feature's own identity. `HollowTests` prove boxes open through one or two faces
or closed, a cylinder and a rounded box inward, boxes open and closed and a cylinder outward by
exact volumes, and the refusal.

## Align Surface

`SurfaceAlignFeatureEvaluator` aligns a single-face B-spline sheet's parameter-boundary edge to a
reference B-spline face's parameter-boundary edge, placed in the target's frame.
`BSplineSurfaceEdgeAligner` turns the target so the edge is its lower U boundary and the
reference so its edge is its upper one, runs the reference along the edge the target's way,
maps both edge parameters to [0, 1], raises the lower degree and merges knots, so both share one
exact basis along the edge; refines the target along U only until it has the rows the continuity
sets and one more (Blend adds no rows: Plasticity's net keeps its size) — and, when the feature
`keepsOtherEdges` (a later edge of a sheet aligned in one dialog, Plasticity's align-3), first at a
sixteenth, an eighth and a quarter of the way across, so the rows set reach only the stretch beside
the edge and an edge aligned before keeps its own rows but where the two meet; then sets its first row to the reference's boundary (G0),
its second so the cross-edge derivative is the reference's times the tension times the target's
own speed ratio (G1), its third so the second derivative is that factor squared times the
reference's (G2), and fades the last row's displacement over the blended rows by their Greville
abscissae toward the first row left alone, each blended row keeping the input shape's influence
and running straight between those rows otherwise; a blend as long as the rows left moves them all,
far edge included, with the last row set ("the surface fully adjusts"). Partial start and end pick
the stretch of the reference edge, as fractions along it, that the whole target edge is attached
to (the reference trimmed to it; Plasticity's target funnels into that stretch), and a layout refits the
target to its degrees and spans on its own parameters first (`MappedBSplineSurfaceFitter`); the
reference's knots along the edge are merged in after, so the continuity stays exact. The sheet is
sewn anew on the aligned surface by `BSplineParameterRectanglePatchBuilder`, whose four sides are
the surface's isoparametric B-spline curves exactly (as Extend Sheet's strips are), so measuring an
edge reads its own control points rather than bounding the surface's derivatives cell by cell. Rational surfaces, trimmed faces and edges inside a domain are
refused. The cross-edge flow (Boundary, decided 2026-10-02) is the reference's own cross derivative
scaled (Next: the reference's next inner row, the default, kept in the requested layout) or, for
Normal (square to the edge), Natural (the target's own cross direction) and Adjacent (the blend of
the target's side edges' directions), `a·R_v + b·R_u` with quadratic `a`, `b` fitted to the flow in
the reference's tangent plane, the second derivative `b²·R_uu + 2ab·R_uv + a²·R_vv` — the reference
reparameterised to second order, so G1 and G2 stay exact; those products need the edge's basis
raised by 2 per order with its interior knots repeated once more per order, so these flows raise the
layout's degree along the edge. `SurfaceAlignJointTests` prove two edges of a flat sheet aligned
one after the other to two pieces of one tilted plane both holding all along, the corner included, and
to two arches bending apart past the corner the first held away from it only when kept.
`SurfaceAlignTests` prove a flat sheet following an arch across
a gap at G0, G1 and G2 with its far edge kept when nothing is blended, a two-row sheet whose one
blended row carries its far edge along, a partial alignment on a refitted layout attaching
the whole edge to the middle of the reference edge, and blended rows of a six-row sheet without input shape influence
running straight, the net keeping its rows; `SurfaceAlignFlowTests` every flow curvature continuous over a sheared arch and
Normal square to the edge, its `SurfaceAlignAnalyzer` analysis within limits. `SurfaceAlignAnalyzer`
measures an aligned sheet against its reference along the reference edge, placed in the sheet's
frame, at 32 interior points: the largest distance (G0), normal angle (G1) and normal-curvature
difference across the edge (G2), against the modeling distance, 10⁻⁶ rad and 10⁻³ m⁻¹. Its
`samples` are those 32 points as `SurfaceAlignSample`s (edge point, the sheet's nearest point, both
unit normals with the reference's turned to agree, the sheet's direction across the edge and both
normal curvatures along it), from which the editor draws the analysis's G0 gaps, G1 normal turns and
G2 combs; `SurfaceAlignFlowTests` own them over an arch (no gap or turn at G1 and G2, the arch's
(2/s)/2^{3/2} bend across, matched by the sheet at G2).

## Rebuild Face

`FaceRebuildFeatureEvaluator` gives each chosen face a B-spline surface refitted to its own on the
same parameters (`MappedBSplineSurfaceFitter`: an explicit layout as given, a tolerance by as few
bicubic spans as keep within it), over the face's parameter extent when it shrinks and its
surface's own domain otherwise (a B-spline's knot range; an analytic surface's face extent),
widened past each side by the extension fractions. A B-spline is read past its domain as its end
spans continued (`BSplineSurfaceNaturalContinuation`, de Boor's algorithm on the nearest span);
an analytic surface asked past its domain is refused. A face that is a sheet of its own is sewn
anew on its new surface when the new surface strays from its edges, each edge a B-spline fitted
along its trimming curve within a quarter of the distance tolerance, so coarse layouts are free.
Any face whose new surface keeps within a quarter of the distance tolerance of the old one along
its trimming curves takes it in place, its edges, vertices and trimming curves kept, whatever its
neighbours. A coarser refit of a face sharing edges has them re-solved onto its new surface
(`RebuiltFaceEdgeResolver`) where its neighbours cross it, by their signed distances — planes,
cylinders and spheres in closed form, any other surface (cones, tori, splines) by the foot of the
point on it, Newton on (S − p)·S_u = (S − p)·S_v = 0 from the old edge's point: each corner where the
new surface meets its two neighbours (Newton on the new surface's parameters), each edge the new
surface's crossing of its neighbour between them — the old trimming curve with its ends carried onto
the new corners, each point slid across it onto the neighbour, fitted as the new trimming curve, the
edge the surface along it within an eighth of the distance tolerance, its trimming curve on a curved
neighbour fitted likewise — and the neighbours' edges run along their own line, circle or curve to
the moved corners, a B-spline cut exactly to the new piece (`BSplineCurveSegmentExtractor`, Boehm
insertion of both ends) and their old exact trimming curves cut to it (iso-lines, segments and
B-splines) rather than fitted. An edge the new surface still runs through, ends and all, is kept.
All coarse faces of a shell are resolved together: a rebuilt neighbour is measured on its new
surface, its foot started from the old surface's parameters it was refitted on (a start found once
per point measured), so an edge two coarse faces share is their new surfaces' crossing, solved once on
the first's parameters with its trimming curve on the other fitted through the feet, and a corner is
where its three faces' surfaces meet. A refit touching a neighbour without crossing it is refused
(`FIXME(INCOMPLETE_IMPLEMENTATION)`).
`FaceRebuildTests` own the explicit layout reproducing a quadratic arch exactly, the extension
continuing it past its edge with the face kept, a box's top, a cylinder's quarter wall (tangent
neighbours) and an open box's wall (open and shared edges) rebuilt in place, a cubic arch's wall
rebuilt as a quadratic with its edges re-solved on its planes (the volume by Green's theorem over
the new section), two cubic walls meeting at an apex rebuilt together (their shared edge on both
new walls), a box's round rebuilt flat into the chamfer through its contacts, and a cylinder's
half wall rebuilt flat into the chord across its caps and its other half (their volumes), a
drafted cylinder's rational cone quarter rebuilt flat with its edges up the wall on the quarters
beside it, and two opposite quarters rebuilt flat together.

Remove Nominal Surface is Rebuild Face's `nominal` method: each spline face's surface cut exactly to its parameter extent (`BSplineSurface3D.trimmed`, on the same parameters, so its trimming curves hold and it takes its new surface in place), with no extension; an analytic face has no nominal surface beyond its edges and is refused. `FaceRebuildTests` own an arch extended past its edges and cut back (the same parabola on [0, 1]) and the plane's refusal.

Square's Refit is Rebuild Face's `square` method (`SquareFaceRefitter`): a face bounded by one loop
of at least four edges is split into four sides at the four vertices where the loop turns most,
each side its edges' exact spans joined along the loop, and the face takes Square's fit of that
frame in exactly the requested net with every side hard — G0, or tangent or curvature continuous
with the one neighbouring face across it (a side on the sheet's open boundary stays G0) — or every
side loose (`SquareRefit.isFree`); its coedges become constant-parameter curves along the new
sheet's boundary, each over its edge's stretch of its side, and its orientation keeps its outward
normal. An original edge is kept only after the existing whole curve/surface
correspondence validator certifies the whole original oriented curve against the new
pcurve at `tolerance.distance`, using the existing depth32/cell1048576 proof
limits. Seventeen observed samples may supply diagnostics only. A proved
`topologyFailure` classifies a straying edge; resource, ambiguity, singularity
and invalid-input failures propagate without that classification. The generic
B-rep validator's eight-times-distance allowance cannot authorize this keep
predicate. An edge satisfying that strict proof is kept, shared
with its neighbour; a sheet's straying edge is replaced by its own edge fitted along the new
boundary and the body is sewn anew, preserving the source edge and both endpoint
vertex parent subshape IDs; the neighbour's edge is left open; a solid's straying edge is
refused (`FIXME(INCOMPLETE_IMPLEMENTATION)`, no tolerant edges). No extension or shrinking applies.
`SquareRefitTests` own a box's top refit flat to its Degree (keeping its volume), a pentagonal
prism's top split at its four sharpest corners — refused on the solid, its bent side detached on
the prism's faces extracted as a sheet, and refit Free — and a sheet's face refit tangent to a
curved ramp beside it. `FaceRefitAnalyzer` is Refit Face's Analysis: for each edge of each refit
face the largest distance from its curve (33 samples) to the new surface's boundary stretch its
trimming curve names, judged against the modeling distance and placed at the edge's middle
(`SquareSideAnalysis`); stable selection follows current lineage to the final face,
so regenerated edges are measured, not an immutable original boundary. The box-top
test owns its four edges lying on the new boundary.
Rebuild Face's `given` method gives one face a B-spline surface on its own parameters — Plasticity's
Raise Degree and control-point moves on a face of a solid. `FaceBSplineSurfaceConverter` makes the
face's surface exact first (a B-spline as it is; a plane as the degree (1, 1) patch through its
corners over a rectangle holding every trimming curve (within the surface's own domain, and along a
periodic parameter the shortest stretch holding them, a face across the seam running on past it); a
cylinder, cone, sphere or torus face as the exact rational surface of revolution over that
rectangle — its profile at the first angle (a line, or arcs of at most a quarter turn whose middle
control point is M + (M − Q) / cos θ weighted cos θ) turned about the axis in such arcs, weights
multiplied — checked to lie on the old surface, a face closing round its axis putting the new
surface's ends on its seam and a face reaching a pole leaving the new surface a side collapsed to
it; any other surface refused, `FIXME(INCOMPLETE_IMPLEMENTATION)`). The face faces out as it did (the given surface's normal at the face's interior point's
parameters, the surface sharing them); where every edge still lies on
the new surface along its trimming curve (within a quarter of the distance tolerance) it keeps its
edges; where they lie on it, or on its natural continuation past every side as far again as it
spans (`BSplineSurfaceBoundaryExtender.continued`, Plasticity's hidden spans of a nominal surface,
when its control points are drawn in), only geometrically it keeps them (and where their trimming
curves cannot be built, it re-solves them with the faces beside it; a boundary control point moved
within the face's plane alone still fails there, `FIXME(INCOMPLETE_IMPLEMENTATION)`)
too, each taking the isoline of the new surface it runs along (a seam's two coedges the two ends,
the one that lay lower taking the lower; an edge closing round the seam running end to end; a point
at a pole taking the collapsed side's parameter, and one whose projection crowds beside it read
from its neighbours, the isoline checked through the others) or a
trimming curve built on it;
otherwise `FaceSurfaceReplacementRebuilder` re-solves the edges and vertices around it where
it meets the faces beside it, which keep their surfaces, and the trimming curves are rebuilt.
`FaceGivenSurfaceTests` own a box's top raised to degree 2 in place (volume kept) and a side's
top-middle control point moved 5 mm out, bulging the box by d·w·h/9 with its five planes kept,
and its middle control point moved out bulging it the same between the edges it keeps, a box raised
face by face through the Rebuild Faces before each, and a rounded edge's quarter cylinder given its
exact rational surface (every point the radius from the axis) and raised, its volume kept; a drum's
side across its seam, a ball's octant reaching its pole (every point the radius from the centre)
and a ring's face raised the same; every octant of a ball, those across its seam included, valid
and meshed (`MeshTessellator` reading a trimmed face's normal where the surface has none, at a pole,
just inside the face toward the middle of its points). These are approximate shading normals,
not a certified one-sided normal limit; direction-dependent singularities and an angular
error guarantee remain incomplete and are source-marked. A side's control points drawn halfway in
keeping the face on the surface's natural continuation (its hidden spans, the box unchanged), and
`FaceBSplineSurfaceConverter.nominalSurface` cutting that continuation to the face's edges.

## Unwrap Face

`FaceUnwrapFeatureEvaluator` lays one face flat as a sheet of its own in the XY plane, centred on
the origin (the middle of its flat boundary's box), front facing +Z (a reversed face is laid out
mirrored), the body left as it is. `FaceDevelopment` maps the face's parameters: planes as they
are, cylinders unrolled (r·u, v), cones into their sector (v·cos(u·sin α), −v·sin(u·sin α)) — all
isometric — and other surfaces by arc length along their middle parameter lines (five-point
Gauss–Legendre over 64 cells). The sheet keeps the face's parameters and trimming curves, so it
serves as Deform's reference: its surface is a planar B-spline fitted to the map within a quarter
of the distance tolerance, and each edge a B-spline fitted to that surface along the edge's
trimming curve. A seam comes apart into two edges. A face around its surface's period with no
seam cannot reach it: a loop winding around the period encloses no parameter area, which B-rep
validation rejects (`degenerateLoop`), so the refusal of a loop that does not close when laid flat
only guards against invalid input. `FaceUnwrapTests` own a cylinder's
quarter wall unrolled to its arc length and height about the origin, and an arch laid out to its
parabola's length.

## Extend Sheet

[Natural Sheet Extension](NaturalSheetExtension/DESIGN.md) owns the SheetExtend public evaluator, retained original support strips, complete-side rectangular inward trimming, and reach-proof limits. The module composes its output through sewing and body replacement; optional planar half-space cutting remains a separate injected producer. Original B-spline continuation uses the Geometry boundary extender. General non-isoparametric shortening, curved corner laws and whole limit-contact proof remain explicit source gaps. Existing SheetExtendTests own deferred behavior checks; current source snapshots do not establish their results.

## Reverse Sheet

`ReverseSheetFeatureEvaluator` turns a sheet over in its place, consuming it: the
sheet's exact faces are copied as sewing patches, each reoriented to its other
side (`BRepSewingPatchOrientationAdapter`: loops traversed the other way,
parameter curves reversed) and sewn back in the sheet's own shells, so surfaces,
trims and the sewn edges between faces are unchanged. A solid is refused at graph
construction and evaluation (its faces face out of it). The source body and every
subshape within it are removed, and each face's lineage leads to the face it
turns over. `ReverseSheetFeatureTests` own one face, a joined sheet turned over
whole and back, the refused solid, persistence and the open-edge query
(`OpenBoundaryLoopResolver.boundaryEdgeIDs`, every edge one face uses).

## Wrap

`WrapFeatureEvaluator` deforms a body from one face onto another (Deform Solid
and Sheet): a point goes from its UVN coordinates on the reference face, through
`WrapOptions` (scale and offset about the extent's centre in normalized units,
N scaled and offset as a length, mirror, swap and normal flip), to the same
coordinates on the target face. Both faces are read as the model is before the
feature, resolved once, each in its own body's frame and placed into the
target's by its rigid placement (none: where it was evaluated). The body keeps its topology and trims: each face's
support becomes a bicubic B-spline fitted to the map of its old support over the
face's own parameter extent (`MappedBSplineSurfaceFitter`, from one span, so an
affine map is exact), keeping its pcurves; each edge's span becomes a B-spline on
the same parameters ([`SpatialCurveFitter.fitBSpline`](../CADModeling/DESIGN.md#spatial-curve-fitting)), shared by the edge's two
coedges. Both fits stay within a quarter of the distance tolerance, so every
edge meets its faces and vertices within it. Where the map's Jacobian determinant
is negative at every vertex the faces are reversed to keep the body right side
out; a sign that changes, or a determinant too small to read, is refused as
folding or flattening (`singularGeometry`). The faces are sewn under the
feature's identity with the source's body topology and lineage to the source
subshapes; the source is removed with its subshapes unless `keepsTarget`. A body
carried beyond a bounded target surface fails (`invalidInput`), and so does one whose
vertices' images reach a whole turn around a periodic target face, which would meet itself
across the seam (checked before any fit; Plasticity asks for the body or face to be split); a fit past its
span budget fails (`resourceLimitExceeded`). With Reblend (`WrapOptions.reblends`) the
body's closed chains of round fillets are recomputed on the deformed faces by
CADModeling's `RollingBallReblender` before sewing: the faces those rounds blend are
fitted past their trims by twice the largest such radius (a narrower round touches them
nearer the sharp edge), and each round's surface, rails, sections, the vertices where they
meet and the trims of the edges reaching those vertices are replaced, topology and
identities kept; rounds of open chains and corners keep the deformed geometry
(`FIXME(INCOMPLETE_IMPLEMENTATION)`). `WrapFeatureTests` own the
identity, offsets with Keep, placed faces, a cube bent onto a cylinder as an annular sector,
the mirrored reversal, refused options and persistence; `WrapReblendTests` a rounded block's
rounded top outline bent onto a cylinder, whose rounds bent with it miss the ball touching
both faces at the radius and reblended touch it within the fits.
A deformed body's faces are non-rational B-splines of many spans under their
source's rectangular trims, which CADTopology's `TrimmedParametricSurfaceVolumeEvaluator`
integrates exactly span by span (each certified Bezier span cut to its share of
the rectangle; a share a hair wide leaves the face to the general certified path),
and `ExactRectangularPcurveDomainResolver` reads an axis-aligned polyline side,
running one way, as a rectangle side, and several pcurves running straight on along one
parameter line as one side (a merged PolySplines face bounded by the edges of its neighbours). Before this, the certified rational path
took minutes on such a body and every measurement of it stalled
(`multiSpanPolynomialTopUnderARectangleIsIntegratedSpanBySpan`).

## Sheet half-space cutting

`BRepBodyHalfSpaceCutter` delegates sheet operands to `BRepSheetHalfSpaceCutter` after constructing its enclosing half-space box. The sheet cutter reuses the complete intersection graph, exact UV splitter, intersection edge materialization, and open-face arrangement. It classifies the two sides of each transverse intersection by the signed derivative of the plane distance, preserving the source surface and pcurves. Unsplit faces are classified only after the complete intersection graph establishes absence of transverse crossings. Connected retained patches form sheet shells; no solid caps or box faces are published. An empty retained side or ambiguous tangency fails explicitly. Cut-stage lineage names only source topology. `SheetMirrorCutTests` owns kept/reflected/combined curved-sheet results, exact topology and empty-side failure; Rupa's `SceneMirrorTests` owns the command integration.

`CubicBezierChainExtension` keeps its public API and delegates numeric continuation to [CADCore](../CADCore/DESIGN.md), so persisted natural-extension expressions and direct kernel operations use identical geometry and failure semantics.

## Revolve section axes

`RevolveSectionAxis` gives Revolve's Normal, Binormal and Tangent axes from the section (decided
2026-10-02): through the start of its boundary — a profile's outer loop's first segment, a curve's
start (its end when reversed), a planar face's outer loop's first edge — Tangent along the boundary
there, Normal along the section plane's normal (a curve's sketch plane, or the plane through its
points; a non-planar curve has none), Binormal along Normal × Tangent. Authors read it as
`FullFilletRadius` is read: against the evaluated document. `RevolveSectionAxisTests` own a
rectangle's axes and its full turns about Tangent and Binormal (Pappus).

### C0 rectangle span composition (PAR.M1R3)

The bounded M1 extension admits nonperiodic clamped positive-weight C0 tensor
rectangles. Seven public declarations/10cases pass the literal side/corner,
interior fidelity, duplicate-count, singular, reservation/cancellation and
FaceRun/input-equality oracles; all36 existing mesh owner declarations pass on
the same frozen composed source. Geometry's
[original native-span authority](../CADGeometry/DESIGN.md#original-native-span-tessellation-authority-parm1r3)
is the sole owner of one-sided differential bounds and endpoint normals.
Kernel partitions the retained original rectangle at each distinct native U/V
knot. Every emitted triangle belongs to one smooth native span; none crosses
a C0 crease. Boundary positions evaluate the original support at exactly the
same retained native stations, while indices and one-sided normals remain
separate for each panel. A tensor knot corner can retain four normals.

```mermaid
flowchart LR
    Original["Original rectangle and native knots"] --> Authority["Geometry: immutable span authority"]
    Authority --> Bounds["One-sided complete bounds"]
    Bounds --> Grids["Kernel: compatible retained panel grids"]
    Grids --> Budget["Checked cumulative preflight"]
    Budget --> Mesh["Original positions / one-sided normals / one FaceRun"]
```

For each U interval, its step count is the maximum required across all V
panels; each V interval uses the analogous maximum. These common stations
prevent panel-boundary T-junctions. Counts use the existing anisotropic
position/Hessian, angular/normal-path and all-edge/diagonal inequalities, with
actual representable gaps. Increasing another panel's count can only narrow
these gaps; retained final grids are checked before emission.

| Owner | Required invariant | Behavioral evidence |
|---|---|---|
| Geometry | Original selected span; one-sided knot jets/normals; one aggregate proof ceiling | Literal derivative and domain/work/refusal tests |
| Kernel preflight | Checked sum of panel vertices `(ku+1)*(kv+1)` and indices `6*ku*kv`, including crease duplicates | Exact-count cumulative count/byte/reservation refusal |
| Kernel emission | Same retained grids; original point coordinates; panel-specific normals; existing actual budget/cancellation | No crossing triangles; matching boundary stations; literal interior/normal/all-edge checks |
| Provenance | One uninterrupted original face run and unchanged exact input | FaceRun/extraction and success/failure/cancellation input equality |

Literal oracles include `z=0.5*min(u,1-u)`, the quadratic piecewise
`z=u*u` / `z=(1-u)*(1-u)`, both U/V roles, and the sum of two linear
creases giving four corner normals. A collapsed tangent panel must fail;
resource exhaustion and pre-cancellation cannot return partial success.
Periodic C0, doubly-periodic charts, singular-limit shading, arbitrary trims
and inter-face M3 agreement remain separate full-scope gaps.

C0 composition consumes Geometry's immutable `OriginalNativeSpan` tokens and
`originalNativeSpanTessellationBounds(of:over:tolerance:)` panel records.
Geometry's `BSplineSurface3D.normal(u:v:owning:tolerance:)` validates the same
original token and evaluates selected scalar native derivatives with the
existing strict normal law. Kernel retains these records and compatible
counts through preflight/emission; it neither creates tokens nor selects an
unproved knot side. The shared token/extraction implementation belongs only
to PAR.ORIGJET1; C0 owns scalar normal composition, aggregate tessellation
bounds and mesh composition.

### Original Double-Periodic Rectangle Mesh (PAR.M1R4)

The existing C1 grid may consume double-periodic spline bounds only through
[Geometry's original double-C1 admission](../CADGeometry/DESIGN.md#original-double-periodic-c1-mesh-admission-parm1r4).
Rectangle admission validates both original parameter widths independently.
For each periodic axis the finite positive rounded width must be below period;
when equal, its TwoDifference residual must be nonpositive. Greater original
width is refused; no tolerance correction or nearest-period unwrap is allowed.
Existing original coedge/corner monotonic rectangle admission, closed seam
EdgeID/coedge identity, actual representable grid gaps, positional/normal/edge
and diagonal error, cumulative body/face/byte reservations, original support
emission, FaceRuns, orientation and cancellation are retained. Preflight and
emission use the same prepared grid. Independent literal double-cardinal tensor
fixtures cover seam-crossing/full-period success and each-axis rounded-period
overshoot, original C0/approximate translation/tail refusal and cumulative budgets.
No new selected-side periodic token or single-periodic policy is introduced.

Native verification passes Geometry five declarations/thirteen parameter cases
and Kernel five declarations/sixteen parameter cases, plus forty-three existing
Kernel tessellation tests and six original native-span Geometry tests. Literal
source positions/normals, both seam identities, full periods, exact-width refusal,
aggregate reservations and cancellation execute through the original production
path. Full M1 and portable closure remain separately owned.

### Native Rebuild Position Publication Evidence (PAR.G6POS1)

FaceRebuild's tolerance method owns a distance-only approximation request. DefaultFeatureEvaluator accepts caller-visible nativeSurfacePositionCertificationLimits and injects them into FaceRebuildFeatureEvaluator; DocumentEvaluator's existing featureEvaluator injection supplies these limits without new engine state. The immutable native-chart fitted output remains a candidate until the [Geometry Conversion position contract](../CADGeometry/GeometryConversion/DESIGN.md#native-position-only-surface-publication-parg6pos1) proves complete original-source position error.

For nonperiodic input with zero requested extensions, a candidate containing the entire original native domain is certified on that complete original domain, covering the exact validated original face. The fitter's outward halo receives no position guarantee. The nonperiodic contained-source route otherwise requires the actual requested fit rectangle strictly inside both original source and candidate. Original periodic requests consume the separate complete requested-rectangle contract below; polynomial continuation consumes PAR.G6CONT1. Unproved source laws and coverage retain explicit incomplete paths. The remaining non-native source families retain their explicit marker; original analytic publication is owned by PAR.G6ANALYTIC1 below. No fitted native candidate is installed before its position certificate succeeds, and tangent/curvature or general G6 completion is not inferred.

Lower invalid/resource/tolerance failures map to KernelError with feature/tolerance context: invalidInput, resourceLimitExceeded and approximationToleranceRejected (numerical indeterminacy). Native KernelError detail and task cancellation remain preserved. Candidate rejection does not assert approximation impossibility. Certification budgets are separate from the existing bounded candidate-fitting owner. Tests in [native publication](../../Tests/SwiftCADTests/FaceRebuildPositionCertificationTests.swift) exercise actual DocumentBuilder/CADPipeline publication, the literal9-by-9 interior bump missed by Greville/quarter stations, native plane success, caller resource refusal and outside-chart extension refusal; immutable source and emitted topology remain checked. Native public4tests, the incremental test and original explicit/box/cylinder3 regressions pass8tests53.410s on the pure indexed Swift6.4 release snapshot. The original continued-law success oracles remain requirements of full PARG.G6 rather than being weakened to match this bounded refusal.

The original Native sprint introduced incremental provenance swift-cad.document-evaluator-native-position-certification-v1. Analytic publication subsequently requires the v2 epoch specified below. The prior dev epoch fails reusableState admission and rebuilds every feature; exact topology validation alone is not position evidence. Current-epoch unchanged-source reuse remains valid. EvaluatedDocument persistence omits incremental state, so this boundary covers retained in-memory state. [Incremental provenance](../../Tests/SwiftCADTests/FaceRebuildIncrementalPositionCertificationTests.swift) executes the actual default evaluator and checks full rebuilt/reused counts for faithful old-epoch state versus current reuse. Native failure-contract7tests pass.003s, including serialization of every declared cause and original categories. Portable consumer closure remains task integration work.


### Original Analytic Rebuild Position Publication (PAR.G6ANALYTIC1)

The non-native `.tolerance` Rebuild path retains an original ordinary plane or
cylinder, or an analytic plane, cylinder, cone, sphere or torus, and the exact
finite native UV rectangle passed to its fitter.
Before inserting the fitted candidate into the replacement dictionary it consumes
[Geometry's original analytic position contract](../CADGeometry/GeometryConversion/DESIGN.md#original-analytic-rebuild-position-parg6analytic1)
through `GeometryAnalyticSurfacePositionCertifying`. The certificate must cover
that complete rectangle within the previously validated requested distance;
losing that distance is typed invalid input rather than a default allowance.
Original angular U coordinates, caller fitting degree/control limits, immutable
inputs, edge/topology handling and feature-scoped failures remain unchanged.
Other procedural source families retain their marked incomplete path.
Rebuild does not acquire an unrequested tangent/curvature approximation contract.

Cone, sphere and torus composition consumes the Geometry owner's original-law
position certificate through the same request, failure mapping and publication
gate. Their source-dependent preparation charges share the existing injected
limits. The previous plane/cylinder evidence does not verify these new source
families; their public success, refusal and portable behavior remain unverified.

Incremental provenance is now
`swift-cad.document-evaluator-native-position-certification-v2`. The previous v1
identity could retain successful analytic Rebuild output that bypassed complete
position proof; exact topology validation cannot certify that missing condition.
`DocumentEvaluationEngine.reusableState` must reject the entire faithful retained
v1 state and rebuild every feature, including the analytic Rebuild, before any
publication. Current-v2 unchanged-source state remains reusable. Persistence
continues to omit incremental state; custom evaluators continue to disable reuse.
This tightens a historically successful publication path, so the continuation
sprint's reasoning for retaining its prior epoch cannot authorize v1 reuse here.

The existing plane/cylinder Rebuild success oracles remain unchanged. Dedicated
public evidence checks literal original angular/native-chart positions,
caller-budget refusal with original FeatureID, immutable inputs, and faithful
old-v1 rejection versus current-v2 full reuse metrics. The existing dev-epoch
native Rebuild regression remains independently required. Lower preparation,
compile or a topology-only certificate is not public completion evidence.

### Original Periodic Rebuild Position Consumption

Tolerance Rebuild retains the original periodic source and resolves its finite
requested rectangle from the face extent or original fundamental domains.
Periodic coordinates are evaluated with the original periodic basis law,
never with an extrapolated end-span polynomial. A nonperiodic axis requested
outside its domain still belongs to the existing continuation owner; periodic
source admission does not authorize that separate operation.

Before replacement, the actual fitted candidate must pass
`GeometrySurfacePositionCertifying` on the complete requested native rectangle.
The lower owner proves exact original periodic continuity, both sides of C0
knots, complete position coverage and cumulative injected limits. Kernel does
not infer proof from a fit, periodic flags or exact topology. Existing
nonperiodic publication and retained-state provenance remain unchanged.
Public periodic success, refusal and portable evidence are pending.

### Polynomial Continued-Law Rebuild Publication (PAR.G6CONT1)

For a real nonzero extension outside the original source chart, resolve the request and obtain Geometry's prepared continuation request before adaptive fitting. Pass that same receipt to post-fit candidate certification so source admission, candidate validation and whole-law proof share one caller allowance. A zero-extension request keeps the existing contained whole-original path even when the extent resolver includes a numerical halo. Unsupported source families must refuse before fitting; the consumer does not duplicate Geometry's weight, knot or coefficient predicates.

For tolerance Rebuild on an original native B-spline, the candidate is still constructed on the actual requested native rectangle before any surface is installed. Zero-extension whole-original publication retains PAR.G6POS1 and its contained certifier. A finite request extending outside the original nonperiodic closed chart can publish only after Geometry's explicit original polynomial continuation certifier proves the complete requested rectangle against that actual candidate under the existing evaluator-injected NativeSurfacePositionCertificationLimits. The request resolver owns actual feature extent/extension arithmetic; it does not establish source continuation authority. Unsupported source/candidate families, uncontained candidate support, nonfinite input, definite excess, original resource exhaustion and cancellation refuse before installation with existing typed causes and original FeatureID. No sample, fitter halo, rebuilt trimming curve, exact topology validation or rounded continued net substitutes for the lower certificate. The lower continuation owner now admits finite nonperiodic exact-clamped common-positive-weight multi-span tensors under PAR.G6MULT1, preserving original C0 partitions and both outer end-span laws. Public consumer admission and output behavior must be verified on that lower snapshot before this extension closes. Full periodic/varying-weight/foreign-chart continuation remains explicitly marked incomplete; other unproved tolerance-source families retain their existing marker; analytic plane/cylinder publication uses the contract above.

For an admitted continued source whose original U and V degrees are at most three, tolerance Rebuild explicitly selects the Geometry-owned native-knot constructor through `GeometryPolynomialSurfaceContinuationConstructing`. It requests bicubic degrees with the existing 128-span and 131-control-point per-axis authoring ceilings. The producer returns the actual candidate together with its complete certificate, carrying source preparation, coefficient authoring and proof costs in one allowance; Kernel does not certify that result a second time. Kernel depends only on this producer guarantee and verifies returned request coverage and finite distance evidence before replacement. The original higher-degree continued-source route still uses the mapped fitter followed by the existing whole-law certifier. Family selection occurs before construction, and construction or proof failures propagate without a sampled retry. Explicit layouts, nominal cuts, given surfaces and zero-extension contained-source certification retain their existing owners. See the [Geometry candidate contract](../CADGeometry/GeometryConversion/DESIGN.md#native-knot-polynomial-continuation-candidate-construction) for source admission, coefficient ownership and cumulative costs. Actual public output and failure tests own this composition evidence; its verification is pending.

The fitted-candidate consumer uses GeometryPolynomialSurfaceContinuationPositionCertifying.certifyContinuationPosition through CertifiedPolynomialSurfaceContinuationPositionCertifier and relies on its full original-law contract, without duplicating coefficient logic. Each face must certify before entering the replacement dictionary; final topology and trimming retain their existing independent owners. For the historical PAR.G6CONT1/PAR.G6MULT1 extension, the then-current native-position incremental provenance remained valid for unchanged contained certificates: implementations before PAR.G6CONT1 could not publish outside-source continuation documents; previously certified single-polynomial results retain the same original law and distance guarantee after PAR.G6MULT1, prior dev state is already rejected, custom evaluators disable incremental reuse, and serialized EvaluatedDocument omits incremental state. This strictly expands a previously refused source operation and does not weaken the current retained-state evidence; no new epoch was required for that bounded extension. Current analytic publication requires the v2 epoch above and supersedes v1 reuse.

Prior PAR.G6CONT1 Native production verification passed 28 Geometry declarations/33 cases and seven public cases on its frozen implementation: unchanged original anExtendedSheetReachesPastItsEdgesAndKeepsThem and removingTheNominalSurfaceCutsTheSplineToItsEdges pass, as does the original zero-extension multi-span whole-domain route. Public low-budget/cancellation and unsupported-continuation cases refuse before publication with original immutable inputs. The contained certifier prepares original common-weight polynomial basis operators once per native axis and checks all initial cells before refining retained unresolved residuals; original bump failures retain toleranceRejected. A 256-cell literal comparison consumes737692 scalars/3538442 work under unchanged standard allowances and certifies an error upper bound2.000000699776224e-9. Varying-weight native preparation remains unchanged. See [Geometry owner](../CADGeometry/GeometryConversion/DESIGN.md) for its original coefficient and paid resource contract. Normal-WASM/Embedded and general G6 publication remain open task integration owners.


### Reblend Whole-Law Admission (PAR.CL11A1)

The Wrap evaluator consumes CADIR's explicit reblends request. Before source mapping/fitting/output mutation, a true request must either possess a producer-owned whole original rolling-ball radius, support incidence and tangency certificate or fail with typed unsupportedCapability carrying the original FeatureID. A FIXME(INCOMPLETE_IMPLEMENTATION) marker at the refusal branch identifies the absent nonlinear closed-chain producer and its completion conditions. The inspected incoming c0c8e3b prototype applies different linear endpoint corrections to Newton section center/contact points, which does not preserve their ball radius or source incidence, and independently sample-fits the round surface/rails. Its few point residuals and final topology/volume checks are not continuous rolling-ball evidence. That prototype and the absent sampled pcurve helper are retained only as an immutable incoming snapshot, not installed on the production success path. Existing false/default Wrap continues independently; this bounded request/persistence unit does not claim Reblend geometry completion.


### Original Periodic C0 Rectangle Tessellation (PAR.M1PC1)

After Geometry's selected-span/lift authority passes lower evidence, MeshTessellator may compose compatible panels from complete original periodic-C0 rectangles. Panel keys retain actual lifted interval/cycle identity and all owning sides. Every triangle stays inside one original panel; compatible edge stations join positions while C0 creases/seams retain independently selected one-sided normal/index duplicates. Existing whole-panel position/normal/curvature bounds, exact cumulative vertices/indices/bytes/preflight reservations, cancellation, face provenance and one FaceRun remain mandatory. No guard-only admission, seam coordinate relabeling, canonical-right normal or copied source authorizes success. Existing C1 periodic and nonperiodic-C0 routes retain their original behavior. Literal single-axis U/V diamond extrusions and double-periodic bilinear tensors verify original stations/normals, seam/corner panel incidence, strict period refusal and cumulative resources before this bounded scope can close.

PAR.G6MULT1 public composition now passes seven declarations/eight cases on an immutable committed production graph plus the exact candidate/consumer overlay. Both common-weight1/7 multi-span continuations match independent literal left/right native quadratic laws at interior and outer chart positions, retain the requested rectangle and immutable inputs, and publish only after the producer certificate. Original extension and nominal-cut oracles plus contained-source, resource, cancellation and varying-weight refusal cases pass unchanged. The [Geometry construction owner](../CADGeometry/GeometryConversion/DESIGN.md#native-knot-polynomial-continuation-candidate-construction) retains its separate lower proof evidence. This closes the bounded Native continuation path; normal-WASM, Embedded and full G6 remain task integration requirements.

### Prepared Boolean Intersections

[Prepared Boolean Operation](PreparedBooleanOperation/DESIGN.md) owns immutable full-graph preparation, operation-independent reuse and complete section publication. BooleanPipeline validates the preparation binding before consumption; its existing classification, exact materialization, sewing and lineage remain the production output path.

### Coincident Region and Imprint Outlines

[Coincident Face Patch Merge](CoincidentFacePatchMerge/DESIGN.md) owns duplicate arranged region elimination before cell extraction. Region Boolean projects both operands' coincident trim outlines into their shared arrangement before provenance-aware merging. Imprint consumes the same clipped exact outline builder, excludes already-existing target boundary spans, and retains both target/tool parameter correspondence. Partial vector projection occlusion retains the existing split-and-filter production path; its continuous visibility certification remains a separate gap.

### Adaptive Trimmed Mesh and Geometric Measurement Children

[Adaptive Trimmed Mesh](AdaptiveTrimmedMesh/DESIGN.md) owns face-specific fidelity preparation and strictest shared-edge fidelity across connected components. [Geometric Measurement](GeometricMeasurement/DESIGN.md) owns geometric measurement publication. Public `KernelQuery.massProperties` and Q4–Q7 query routes compose that child's accuracy, SI units, density, and cumulative work/depth contracts through the runtime adapter; their detailed publication and failure guarantees remain child authority. These component owners provide their implementation and source/behavioral verification contracts; the parent indexes them without duplicating their detailed guarantees.

### Drawing and Document Topology Selection Children

[BRep Drawing](BRepDrawing/DESIGN.md) owns current exact B-rep drawing preparation and source-retaining projected edges. [Document Topology Selection](DocumentTopologySelection/DESIGN.md) owns immutable source/document/B-rep/Mesh/configuration identity binding and triangle-to-persistent-face selection. Their component contracts remain their sole detailed authority.

### Natural Sheet Continuation

[Natural Sheet Extension](NaturalSheetExtension/DESIGN.md) owns exact analytic/procedural support strips along iso-parameter edges. SheetExtend dispatches Natural requests to this retained-support producer before the native B-spline boundary extender. Arbitrary trimmed boundaries, other extension laws and global limit contact certification remain separate producer gaps. DefaultFeatureEvaluator exposes `naturalSheetExtensionLimits: NaturalSheetExtensionLimits` and forwards it unchanged to SheetExtendFeatureEvaluator. The linked child owns the invocation allowance for reach candidates and original arclength proofs; Boolean and sewing keep their own resource owners.

- [Singular Sheet Boundary](SingularSheetBoundary/DESIGN.md): exact closed-span and pole/apex sewing admission.

## Document Cache and Evaluation Report Composition

The module composition roots `DocumentCacheMaterializer` and `EvaluationReport`
preserve the complete assembly artifact, producer validation, and incremental
receipts. A successful report covers exactly the source graph's feature IDs,
retains the source equality binding, and admits only suppression-compatible
states. Empty state collections and foreign feature keys cannot establish
success. Failure reports retain graph-scoped failed and blocked feature IDs.
Native serialization is platform-specific; the value and validation contracts
remain common to Native, WASM, and Embedded consumers. Changes require renewed
cache round-trip and complete/suppressed/failed graph evidence during the
verification phase.

`DocumentCacheValidation` uses the common `PortableSourceEncoder` contract from
[CADIR](../CADIR/DESIGN.md) for complete original geometry content signatures;
Native JSON and base64 representations do not define cache equality. Ordered
topology and geometry multisets compare independent of allocated topology IDs
while retaining every original source leaf value. One invocation accumulator
covers both cached and expected signatures under an explicit encoding limit;
leaf comparisons cannot reset it. This source-encoding limit is independent of
tessellation limits. The legacy convenience entry retains its existing
unbounded (`Int.max`) source-fingerprint policy instead of adding a new default
ceiling.

[Cache Content Identity](CacheContentIdentity/DESIGN.md) owns the immutable
ID-independent original B-rep content traversal consumed by cache validation's
single portable source-encoding invocation.

- [Bridge Surface Wall Trim](BridgeSurfaceWallTrim/DESIGN.md): finite-face intersection and unique connected bridge region publication.

`DefaultFeatureEvaluator.bridgeSourceAdmission` forwards the identical optional caller admission to the [Bridge Surface](../CADModeling/BridgeSurface/DESIGN.md) construction contract. Selected original-source preparation and final semantic certification reuse that work/BYTES owner with independent source, subdivision and algebra capabilities. Nil preserves the legacy route without creating a private aggregate allowance. This composition does not claim whole F7 wall-trim/sewing/resource completion from the selected construction port.

- [Shared Boundary Face Rebuild](SharedBoundaryFaceRebuild/DESIGN.md): joint rebuilt supports with mixed free/shared native boundaries.


Common query and result values retain identical fields, validation and Sendable contracts on Native, WASM and Embedded targets. Dedicated Codable keys, discriminators, decoder initializers and encoders are Native adapters; conditional serialization cannot change the common query path or its value authority.

- [Loft Finite Cap Contact](LoftFiniteCapContact/DESIGN.md) owns finite original cap/side intersection admission through the Modeling port, preserving shared topology contact authority.

- [Sketch Source Chart](SketchSourceChart/DESIGN.md) owns exact authored chart use in sketch curve and profile extraction, including source translation.

Boolean phase, capability, preflight, plan-result and topology-summary values follow the same common-value contract: all stored fields, existing equality/hashability, enum cases and Sendable semantics remain identical on Native, WASM and Embedded. Only Native serialization conformances and their codec bodies are conditional adapters; the Boolean planning and execution algorithm is common.

[BRep Ray Classification](BRepRayClassification/DESIGN.md) owns finite original face UV extent forwarding and actual finite ray-event admission for solid and sheet-side classification.

[Original BRep Bounds](OriginalBRepBounds/DESIGN.md) owns finite original face and body spatial enclosure and caller-bound original position-cell refinement used by query and classification preparation.

[Finite Face Containment](FiniteFaceContainment/DESIGN.md) owns immutable authored-trim preparation and whole original loop containment used by ray classification and finite surface queries.

[Original Solid Classification](OriginalSolidClassification/DESIGN.md) owns
source-bound material parity and immutable bounded classification sessions for
Boolean and public distance queries. Its lower producer and cumulative admission
contracts remain child authority.

- [Original Offset Feasibility](OriginalOffsetFeasibility/DESIGN.md): injected original result-face contact admission for Surface Offset, Thicken and caller-admitted generated sheets. The concrete validator consumes the actual sewn result receipt and borrows the generating invocation's admission; [Original Surface Embedding](../CADGeometry/OriginalSurfaceEmbedding/DESIGN.md) supplies its neutral immutable self-atlas preparation. Shared-boundary and critical lower gaps remain governed by the child contracts.
`DefaultFeatureEvaluator` supplies `DefaultOffsetResultValidator` to Surface
Offset, Thicken, and generated drafted Extrude sheets. These default production
dispatches share the configured validator, and generated sheets borrow their
generating invocation's admission. The child retains responsibility for complete caller admission and
the remaining same-face/critical-sector source obligations.
The additive `offsetFeasibilityLimits` constructor input configures this shared
validator with the same policy value. Nil cumulative limits preserve the
legacy per-proof policies; they cannot establish a bounded aggregate receipt.

- [Finite Curve Clipping](FiniteCurveClipping/DESIGN.md): original finite trim contact partition, proved closed spans and endpoint ancestry for imprint/edit routes.

[Original Trim Contact](OriginalTrimContact/DESIGN.md) owns complete directed sewing-edge contact reductions used by Boolean, Imprint and Natural joins. Its child contract retains whole authored ranges at endpoint contacts and tracks complete critical-root and caller-admission dependencies.

[Original Planar Contours](OriginalPlanarContours/DESIGN.md) owns directed glyph source/contact preparation and nonzero region composition. Native commands supply original line/quadratic/cubic laws; exact Geometry cuts retain original root spans, and Exchange owns legal filled boundary publication.

Edge/face-loop offset composition accepts an optional `EdgeOffsetConversionLimits` policy and forwards it to both evaluators. The invocation-scoped original conversion contract and its limited resource guarantee belong to [Original Edge Offset](OriginalEdgeOffset/DESIGN.md); nil retains historical per-proof conversion policy.

[Original Geometry Query](OriginalGeometryQuery/DESIGN.md) owns same-ledger current source resolution and original knot/span preparation. The query composition preserves source feature/output identity and native span ordinals through original image families; source, subdivision and algebra ceilings remain separate, and no transformed control net supplies query authority.

The original plane-derivative curve/surface family follows that child's general original closest/directional query contract. Its retained traversal and support constraints are source authority; a construction control net or primitive center is not inferred from the corrected law.

[Original Evaluation Source Binding](OriginalEvaluationSourceBinding/DESIGN.md)
owns immutable binding of an evaluated snapshot to its producer-issued original
source receipt. Evaluation and cache materialization derive the document from
that receipt and retain the binding through immutable copies. Publicly created
or decoded snapshots retain no trusted producer binding; read-only consumers
require bounded original semantic validation or an explicit failure before
granting equivalent source authority.


### Exact offset result admission migration
The [Original Offset Feasibility](OriginalOffsetFeasibility/DESIGN.md#exact-consumer-migration-and-retired-legacy-dispatch)
owner retires its unproved interval/opaque contact replay. Its default injected
validator now requires exact consumed receipts; missing family or distinct-face
coverage is an explicit failure before generated-result publication. The child
owns the currently connected scope, remaining coverage and verification.

### Source-bound symbolic SSI compatibility

The geometric SSI array can retain an original coaxial component, including
exact image/UV scope, instead of a rounded parametric circle. Boolean graph
validation and the existing finite UV splitter explicitly refuse this output
until source-relation/material refinement is connected; no absence or complete
Boolean success follows from this gate. Preparation diagnostics count proved
image0/image1 without inventing numeric residual evidence. The representation
contract belongs to [Geometry](../CADGeometry/NativeExactGeometricRelations/DESIGN.md).
The changed dispatch branches require focused graph runtime and primary-file
typechecking; full Boolean/clipping capability remains a separate acceptance cell.
For Embedded, the actual imported graph body/runtime is the representation gate;
existing Foundation-dependent downstream files are not made portable by this
publication. Whole Kernel portability and standalone generic-client packaging
remain unclaimed. The graph imports its already-declared HashTreeCollections
dependency directly on every target.

### Bounded sphere-cone symbolic SSI compatibility

The source-backed component from [Geometry publication](../CADGeometry/NativeExactGeometricRelations/DESIGN.md#bounded-sphere-cone-ssi-publication)
retains exact common XYZ/UV authority. The existing Boolean material/residual
consumer gates reject this representation before numerical validation, just
as for retained coaxial components. Diagnostics count its image1 curve without
assigning a numerical residual. This compatibility update establishes refusal
safety; general Boolean/material clipping and whole Kernel portability are not
completed by the new Geometry family. Verify the affected primary bodies and
actual graph refusal with real ordered sources/IDs when Geometry is stable.

Full sphere-cone symbolic SSI uses the existing original material-refinement
refusal in graph validation and finite splitting. This protects its all-UV
owner; it does not claim completed Boolean clipping.

Full cone-cone original symbolic families join the existing material-refinement
refusal in Boolean graph validation and finite splitting. Their source and all
UV remain retained; this gate is not a completed Boolean clipping claim.

Apex sphere-cone stratified symbolic output joins the existing original
material-refinement refusal gate; unconverted finite splitting cannot discard
the apex full-U fibre or original regular arc source correspondence.

## Canonical Geometry caller composition

The delivery candidate consumes Geometry's canonical ExactScalarAdmission and
OriginalQueryExecution contracts. Existing Kernel callers of removed Geometry
admissions and callback overloads pass the original execution through their
selected mathematical body and retained-owner readers. Ordinary entry points
create one execution; nested operations borrow it. This integration preserves
existing formulas, branch selection, local ceilings and typed failure meaning.
It does not establish independent document, mass, mesh or drawing feature
acceptance. The owning component designs state each changed caller boundary;
the package integration gate must compile the extracted candidate and execute
the public G01 path before delivery is claimed.

The module-level interior sampler shares its existing station/offset traversal between spatial containment and an explicitly supplied original-parameter session. The caller owns proof that the generated parameter and session refer to the same original face/model. [Shared Boundary Face Rebuild](SharedBoundaryFaceRebuild/DESIGN.md) owns the complete native parameter-law gate for its `.given` route; [Finite Face Containment](FiniteFaceContainment/DESIGN.md) owns whole-loop classification and retained session admission. An unavailable parameter witness fails explicitly instead of selecting spatial projection.

### Default Boolean consumer caller binding

`ExactBRepBooleanEvaluator`, `DefaultBooleanUVFaceSplitter` and
`DefaultBooleanRegionClassifier` implement the actual non-generic direct
requirements with one borrowed `OriginalQueryExecution`. Their ordinary entries
create one operation execution and forward to that same implementation. Plans,
UV contact registration, original containment and ray sessions, arrangements,
face-patch materialization and sewing receive that execution through their real
callee edges. Local source, subdivision and algebra ceilings remain independent;
diagnostic entry/stage metadata never selects mathematics or numerical limits.
Body topology removal preserves the existing traversal, mutation order, missing-reference
errors and subshape IDs. Its ordinary entry creates one execution; the admitted entry
passes the same execution through reference collection and the actual model mutation.
Resource and cancellation failures remain throwing at this boundary.
Boolean UV splitting, trim contact, shared/open arrangements and face-patch
materialization add diagnostic text through Geometry's
[diagnostic-only failure boundary](../CADGeometry/NativeExactGeometricRelations/DESIGN.md#direct-public-failure-contract).
They preserve the lower typed cause, classification and query context instead
of passing an erased Geometry failure to Core's foreign-error fallback. This
changes no Boolean geometry, arrangement order, result coverage or local limit.
`KernelDiagnosticFailureClassificationTests` owns nonzero-prefix work refusal,
genuine empty graph and nonempty crossing-line controls, and lower cancellation.
The UV splitter imports HashTreeCollections directly for original topology-map
access. Its implementation uses no Foundation API; every target retains the
same source arithmetic, caller execution and immutable containment providers.
Its point, parameter, residual and recovered-contact readers use noncapturing
field closures on all targets. They preserve the same getters, traversal and
array operations without requiring runtime keypath metadata. Graph validation
keeps both current-task cancellation guards at their original positions.

```text
ordinary entry -> one execution -> default direct witness
admitted entry -----------------> default direct witness
    -> source validation / clipping / classification
    -> retained session readmission / arrangement / materialization
    -> selected sewing request / existing sewing witness -> cancellation check
```

Retained classification and containment payloads keep their immutable source,
issuing budget, effective limits, attained preparation depth and selected
contribution handles. Readers preflight depth before paid reattachment and keep
the same handles active around the actual query body. Ordinary retained readers
resume their issuing budget rather than allocating a replacement budget.

The original MAIN mathematical formulas, branch selection, winding/parity,
periodic seams, material inversion, contact ordering and accepted materialization
strategies are preserved. A raw Boolean graph remains a constructive input:
structural validation and actual raw-source validation do not certify its
intersection completeness. A validated model authorizes that immutable model's
source only. These caller bindings neither create an original graph authority
nor complete general Boolean clipping, generated lineage or M7 acceptance.
Source-family gaps keep their existing explicit failures and incomplete markers.

The binding inventory records each selected source path and its exact lower
callee edge. Focused verification must distinguish the concrete direct witness
from a protocol fallback, retain cumulative work/storage refusal and cancellation,
and exercise retained contribution readmission. Package compilation establishes
API coherence only; broader Boolean mathematics requires its existing behavioral
owners' separate evidence.

Specialized orthogonal request generation retains its existing occupied-grid,
connected-component, exterior/void-shell and planar-cycle algorithms. Actual
cell/edge visits and lower source projection, planar predicates and sewing borrow
the same execution as the Boolean evaluator. Local grid ceiling 1,000,000 and all
existing tolerance comparisons remain unchanged; overflow is explicit failure.

### Boolean generated-output lineage authority

BooleanTopologyLineageBuilder validates and retains complete issued sewing
lineage. Every published output must already be covered by that provenance.
When generated-output correspondence is absent, the canonical caller path fails
with unsupportedCapability until an original source-bound producer exists.
Distance/angular tolerance, callback presence and diagnostic execution entry
never establish parent identity. The old unproved matching implementation is
removed; this does not implement a new Boolean history producer or close its
required source-family coverage. Focused binding checks cover complete retained
provenance, absent provenance under both entry contexts, resource refusal and
cancellation.

[BooleanLineageCanonicalBindingTests](../../Tests/CADKernelTests/BooleanLineageCanonicalBindingTests.swift)
owns those narrow source-authority and failure controls. The fixture is source
ready; its actual execution awaits the candidate integration compiler slot.

The edge-offset imprint dependency keeps the existing completion, representative
point, two-pass arrangement and neighbour-face algorithms. Its direct operations
borrow the edge-offset execution through native pcurve reads, intersections,
subdivision, closest proposals and final sewing/model validation. Ordinary
compatibility entries create one execution and call those same bodies; they do
not duplicate the former unmetered implementation.

SweepEvaluationPlanService binds its existing original span/section and certified
plan consumers to one execution. The ordinary plan creates its existing curved
source envelope; direct planning selects the same GeometryConversionRequirements
work, scalar-storage, depth20, scalar32 and native-span limits as a contribution.
The existing planning branches, guide retention and numeric/capability decisions
remain unchanged. Document/sketch extraction and display path-frame preparation
remain ordinary providers with an explicit incomplete-accounting marker; this
API binding does not add sweep capability or claim complete preflight accounting.

### Sweep Original Path Authority
Both ordinary and direct SweepEvaluationPlanService entries resolve selected
section/path laws through the original-source constructor contract. Execution
context and accounting capability do not select display trim/reversal semantics.
Display sample reconstructions cannot authorize original source or traversal;
missing original construction propagates explicit unsupported. Existing
display-only resolveCurve consumers outside Sweep are not migrated by this
binding, and unsupported required inputs remain unconverted.

| Input | Prior Sweep preparation | Canonical Sweep preparation |
|---|---|---|
| Whole original source | Retained native law | Same retained native law and source guards |
| Selected or reversed section in orderedPathSegments | Ordinary display trim/reversal could reconstruct samples | Original parameter-image/trim receipt retains native traversal; missing constructor refuses |
| Selected or reversed section in plan | Original admission selected source preparation | Same original preparation through the borrowed execution |

The display-only API is not a fallback for either Sweep entry. This narrow
authority change requires actual selected/reversed-source behavioral evidence
in the integration gate; it does not establish whole U1 completion.

The native Kernel binding gate requires the existing actual consumer body to
borrow OriginalQueryExecution through changed containment, arrangement, source
validation and scalar readers. Ordinary operation entries root once. Pure
structural/interpolation helpers keep their existing signatures; throwing
topology getters propagate failure. Existing formulas, ordering, selected domains
and independent local ceilings remain authoritative. This is API/caller repair,
not new feature or whole-resource completion evidence.
