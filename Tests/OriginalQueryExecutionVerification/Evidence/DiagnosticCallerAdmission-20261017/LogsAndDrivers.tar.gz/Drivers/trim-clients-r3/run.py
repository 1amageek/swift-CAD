#!/usr/bin/env python3
"""Reuse actual current Model6 and compile the two real corrected Kernel inputs for Trim3."""
import argparse,hashlib,json,os,pathlib,shutil,sys,time
B=pathlib.Path(__file__).resolve().parent;R=B.parent
C=pathlib.Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
H=pathlib.Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0,str(H))
from native_tests import run,RSS_BYTES
OLD={'asan':'453d85bf80a0ce95c3b117f7ad9d95c4a7074245e2c03248bef6f285e8b95923','wasm':'02630e69da52831df999e5246f15ebf40bb8b52fa966058c3cecdbc45d7301eb','embedded':'cdceba7dc7ab10ff74ba997de41d8a68b7cba51cb1679b1358b67e611f8474d1'}
CHANGED='Sources/CADKernel/OriginalTrimContact/ExactTrimEdgeIntersector.swift'
BEFORE='8f5734e1e0d4d76cfebc2db47d581bfc00bfe7a109e50e864d3a61d991cfa4b9'
AFTER='a0cc1aa9e24a20244460cd2f8cb11596104597f1c8695708805e3ee3bc878e2b'
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(c,m):
 if not c:raise RuntimeError(m)
def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
def prepare(lane):
 out=B/lane;out.mkdir(exist_ok=False);pins={}
 def pin(p,h=None):
  p=pathlib.Path(p);v=sha(p);require(h is None or h==v,'Hash differs: '+str(p));require(str(p) not in pins or pins[str(p)]==v,'Conflicting hash: '+str(p));pins[str(p)]=v;return v
 origin=R/'trim-clients-r2'/lane/'receipt.json';pin(origin,OLD[lane]);old=json.loads(origin.read_text())
 require(not old['postflightDrift'],'Origin terminal drift.')
 require(old['steps']['CADModeling']['exitCode']==0 and old['steps']['CADModeling']['stopReason'] is None,'Model6 origin did not compile successfully.')
 require(len(old['moduleSources']['CADModeling'])==6,'Expected six actual Modeling inputs.')
 for p,h in old['inputAndProductSHA256'].items():
  if p!=str(C/CHANGED):pin(p,h)
 model_products={p:h for p,h in old['compiledProductSHA256'].items() if pathlib.Path(p).name.startswith('CADModeling.')}
 require(len(model_products)==(1 if lane=='embedded' else 2),'Model6 actual products missing.')
 for p,h in model_products.items():pin(p,h)
 native=R/'native-full-r4/receipt.json';pin(native,'6d7137de3f39275a21799e434327cac3ca74d3411e35ef38f69574966e2edc61');n=json.loads(native.read_text())
 require(len(n['sourceSHA256'])==3927 and n['sourceSHA256'][CHANGED]==BEFORE,'Expected immutable historical Kernel source authority.')
 require(n['steps']['CADModeling']['exitCode']==0 and n['steps']['CADKernel']['exitCode']==0,'Native source-subset origin failed.')
 for rel,h in n['sourceSHA256'].items():pin(C/rel,AFTER if rel==CHANGED else h)
 old_file=origin.parent/'snapshot'/CHANGED;pin(old_file,BEFORE);text=old_file.read_text()
 substitutions=[('.compactMap(\\.classification.residual)','.compactMap { $0.classification.residual }',2),('.map(\\.x)','.map { $0.x }',4),('.map(\\.y)','.map { $0.y }',4),('keyPath: \\.x','coordinate: { $0.x }',5),('keyPath: \\.y','coordinate: { $0.y }',5),('keyPath: KeyPath<Point2D, Double>','coordinate: (Point2D) -> Double',2),('$0[keyPath: keyPath]','coordinate($0)',2),('firstPoint[keyPath: keyPath]','coordinate(firstPoint)',1),('point[keyPath: keyPath]','coordinate(point)',1)]
 for before,after,count in substitutions:
  require(text.count(before)==count,'Mechanical correction count differs: '+before);text=text.replace(before,after)
 require(text==(C/CHANGED).read_text(),'Mechanical correction changed other bytes.')
 kernel=dict(old['moduleSources']['CADKernel']);kernel[CHANGED]=AFTER
 require(len(kernel)==2,'Kernel must remain the actual two-file closure.')
 for rel,h in kernel.items():
  pin(C/rel,h);dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/rel,dest);pin(dest,h)
 rsp=out/'CADKernelSources.rsp';rsp.write_text(''.join('"'+str(out/'snapshot'/rel)+'"\n' for rel in sorted(kernel)));pin(rsp)
 modules=out/'modules';modules.mkdir()
 cmd=old['commands']['CADKernel'][:];cmd=[cmd[0],'-I',str(modules)]+cmd[1:]
 target=modules/'CADKernel.swiftmodule';cmd[cmd.index('-emit-module-path')+1]=str(target);products=[str(target)]
 if lane!='embedded':
  obj=modules/'CADKernel.code.o';cmd[cmd.index('-o')+1]=str(obj);products.append(str(obj))
 cmd[-1]='@'+str(rsp)
 replacements={}
 for rel,h in old['fixtureSHA256'].items():
  pin(C/rel,h);dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/rel,dest);pin(dest,h);replacements[str(origin.parent/'snapshot'/rel)]=str(dest)
 link=[replacements.get(v,v) for v in old['commands']['client-link']];link=[link[0],'-I',str(modules)]+link[1:]
 if lane!='embedded':
  old_object=str(origin.parent/'modules/CADKernel.code.o');require(link.count(old_object)==1,'Expected one old Kernel object.');link[link.index(old_object)]=str(modules/'CADKernel.code.o')
 exe=out/('TrimDiagnostic' if lane=='asan' else 'TrimDiagnostic.wasm');link[link.index('-o')+1]=str(exe)
 runtime=[str(exe) if v==old['executable'] else v for v in old['commands']['runtime']]
 prior=old['priorCoreGeometryTopologyIRCompileSeconds']+sum(s['elapsedSeconds'] for s in old['steps'].values())
 pin(__file__);pin(H/'native_tests.py')
 plan={'status':'prepared-not-executed','lane':lane,'scope':'Actual corrected whole-file Kernel2 plus the same three trim checks. Reuses actual current Model6 and accepted Core/Geo/Topo/IR only. No UV, Bridge or whole Kernel acceptance.','moduleRegeneration':1,'modelRegeneration':0,'lowerModuleRegeneration':0,'moduleSources':{'CADKernel':kernel},'retainedModelSourceSHA256':old['moduleSources']['CADModeling'],'retainedModelProducts':model_products,'retainedModelCompilerPhase':old['steps']['CADModeling'],'origin':{'path':str(origin),'sha256':pins[str(origin)],'acceptedScope':'Successful current Modeling6 phase and products only; Embedded failed Kernel phase remains failed.'},'nativeSourceSubsetAuthority':{'path':str(native),'sha256':pins[str(native)],'scope':'Current lower and Model6 source identities plus unchanged Kernel helper; old Native Kernel binary is not current ExactTrim proof.'},'sourceCorrection':{'path':CHANGED,'beforeSHA256':BEFORE,'afterSHA256':AFTER,'substitutionCount':26,'proof':'Exact 26 mechanical replacements reproduce the current whole source; all remaining 3926 production files match the immutable Native r4 source authority.'},'fixtureSHA256':old['fixtureSHA256'],'expectedOutputLines':old['expectedOutputLines'],'commands':{'CADKernel':cmd,'client-link':link,'runtime':runtime},'products':{'CADKernel':products},'executable':str(exe),'priorCompileSeconds':prior,'bounds':old['bounds'],'inputAndProductSHA256':pins}
 write(out/'plan.json',plan);print(json.dumps({'status':'prepared','lane':lane,'pins':len(pins),'planSHA256':sha(out/'plan.json'),'remainingCompileLinkSeconds':1200-prior}))
def execute(lane):
 out=B/lane;path=out/'plan.json';plan=json.loads(path.read_text());require(not(out/'receipt.json').exists(),'Existing terminal/run receipt must be preserved.')
 pins=dict(plan['inputAndProductSHA256']);pins[str(path)]=sha(path)
 def drift():return [p for p,h in pins.items() if not pathlib.Path(p).is_file() or sha(p)!=h]
 require(not drift(),'Preflight drift.')
 r=dict(plan);r.update({'status':'running','steps':{},'inputAndProductSHA256':pins});save=lambda:write(out/'receipt.json',r)
 try:
  env=dict(os.environ);env.pop('TOOLCHAINS',None);env['ASAN_OPTIONS']='halt_on_error=1:abort_on_error=1';deadline=time.monotonic()+max(0,1200-plan['priorCompileSeconds']);save()
  for name,cmd in plan['commands'].items():
   s=run(cmd,out/(name+'.log'),env,deadline=time.monotonic()+120 if name=='runtime' else deadline,stage_limit=120 if name=='runtime' else 1200);r['steps'][name]=s;pins[str(out/(name+'.log'))]=s['logSHA256']
   if name=='CADKernel' and s['exitCode']==0 and s['stopReason'] is None:
    for p in plan['products']['CADKernel']:r.setdefault('compiledProductSHA256',{})[p]=sha(p);pins[p]=sha(p)
   if name=='client-link' and s['exitCode']==0:r['executableSHA256']=sha(plan['executable']);pins[plan['executable']]=r['executableSHA256']
   save();require(s['exitCode']==0 and s['stopReason'] is None,name+' failed; inspect actual log.')
  actual=[v for v in (out/'runtime.log').read_text().splitlines() if v.startswith('PASS ')];require(actual==plan['expectedOutputLines'],'Actual Trim3 output differs.')
  r['postflightDrift']=drift();require(not r['postflightDrift'],'Postflight drift.');r['sourcesProductsAndLogsUnchanged']=True;r['status']='passed';save();print(json.dumps({'status':'passed','lane':lane,'oracles':len(actual),'receipt':str(out/'receipt.json')}))
 except Exception as e:
  r['status']='failed';r['failure']=str(e);r['postflightDrift']=drift();save();raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=['asan','wasm','embedded']);a=p.parse_args()
 if a.prepare:
  for lane in ([a.lane] if a.lane else ['asan','wasm','embedded']):prepare(lane)
 else:require(a.lane is not None,'Lane required.');execute(a.lane)
