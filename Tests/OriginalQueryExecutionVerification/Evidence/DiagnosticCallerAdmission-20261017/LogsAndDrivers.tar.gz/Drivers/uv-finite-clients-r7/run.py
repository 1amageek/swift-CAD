#!/usr/bin/env python3
"""Compile actual Kernel30 on current retained Model17 and execute eight shared caller checks."""
import argparse,hashlib,json,os,pathlib,shutil,sys,time
B=pathlib.Path(__file__).resolve().parent;R=B.parent
C=pathlib.Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
H=pathlib.Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0,str(H))
from native_tests import run,RSS_BYTES
NATIVE_SHA='96022991cbe7e96ead20646f1fa8e7c904f330ac62aefd51f7ec22d70a7cf172'
FIXTURES={'Tests/CADKernelTests/KernelUVSplitDiagnosticChecks.swift':'2177a88255def582458ddc9c92b24d79f62b65fb9235f79fff4480d656ad6875','Tests/CADKernelTests/FinitePlaneContainmentAdmissionChecks.swift':'601a7eab03343430e59754500f5d422bafd2255a451892b21ef016e70da340ea'}
ENTRY='''@main
struct UVFinitePlanePortable {
    static func main() throws {
        try KernelUVSplitDiagnosticChecks.emptyGraphRemainsAGenuineEmptySplit()
        print("PASS emptyGraphRemainsAGenuineEmptySplit")
        try KernelUVSplitDiagnosticChecks.lowerWorkRefusalRetainsItsOriginalClassification()
        print("PASS lowerWorkRefusalRetainsItsOriginalClassification")
        try KernelUVSplitDiagnosticChecks.lowerCallerCancellationRetainsItsOriginalCause()
        print("PASS lowerCallerCancellationRetainsItsOriginalCause")
        try KernelUVSplitDiagnosticChecks.externalProviderRetainsItsEmptyCapabilityFallbackAndCaller()
        print("PASS externalProviderRetainsItsEmptyCapabilityFallbackAndCaller")
        try KernelUVSplitDiagnosticChecks.exactPlanarCutRetainsItsSourceAndUVLaw()
        print("PASS exactPlanarCutRetainsItsSourceAndUVLaw")
        try FinitePlaneContainmentAdmissionChecks.finitePlaneProximityUsesRetainedMaterialAndSource()
        print("PASS finitePlaneProximityUsesRetainedMaterialAndSource")
        try FinitePlaneContainmentAdmissionChecks.finiteBoundsAndOutsideToleranceKeepTheirCompletePath()
        print("PASS finiteBoundsAndOutsideToleranceKeepTheirCompletePath")
        try FinitePlaneContainmentAdmissionChecks.primitiveProjectionPreservesCallerWorkAndCancellation()
        print("PASS primitiveProjectionPreservesCallerWorkAndCancellation")
    }
}
'''
EXPECTED=[v.split('print("')[1].split('")')[0] for v in ENTRY.splitlines() if 'print("PASS ' in v]
def sha(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(c,m):
 if not c:raise RuntimeError(m)
def write(p,r):p.write_text(json.dumps(r,indent=2)+'\n')
def prepare(lane):
 require(lane=='embedded','Only the released Embedded lane is prepared by this frozen plan.')
 out=B/lane;out.mkdir(exist_ok=False);pins={}
 def pin(p,h=None):
  p=pathlib.Path(p);v=sha(p);require(h is None or h==v,'Hash differs: '+str(p));require(str(p) not in pins or pins[str(p)]==v,'Conflicting hash: '+str(p));pins[str(p)]=v;return v
 origin=R/'uv-finite-clients-r6/embedded/receipt.json';pin(origin,'4056fae83871e02339673491efc981534a4d5952213b109b28f573d7e86c6866');old=json.loads(origin.read_text());require(not old['postflightDrift'],'Prior compiler had drift.')
 native=R/'native-full-r9/receipt.json';pin(native,NATIVE_SHA);n=json.loads(native.read_text())
 require(len(n['sourceSHA256'])==3928 and all(s['exitCode']==0 and s['stopReason'] is None for s in n['steps'].values()),'Actual Native r9 authority is not accepted.')
 capability='Sources/CADKernel/FiniteFaceContainment/FacePointContainmentCapabilities.swift'
 kernel={rel:n['sourceSHA256'][rel] for rel in old['moduleSources']['CADKernel']};kernel[capability]=n['sourceSHA256'][capability]
 require(len(kernel)==30,'Expected exactly Kernel29 plus the actual capability owner.')
 expected_changes={'Sources/CADKernel/DefaultBooleanUVFaceSplitter.swift'}
 changes={rel:kernel[rel] for rel,h in old['moduleSources']['CADKernel'].items() if kernel[rel]!=h};require(set(changes)==expected_changes,'Only the reported ordinal-reader source line may change from r6.')
 substitutions={'Sources/CADKernel/DefaultBooleanUVFaceSplitter.swift':[('      let keptOrdinals = Set(result.map(\\.ordinal))','    let keptOrdinals = Set(result.map { $0.ordinal })')]}
 for rel,items in substitutions.items():
  previous=origin.parent/'snapshot'/rel;pin(previous,old['moduleSources']['CADKernel'][rel]);text=previous.read_text()
  for before,after in items:
   require(text.count(before)==1,'Expected one original keypath accessor: '+before);text=text.replace(before,after)
  require(text==(C/rel).read_text(),'Ordinal-reader correction changed other bytes: '+rel)
 excluded={str(C/rel) for rel in changes}|{str(C/'Tests/CADKernelTests/KernelUVSplitDiagnosticChecks.swift')}
 for p,h in old['inputAndProductSHA256'].items():
  if p not in excluded:pin(p,h)
 models=old['retainedModelSourceSHA256'];require(len(models)==17,'Expected actual retained Model17.')
 require(old['retainedModelCompilerPhase']['exitCode']==0 and old['retainedModelCompilerPhase']['stopReason'] is None,'Retained Model17 phase is not successful.')
 for rel,h in models.items():require(n['sourceSHA256'][rel]==h,'Current Native Model source differs: '+rel);pin(C/rel,h)
 model_products=old['retainedModelProducts'];require(len(model_products)==1,'Embedded serialized Model product missing.')
 for p,h in model_products.items():pin(p,h)
 caller=R/'native-uv-capability-r1/receipt.json';pin(caller);caller_receipt=json.loads(caller.read_text());require(caller_receipt['status']=='passed','Native eight-caller gate not passed.')
 for rel,h in kernel.items():
  pin(C/rel,h);dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/rel,dest);pin(dest,h)
 rsp=out/'CADKernelSources.rsp';rsp.write_text(''.join('"'+str(out/'snapshot'/rel)+'"\n' for rel in sorted(kernel)));pin(rsp)
 modules=out/'modules';modules.mkdir();target=modules/'CADKernel.swiftmodule'
 cmd=old['commands']['CADKernel'][:];cmd=[cmd[0],'-I',str(modules)]+cmd[1:];cmd[cmd.index('-emit-module-path')+1]=str(target);cmd[-1]='@'+str(rsp)
 replacements={}
 for rel,h in FIXTURES.items():
  pin(C/rel,h);dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(C/rel,dest);pin(dest,h);replacements[str(origin.parent/'snapshot'/rel)]=str(dest)
 entry=B/'UVFinitePlanePortable.swift';entry.write_text(ENTRY);pin(entry)
 private=out/'snapshot/Portable/UVFinitePlanePortable.swift';private.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(entry,private);pin(private,pins[str(entry)]);replacements[old['clientInputs'][-1]]=str(private)
 portable_sources={'Tests/OriginalQueryExecutionVerification/KernelUVSplitDiagnosticPortable.swift':'893f8b29097c50e5e8386847dd914cc76085a108e1023f6c73e5cd24b1d6ad43','Tests/OriginalQueryExecutionVerification/FinitePlaneContainmentAdmissionPortable.swift':'43fcddad23bb1b90ebd79cf1ec563bfd0fd92c12ee4da189f0a30486c56afec9'}
 for rel,h in portable_sources.items():pin(C/rel,h)
 link=[replacements.get(v,v) for v in old['commands']['client-link']];link=[link[0],'-I',str(modules)]+link[1:]
 exe=out/'UVFinitePlane.wasm';link[link.index('-o')+1]=str(exe);runtime=[str(exe) if v==old['executable'] else v for v in old['commands']['runtime']]
 require(sum(v in replacements.values() for v in link)==3,'Exactly two real shared sources plus one thin private entry must be compiled.')
 prior=old['priorCompileSeconds']+sum(s['elapsedSeconds'] for s in old['steps'].values());pin(__file__);pin(H/'native_tests.py')
 plan={'status':'prepared-not-executed','lane':lane,'scope':'Actual current Kernel30 with existing Model17 and lower products, five UV and three finite-plane checks. Actual default cached witness and external public provider same-caller fallback; no Bridge/Exchange/whole Kernel claim.','nativeCurrentAuthority':{'path':str(native),'sha256':pins[str(native)]},'nativeEightCallerProof':{'path':str(caller),'sha256':pins[str(caller)],'scope':'Actual r7 eight-caller behavior before the four accessor-only replacements; current r9 compiler authority and current Embedded runtime are recorded separately.'},'moduleRegeneration':1,'modelRegeneration':0,'lowerModuleRegeneration':0,'moduleSources':{'CADKernel':kernel},'retainedModelSourceSHA256':models,'retainedModelProducts':model_products,'retainedModelCompilerPhase':old['retainedModelCompilerPhase'],'retainedModelOrigin':old['retainedModelOrigin'],'predecessor':{'path':str(origin),'sha256':pins[str(origin)],'acceptedScope':'Successful retained Model17 only. Previous Kernel diagnostics stay failed.'},'kernelFindingChanges':changes,'mechanicalReaderCorrection':{'fileCount':1,'accessCount':1,'proof':'Exact ordinal source-line replacement (including indentation) reconstructs the current whole file byte-for-byte; every other Kernel30 and Model17 source matches current Native r9.'},'newCapabilitySource':{capability:kernel[capability]},'fixtureSHA256':FIXTURES,'originalPortableEntrySHA256':portable_sources,'privateClientOrchestrator':{'path':str(entry),'sha256':pins[str(entry)],'role':'Eight actual shared check calls and PASS prints only; no production substitute or math.'},'clientInputs':list(replacements.values()),'commands':{'CADKernel':cmd,'client-link':link,'runtime':runtime},'products':{'CADKernel':[str(target)]},'executable':str(exe),'expectedOutputLines':EXPECTED,'priorCompileSeconds':prior,'bounds':old['bounds'],'inputAndProductSHA256':pins}
 write(out/'plan.json',plan);print(json.dumps({'status':'prepared','pins':len(pins),'remainingCompileLinkSeconds':1200-prior,'planSHA256':sha(out/'plan.json')}))
def execute(lane):
 out=B/lane;path=out/'plan.json';plan=json.loads(path.read_text());require(not(out/'receipt.json').exists(),'Existing run receipt must remain immutable.')
 pins=dict(plan['inputAndProductSHA256']);pins[str(path)]=sha(path)
 def drift():return [p for p,h in pins.items() if not pathlib.Path(p).is_file() or sha(p)!=h]
 require(not drift(),'Preflight drift.');r=dict(plan);r.update({'status':'running','steps':{},'inputAndProductSHA256':pins});save=lambda:write(out/'receipt.json',r)
 try:
  env=dict(os.environ);env.pop('TOOLCHAINS',None);env['ASAN_OPTIONS']='halt_on_error=1:abort_on_error=1';deadline=time.monotonic()+max(0,1200-plan['priorCompileSeconds']);save()
  for name,cmd in plan['commands'].items():
   s=run(cmd,out/(name+'.log'),env,deadline=time.monotonic()+120 if name=='runtime' else deadline,stage_limit=120 if name=='runtime' else 1200);r['steps'][name]=s;pins[str(out/(name+'.log'))]=s['logSHA256']
   if name=='CADKernel' and s['exitCode']==0 and s['stopReason'] is None:
    for p in plan['products']['CADKernel']:r.setdefault('compiledProductSHA256',{})[p]=sha(p);pins[p]=sha(p)
   if name=='client-link' and s['exitCode']==0:r['executableSHA256']=sha(plan['executable']);pins[plan['executable']]=r['executableSHA256']
   save();require(s['exitCode']==0 and s['stopReason'] is None,name+' failed; inspect actual log.')
  actual=[v for v in (out/'runtime.log').read_text().splitlines() if v.startswith('PASS ')];require(actual==EXPECTED,'Actual eight-caller output differs.');r['postflightDrift']=drift();require(not r['postflightDrift'],'Postflight drift.');r['sourcesProductsAndLogsUnchanged']=True;r['status']='passed';save();print(json.dumps({'status':'passed','oracles':len(actual),'receipt':str(out/'receipt.json')}))
 except Exception as e:
  r['status']='failed';r['failure']=str(e);r['postflightDrift']=drift();save();raise
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--prepare',action='store_true');p.add_argument('--lane',choices=['embedded'],required=True);a=p.parse_args()
 if a.prepare:prepare(a.lane)
 else:execute(a.lane)
