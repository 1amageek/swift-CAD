@main
struct UVFinitePlanePortable {
    static func main() throws {
        try KernelUVSplitDiagnosticChecks.emptyGraphRemainsAGenuineEmptySplit()
        print("PASS emptyGraphRemainsAGenuineEmptySplit")
        try KernelUVSplitDiagnosticChecks.lowerWorkRefusalRetainsItsOriginalClassification()
        print("PASS lowerWorkRefusalRetainsItsOriginalClassification")
        try KernelUVSplitDiagnosticChecks.lowerCallerCancellationRetainsItsOriginalCause()
        print("PASS lowerCallerCancellationRetainsItsOriginalCause")
        try KernelUVSplitDiagnosticChecks.externalProviderRetainsItsEmptyCapabilityFallbackAndCaller()
        print("PASS externalProviderRetainsItsEmptyCapabilityFallbackAndCaller")
        try KernelUVSplitDiagnosticChecks.exactPlanarCutRetainsItsSourceAndUVLaw()
        print("PASS exactPlanarCutRetainsItsSourceAndUVLaw")
        try FinitePlaneContainmentAdmissionChecks.finitePlaneProximityUsesRetainedMaterialAndSource()
        print("PASS finitePlaneProximityUsesRetainedMaterialAndSource")
        try FinitePlaneContainmentAdmissionChecks.finiteBoundsAndOutsideToleranceKeepTheirCompletePath()
        print("PASS finiteBoundsAndOutsideToleranceKeepTheirCompletePath")
        try FinitePlaneContainmentAdmissionChecks.primitiveProjectionPreservesCallerWorkAndCancellation()
        print("PASS primitiveProjectionPreservesCallerWorkAndCancellation")
    }
}
