#!/usr/bin/env python3
"""Compile the actual current Modeling17 and Kernel30 closure, then execute eight shared UV and finite-plane checks."""
import argparse, hashlib, json, os, pathlib, shlex, shutil, sys, time
BASE=pathlib.Path(__file__).resolve().parent
ROOT=BASE.parent
SOURCE=pathlib.Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
HARNESS=pathlib.Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0,str(HARNESS))
from native_tests import run,RSS_BYTES
MODULES={'CADModeling': {'Sources/CADModeling/BRepSewingEdge.swift': 'ca569c702b97b780b66acf9cb46164017f0367772ed88bfacd476bf60e7853e4', 'Sources/CADModeling/BRepSewingEdgeSubdivider.swift': '973861c2a55e26c8e625e31795e3499a462f53a65b27f0f1b3d4f57280a4b387', 'Sources/CADModeling/BRepSewingFacePatch.swift': 'a0d959706a746989c9ebbd476cf797e859ee85b59d16063843c0386830dd933f', 'Sources/CADModeling/BRepSewingLoop.swift': '02e563a759a026906beda0efe3f0d6f406576685de13c7922d563f0da958b8d3', 'Sources/CADModeling/BRepSewingStableKey.swift': '52cf2876c201d565539a98ee71659f3e9440defb08f21785a4378629468ddb41', 'Sources/CADModeling/BoundedSewingValidation/OriginalSewingPatchValidator.swift': '532001933cedbf52e22ec119ac83c8d3d69007749253210e1a2907d5fbc065a7', 'Sources/CADModeling/CurveSpanDefinition.swift': 'd27ef85dd01e72cfaccfa3dee646c632b1cce2d91c2d7ce94b1a7f198fdab75a', 'Sources/CADModeling/ExactFacePcurve/ExactFacePcurveBuilder.swift': '734166a982b9ecdaa5ec001ff95ea50e2fa25bae4bd5c3768b47b85258193d34', 'Sources/CADModeling/OriginalCurveSpanCoincidence/CurveSpanCoincidenceMatcher.swift': 'e33117c68b012760a9634e11c630e261383f5319dbfd453a1138fd8ca2aaf2c1', 'Sources/CADModeling/OriginalCurveSpanCoincidence/OriginalCurveSpanCoincidenceCertifier.swift': 'c146e24128c05d391022dea13982905155b6b4a906595144825fd9247228a2f7', 'Sources/CADModeling/SewingProvenance/AdmittedSewingProvenance.swift': 'd2672ad5638fe0a40cf9609218995e1c9c91cc953a8d7ed523e2ee05f72982c7', 'Sources/CADModeling/SourceFacePatch/SourceBRepFacePatchBuilder.swift': 'a8f0293a8e308b1cbfccb3bfbf9e7f70441691c92dd10e8edb0fe48dbbfe371f', 'Sources/CADModeling/BRepSewingRequest.swift': 'dff5375ee4476c00fbe4f3ad24d85ff177c31f96ea778b2cd42f28bd0c9c61bf', 'Sources/CADModeling/BRepSewingBodyTopology.swift': 'bf62df41fbaf630fab2804648ae3d89c0f322e3a2c9630b2ee7770d3c8e3d7c9', 'Sources/CADModeling/BRepSewingShell.swift': '6464b0122ef26823e97151dcd11266040710d4775d64414de54647921ddb815d', 'Sources/CADModeling/BRepSewingSolidComponent.swift': '53b8e5266e4ddde456a36becd6667c5e78d8585334fc7bb13a1d25aba1efcb25', 'Sources/CADModeling/BRepSewingTopologyNamespace.swift': 'db27d91fc4733a0199af3b6bc953be866f862bf67a80e1df846b8e9f89e28426'}, 'CADKernel': {'Sources/CADKernel/BooleanBoundaryContact.swift': '12088acf2842d11bd79cbf249cfeb0829318dad4cd5e1f73d07ab179c2b6745a', 'Sources/CADKernel/BooleanBoundaryContactGeometry.swift': '003e5c584ce8e84a454dd65ca7d0529e97afc614fbbde2568cc9fa33b01d005a', 'Sources/CADKernel/BooleanClosedFaceIntersection.swift': 'a79657d61b3a59e0010a18ee9e8103a466a285f2bcca44358575e766b467032b', 'Sources/CADKernel/BooleanCurveUVSample.swift': '706c82073ed79f5bf3fbe89a3329cd81ac1ac84af5168f1d0ab138bdd3ca1e74', 'Sources/CADKernel/BooleanFacePairCandidate.swift': 'a0f49ca6a6f465fea0d1fc97267add15e5320d0e61b489cee356cd1bfa90a77c', 'Sources/CADKernel/BooleanFaceSplit.swift': '8c341d90061e548745a5841a66b161ce4bd586d74b7be3d0d9658f4ede350bc2', 'Sources/CADKernel/BooleanFaceSplitComponent.swift': '3f9f986b2253eba349a6511018b75cf141a3f92bdc3bc71d928decc4e86e0745', 'Sources/CADKernel/BooleanFaceSplitComponentGeometry.swift': '9c44497a5f7e6ff6b338e86cf2c5ea3f77d912cce07c7e6d8145938e55c9176e', 'Sources/CADKernel/BooleanFaceSplitComponentID.swift': 'ad2795ef13f8a82f6dd63560d3bb938610e2f95c09c40db5ed77fe8f9d1dcca5', 'Sources/CADKernel/BooleanFaceSurfaceIntersection.swift': '3c1d7120ecc63d2b84dedbd7686deedbaa54fa1a13a39ed11557eaf51c4aac04', 'Sources/CADKernel/BooleanIntersectionGraph.swift': 'b7e8ba0ea46f56af8349804d0c35239406bcb29dffedc02b945a7c85d17a0e65', 'Sources/CADKernel/BooleanTrimmedFaceIntersection.swift': '0fbf5c35d7a6bcd88442915eba47368145619dc870b1a68c68acc34ae71e3297', 'Sources/CADKernel/BooleanTrimmedFaceIntersectionChain.swift': 'db80c2b0ac25af20d6a8826f3205f6813388e1441b6f5b9238a71911f8a4a6c5', 'Sources/CADKernel/BooleanUVFaceSplitting.swift': 'e68bf045064382547c6fc546ceb1fb4d613ebb9ed37625d6f3c9ff83aa559afc', 'Sources/CADKernel/BooleanUVPoint.swift': '747ed1d3df4413e29e4a189c136013b92d8d7ff0d53edbf0d60ed7ab7f5655cc', 'Sources/CADKernel/BooleanUVSplitGraph.swift': '3306e0ca49f17fc5f99987166ca2630c0765bd632ec4378e36a0d69898b6a11d', 'Sources/CADKernel/CoincidentFaceOverlapTester.swift': '127e0d1cfd43635753c9d58e7e2ef6c72593058b410ec89351ae858f28f95064', 'Sources/CADKernel/CoincidentFacePatchMerge/FiniteCoincidentFaceAreaClassifier.swift': '68e5e0433a1a33b408f54663b06a9bc6720120b602d866c45d77ee3824fa5b09', 'Sources/CADKernel/DefaultBooleanUVFaceSplitter.swift': '5da3b1cafda46b9d2ad7d062fe2bd6b67537f1be5b63e6edf53ffc2b75fe09f2', 'Sources/CADKernel/ExactCurveIdentity.swift': '24e211573c052c7d551c1448d067ba8e2e2894146d5fc0f738cc8473a2183a25', 'Sources/CADKernel/ExactCurveIdentityRegistry.swift': '28e76e8608e1fb68ed0f8d684585dfeb0bb94430ea7542f10b07a05178cabaf2', 'Sources/CADKernel/FiniteFaceContainment/DefaultFacePointContainmentTester.swift': '07c039529a618805efac7895af3d72d4006d9e1a4401c581c512ec2aa8aeb090', 'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentPreparationCache.swift': 'a84a091a75a49252999be63b3edd60ee4a289d7b89e0dce0802d49dbef8a656f', 'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentTesting.swift': '5ca01ea27efac4445d0fc7e2cd2fc8b1b176b892db51efe404e82fbb3c9e66f4', 'Sources/CADKernel/OriginalBRepBounds/OriginalFaceParameterBounds.swift': '15f6e1e8b382203823afafaf23b07d5482acea5cf71532c7e53b905dbe06b21b', 'Sources/CADKernel/OriginalTrimContact/ExactTrimEdgeIntersector.swift': 'a0cc1aa9e24a20244460cd2f8cb11596104597f1c8695708805e3ee3bc878e2b', 'Sources/CADKernel/PreparedBooleanOperation/PreparedBooleanQueryLifetime.swift': '85b21396bd8214ab18865b89656ca833d98a556456b3ffaedd85fb82eea63e24', 'Sources/CADKernel/RectangularBooleanClipContactRefiner.swift': 'cc490d1da2678abd43bf42aa06e8847ef69f60f75d194f0f2c935bf62c6be6e3', 'Sources/CADKernel/OriginalGeometryQuery/OriginalQueryExecution+Kernel.swift': '3eefe74bebf926f6271411241d1df19f7cea226ac20f1f239917889de7967e8b', 'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentCapabilities.swift': 'fbbc7b7353a653e22791414dafabc1906f1c6cf7d41ed1d90c84a4e361d4e427'}}
FIXTURES={'Tests/CADKernelTests/KernelUVSplitDiagnosticChecks.swift': '2177a88255def582458ddc9c92b24d79f62b65fb9235f79fff4480d656ad6875', 'Tests/CADKernelTests/FinitePlaneContainmentAdmissionChecks.swift': '601a7eab03343430e59754500f5d422bafd2255a451892b21ef016e70da340ea'}
EXPECTED=['PASS emptyGraphRemainsAGenuineEmptySplit', 'PASS lowerWorkRefusalRetainsItsOriginalClassification', 'PASS lowerCallerCancellationRetainsItsOriginalCause', 'PASS externalProviderRetainsItsEmptyCapabilityFallbackAndCaller', 'PASS exactPlanarCutRetainsItsSourceAndUVLaw', 'PASS finitePlaneProximityUsesRetainedMaterialAndSource', 'PASS finiteBoundsAndOutsideToleranceKeepTheirCompletePath', 'PASS primitiveProjectionPreservesCallerWorkAndCancellation']
def digest(p):
 with pathlib.Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def prepare(lane):
 out=BASE/lane;out.mkdir(exist_ok=False);pins={}
 def pin(p,h=None):
  p=pathlib.Path(p);v=digest(p);require(h is None or v==h,'Hash differs: '+str(p));require(str(p) not in pins or pins[str(p)]==v,'Conflicting pin: '+str(p));pins[str(p)]=v;return v
 mapping=ROOT/'ir-prefix-clients-r2/products.json';pin(mapping,'4f9c08841532da5cfb48480dc602fefce9597f063f12b8a6191ebf23b38bf74d')
 item=json.loads(mapping.read_text())['lanes'][lane]
 prefix=pathlib.Path(item['receipt']);pin(prefix,item['receiptSHA256']);r=json.loads(prefix.read_text())
 require(r['status']=='passed' and not r['postflightDrift'] and r['sourcesProductsAndLogsUnchanged'],'IR prefix not accepted.')
 for p,h in r['inputAndProductSHA256'].items():pin(p,h)
 for p,h in item['products'].items():pin(p,h)
 for p,h in item['logs'].items():pin(p,h)
 native=ROOT/'native-full-r9/receipt.json';pin(native,'96022991cbe7e96ead20646f1fa8e7c904f330ac62aefd51f7ec22d70a7cf172');n=json.loads(native.read_text())
 require(all(n['steps'][m]['exitCode']==0 and n['steps'][m]['stopReason'] is None for m in ['CADModeling','CADKernel']),'Native actual source subset authority failed.')
 inventory_file=ROOT.parent/'u1-direct-gaps-kernel-closure-20261017/uv-split-caller-inputs.json'
 pin(inventory_file,'b005b5e4f848c08e1955170f982659bc5b3f4a42679a7207da9b6dc17ed8b8f4')
 baseline=json.loads(inventory_file.read_text())
 expected_delta={'Sources/CADKernel/BooleanClosedFaceIntersection.swift': 'a79657d61b3a59e0010a18ee9e8103a466a285f2bcca44358575e766b467032b', 'Sources/CADKernel/BooleanUVSplitGraph.swift': '3306e0ca49f17fc5f99987166ca2630c0765bd632ec4378e36a0d69898b6a11d', 'Sources/CADKernel/DefaultBooleanUVFaceSplitter.swift': '5da3b1cafda46b9d2ad7d062fe2bd6b67537f1be5b63e6edf53ffc2b75fe09f2', 'Sources/CADKernel/FiniteFaceContainment/DefaultFacePointContainmentTester.swift': '07c039529a618805efac7895af3d72d4006d9e1a4401c581c512ec2aa8aeb090', 'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentTesting.swift': '5ca01ea27efac4445d0fc7e2cd2fc8b1b176b892db51efe404e82fbb3c9e66f4', 'Sources/CADKernel/OriginalTrimContact/ExactTrimEdgeIntersector.swift': 'a0cc1aa9e24a20244460cd2f8cb11596104597f1c8695708805e3ee3bc878e2b', 'Sources/CADKernel/RectangularBooleanClipContactRefiner.swift': 'cc490d1da2678abd43bf42aa06e8847ef69f60f75d194f0f2c935bf62c6be6e3', 'Sources/CADModeling/BRepSewingEdgeSubdivider.swift': '973861c2a55e26c8e625e31795e3499a462f53a65b27f0f1b3d4f57280a4b387', 'Sources/CADModeling/SourceFacePatch/SourceBRepFacePatchBuilder.swift': 'a8f0293a8e308b1cbfccb3bfbf9e7f70441691c92dd10e8edb0fe48dbbfe371f'}
 actual_delta={v['path']:MODULES[module][v['path']] for module,a in baseline['wholeFileInputs'].items() for v in a if MODULES[module][v['path']]!=v['sha256']}
 require(actual_delta==expected_delta,'Only the accepted Native9 source deltas may update the original whole-file inventory; the one new capability owner is explicitly added.')
 planar=ROOT.parent/'u1-direct-gaps-kernel-closure-20261017/uv-split-exact-planar-inputs-r1.json'
 pin(planar,'19e5dd0fbcc5a70eed8c513b7e01de0e2195e4fa834123029502a100e4aacd15')
 require({k:len(v) for k,v in MODULES.items()}=={'CADModeling':17,'CADKernel':30},'Actual whole-file closure count differs.')
 lower={p:h for p,h in n['sourceSHA256'].items() if p.startswith(('Sources/CADCore/','Sources/CADGeometry/','Sources/CADTopology/','Sources/CADIR/'))}
 require(lower==r['productionSourceSHA256'] and len(lower)==3198,'Current lower source map differs.')
 for rel,h in lower.items():pin(SOURCE/rel,h)
 geo_file=ROOT/'current-geometry'/lane/'receipt.json';g=json.loads(geo_file.read_text());selected=g['lanes'][lane]
 module_dir=out/'modules';module_dir.mkdir()
 ir_dir=pathlib.Path(next(p for p in item['products'] if p.endswith('/CADIR.swiftmodule'))).parent
 flags=selected['commands']['compile'][:selected['commands']['compile'].index('-module-name')]
 flags=[flags[0],'-I',str(module_dir),'-I',str(ir_dir)]+flags[1:]
 commands={};products={}
 for module,inventory in MODULES.items():
  for rel,h in inventory.items():
   require(n['sourceSHA256'][rel]==h,'Native owning-source subset differs: '+rel);pin(SOURCE/rel,h)
   dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/rel,dest);pin(dest,h)
  rsp=out/(module+'Sources.rsp');rsp.write_text(''.join('"'+str(out/'snapshot'/rel)+'"\n' for rel in sorted(inventory)));pin(rsp)
  target=module_dir/(module+'.swiftmodule');cmd=flags+['-module-name',module,'-emit-module','-emit-module-path',str(target)];products[module]=[str(target)]
  if lane!='embedded':
   obj=module_dir/(module+'.code.o');cmd+=['-emit-object','-o',str(obj)];products[module].append(str(obj))
  commands[module]=cmd+['@'+str(rsp)]
 replacements={}
 for rel,h in FIXTURES.items():
  pin(SOURCE/rel,h);dest=out/'snapshot'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(SOURCE/rel,dest);pin(dest,h)
  replacements[rel]=str(dest)
 private_entry=BASE/'UVFinitePlanePortable.swift';pin(private_entry,'2c0dcb99be457bc52fcf658302d43f67292da2f3585e9a9f5d5432b1724702a4')
 destination=out/'snapshot/Portable/UVFinitePlanePortable.swift';destination.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(private_entry,destination);pin(destination,'2c0dcb99be457bc52fcf658302d43f67292da2f3585e9a9f5d5432b1724702a4');replacements['private-orchestrator']=str(destination)
 link=[];count=0
 old_inputs=r['fixtureSHA256']
 for arg in r['commands']['client-link']:
  if any(arg.endswith('/snapshot/'+rel) for rel in old_inputs):
   if count==0:link+=list(replacements.values())
   count+=1
  else:link.append(arg)
 require(count==2,'Expected two genuine IR fixture inputs to replace.')
 link=[link[0],'-I',str(module_dir)]+link[1:]
 if lane!='embedded':
  pos=link.index('-o');link[pos:pos]=[p for paths in products.values() for p in paths if p.endswith('.code.o')]
 exe=out/('UVFinitePlane' if lane=='asan' else 'UVFinitePlane.wasm');link[link.index('-o')+1]=str(exe)
 runtime=[str(exe) if v==r['executable'] else v for v in r['commands']['runtime']]
 commands.update({'client-link':link,'runtime':runtime})
 compiled=r['retainedCompilerPhases'] if lane=='asan' else {k:r['steps'][k] for k in ['CADTopology','CADIR']}
 prior=sum(s['elapsedSeconds'] for s in g['phases'])+sum(s['elapsedSeconds'] for s in compiled.values())
 if lane=='asan':
  previous=ROOT/'uv-finite-clients-r1/asan/receipt.json';pin(previous,'b890e7a86760bd933d0fc6968abb40f566f2671e6d7a759e3a0b7675c85fc9a4');failed=json.loads(previous.read_text());require(not failed['postflightDrift'],'Original failed compiler receipt drifted.');pin(previous.parent/'CADModeling.log',failed['steps']['CADModeling']['logSHA256']);prior+=sum(s['elapsedSeconds'] for s in failed['steps'].values())
 prior_success=ROOT/'uv-finite-clients-r2'/lane/'receipt.json'
 expected_prior={'asan':'dfd30d6a0cb4faa8722d903a7cc5833b4e960375e0c62d5764c7505384c578db','wasm':'34b90131b89e78ec3caca5b317a840d800f1a3f7458a35dfc972018534c7cd71'}
 require(lane in expected_prior,'Only ASAN and normal WASM are released for this final snapshot.')
 pin(prior_success,expected_prior[lane]);prior_record=json.loads(prior_success.read_text());require(prior_record['status']=='passed' and not prior_record['postflightDrift'],'Prior local seven-check proof differs.')
 prior+=sum(step['elapsedSeconds'] for step in prior_record['steps'].values())
 pin(__file__);pin(HARNESS/'native_tests.py')
 plan={'status':'prepared-not-executed','lane':lane,'scope':'Actual whole-file Modeling17/Kernel30 closure with five UV-splitter and three finite-plane checks, including real external provider same-A fallback. Genuine public protocol/session witnesses; no Bridge, Exchange, all-geometry-family or whole Kernel acceptance.','sourceRoot':str(SOURCE),'prefix':{'path':str(prefix),'sha256':pins[str(prefix)]},'nativeSourceSubsetAuthority':{'path':str(native),'sha256':pins[str(native)]},'moduleSources':MODULES,'declarationClosureFinding':{'cause':'BRepSewingFacePatch.swift55/81 and BRepSewingLoop.swift56 require contextualizedSewingFailure owned by whole BRepSewingRequest.swift226; its actual stored fields and body require the other four added whole source files.','addedActualWholeFiles':{'Sources/CADModeling/BRepSewingRequest.swift': 'dff5375ee4476c00fbe4f3ad24d85ff177c31f96ea778b2cd42f28bd0c9c61bf', 'Sources/CADModeling/BRepSewingBodyTopology.swift': 'bf62df41fbaf630fab2804648ae3d89c0f322e3a2c9630b2ee7770d3c8e3d7c9', 'Sources/CADModeling/BRepSewingShell.swift': '6464b0122ef26823e97151dcd11266040710d4775d64414de54647921ddb815d', 'Sources/CADModeling/BRepSewingSolidComponent.swift': '53b8e5266e4ddde456a36becd6667c5e78d8585334fc7bb13a1d25aba1efcb25', 'Sources/CADModeling/BRepSewingTopologyNamespace.swift': 'db27d91fc4733a0199af3b6bc953be866f862bf67a80e1df846b8e9f89e28426'},'productionEdits':0,'originalFailedReceipt':str(ROOT/'uv-finite-clients-r1/asan/receipt.json')},'newActualCapabilitySource':{'path':'Sources/CADKernel/FiniteFaceContainment/FacePointContainmentCapabilities.swift','sha256':MODULES['CADKernel']['Sources/CADKernel/FiniteFaceContainment/FacePointContainmentCapabilities.swift']},'previousLocalSevenCheckReceipt':{'path':str(prior_success),'sha256':pins[str(prior_success)],'scope':'Historical seven checks before new API/source imports. Current eight-check runtime is independent.'},'fixtureSHA256':FIXTURES,'privateClientOrchestrator':{'path':str(private_entry),'sha256':pins[str(private_entry)],'role':'Only the seven existing shared check calls and identical PASS lines; no production declaration, algorithm or test body substitution.'},'clientInputs':list(replacements.values()),'inventoryAuthority':{'path':str(inventory_file),'sha256':pins[str(inventory_file)],'authorizedCurrentSourceDeltas':actual_delta},'uvFixtureAuthority':{'path':str(planar),'sha256':pins[str(planar)]},'commands':commands,'products':products,'executable':str(exe),'expectedOutputLines':EXPECTED,'priorCoreGeometryTopologyIRCompileSeconds':prior,'bounds':{'compileLinkSeconds':1200,'runtimeSeconds':120,'processTreeRSSBytes':RSS_BYTES,'jobs':1},'inputAndProductSHA256':pins,'moduleRegeneration':2,'lowerModuleRegeneration':0}
 write(out/'plan.json',plan);print(json.dumps({'status':'prepared','lane':lane,'plan':str(out/'plan.json'),'sha256':digest(out/'plan.json'),'pins':len(pins)}))
def execute(lane):
 out=BASE/lane;path=out/'plan.json';plan=json.loads(path.read_text());require(not (out/'receipt.json').exists(),'Output already executed; preserve terminal receipt.')
 pins=dict(plan['inputAndProductSHA256']);pins[str(path)]=digest(path)
 def verify():return [p for p,h in pins.items() if not pathlib.Path(p).is_file() or digest(p)!=h]
 require(not verify(),'Preflight input/product/source drift.')
 r=dict(plan);r.update({'status':'running','steps':{},'inputAndProductSHA256':pins});save=lambda:write(out/'receipt.json',r)
 try:
  env=dict(os.environ);env.pop('TOOLCHAINS',None);env['ASAN_OPTIONS']='halt_on_error=1:abort_on_error=1'
  deadline=time.monotonic()+max(0,1200-plan['priorCoreGeometryTopologyIRCompileSeconds']);save()
  for name,cmd in plan['commands'].items():
   step=run(cmd,out/(name+'.log'),env,deadline=time.monotonic()+120 if name=='runtime' else deadline,stage_limit=120 if name=='runtime' else 1200)
   r['steps'][name]=step;pins[str(out/(name+'.log'))]=step['logSHA256']
   if name in plan['products'] and step['exitCode']==0 and step['stopReason'] is None:
    for p in plan['products'][name]:r.setdefault('compiledProductSHA256',{})[p]=digest(p);pins[p]=digest(p)
   if name=='client-link' and step['exitCode']==0:r['executableSHA256']=digest(plan['executable']);pins[plan['executable']]=r['executableSHA256']
   save();require(step['exitCode']==0 and step['stopReason'] is None,name+' failed; inspect actual log.')
  observed=[s for s in (out/'runtime.log').read_text().splitlines() if s.startswith('PASS ')]
  require(observed==EXPECTED,'UV/finite-plane oracle output differs.');r['postflightDrift']=verify();require(not r['postflightDrift'],'Postflight drift.')
  r['sourcesProductsAndLogsUnchanged']=True;r['status']='passed';save();print(json.dumps({'status':'passed','lane':lane,'oracles':len(observed),'receipt':str(out/'receipt.json')}))
 except Exception as e:
  r['status']='failed';r['failure']=str(e);r['postflightDrift']=verify();save();raise
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--prepare',action='store_true');a.add_argument('--lane',choices=['asan','wasm','embedded']);v=a.parse_args()
 if v.prepare:
  for lane in ([v.lane] if v.lane else ['asan','wasm','embedded']):prepare(lane)
 else:require(v.lane is not None,'Lane required.');execute(v.lane)
