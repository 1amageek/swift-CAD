#!/usr/bin/env python3
"""Run four frozen metadata oracles on exact current Core and Geometry products."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import sys
import time

BASE = Path(__file__).resolve().parent
ROOT = BASE.parent
SOURCE = Path('/Users/1amageek/.codex/worktrees/g01-direct-delivery-20261016/swift-CAD')
HARNESS = Path('/Users/1amageek/.codex/worktrees/m4-m8-completion-recovered/swift-CAD/Tests/OriginalQueryExecutionVerification')
sys.path.insert(0, str(HARNESS))
from native_tests import run, RSS_BYTES

INPUTS = {
    'Tests/CADGeometryTests/OriginalQueryDiagnosticPrefixChecks.swift': '36c50cbc32add0d989fc4c009a6c4b64bcff5116d3c18d020cc2d8ba78f56e93',
    'Tests/OriginalQueryExecutionVerification/OriginalQueryDiagnosticPrefixPortable.swift': '8c885a12abfe85b1284ec454517b835f361052b2d4d4e3e7917eb078d6eec1c9',
}
EXPECTED = [
    'PASS prefixPreservesEveryPublishedFieldAndInnerContext',
    'PASS rawResourcePublicationRetainsCauseAndFillsOnlyMissingContext',
    'PASS explicitClassificationOwnerStillControlsItsAggregateDecision',
    'PASS diagnosticPrefixNeverClassifiesCancellationOrInventsForeignAuthority',
]


def digest(path):
    with Path(path).open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--lane', required=True, choices=['asan', 'wasm', 'embedded'])
    args = parser.parse_args()
    output = BASE / args.lane
    output.mkdir(exist_ok=False)
    pins = {}
    record = {'status': 'preparing', 'lane': args.lane, 'scope': 'Four metadata oracles on actual current Core67 and Geometry2171 products; no IR, Kernel, whole-family or full-task acceptance.',
              'moduleRegeneration': 0, 'steps': {}, 'bounds': {'compileLinkSeconds': 1200, 'runtimeSeconds': 120, 'processTreeRSSBytes': RSS_BYTES, 'jobs': 1},
              'inputAndProductSHA256': pins, 'expectedOutputLines': EXPECTED}

    def save():
        (output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')

    def pin(path, expected=None):
        path = Path(path)
        observed = digest(path)
        require(expected is None or observed == expected, 'Input/product hash differs: ' + str(path))
        require(str(path) not in pins or pins[str(path)] == observed, 'Conflicting input pin: ' + str(path))
        pins[str(path)] = observed
        return observed

    def verify():
        return [path for path, expected in pins.items() if not Path(path).is_file() or digest(path) != expected]

    try:
        geometry_receipt = ROOT / 'current-geometry' / args.lane / 'receipt.json'
        geometry = json.loads(geometry_receipt.read_text())
        selected = geometry['lanes'][args.lane]
        authority = ROOT / 'native-current-geometry-r2/receipt.json'
        pin(authority, 'e204846e7c7cab172f79257ef812847d774ffcc6c6369c86639da1a613a8d4d8')
        source_authority = json.loads(authority.read_text())
        require(geometry['status'] == 'compiled-only' and geometry['compileCore'], 'Current Core and Geometry require their actual fresh successful compiler phases.')
        require(geometry['sourceSHA256'] == source_authority['sourceSHA256'], 'Geometry source authority differs.')
        require(all(not geometry[name] for name in ['currentDrift', 'snapshotDrift', 'productDrift']), 'Geometry origin has drift.')
        record['geometryOrigin'] = {'path': str(geometry_receipt), 'sha256': pin(geometry_receipt)}
        record['sourceAuthority'] = {'path': str(authority), 'sha256': pins[str(authority)], 'scope': 'Actual successful Native current Core and Geometry source authority'}
        record['productionSourceSHA256'] = geometry['sourceSHA256']
        record['productionSourceRoot'] = str(geometry_receipt.parent / 'snapshot')
        require(geometry['sourceCount'] == {'CADCore': 67, 'CADGeometry': 2171}, 'Production input counts differ.')
        for relative, expected in geometry['sourceSHA256'].items():
            pin(geometry_receipt.parent / 'snapshot' / relative, expected)
        phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-compile')
        require(phase['exitCode'] == 0 and phase['stopReason'] is None and phase['command'] == selected['commands']['compile'], 'Geometry compiler phase is not accepted.')
        pin(phase['log'], phase['logSHA256'])
        response = Path(phase['command'][-1][1:])
        pin(response, selected['responseSHA256'])
        require(set(shlex.split(response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADGeometry/')}, 'Geometry compiler inventory differs.')
        for mapping in [selected['compiledProductSHA256'], selected['compiledCoreProductSHA256'], selected['platformArchiveSHA256']]:
            for path, expected in mapping.items():
                pin(path, expected)
        for path, item in selected['dependencies'].items():
            pin(path, item['sha256'])
            pin(item['source'], item['sha256'])
        core_phase = next(item for item in geometry['phases'] if item['name'] == args.lane + '-core-compile')
        require(core_phase['exitCode'] == 0 and core_phase['stopReason'] is None and core_phase['command'] == selected['commands']['core-compile'], 'Current Core compiler phase differs.')
        pin(core_phase['log'], core_phase['logSHA256'])
        core_response = Path(core_phase['command'][-1][1:])
        pin(core_response, selected['coreResponseSHA256'])
        require(set(shlex.split(core_response.read_text())) == {str(geometry_receipt.parent / 'snapshot' / relative) for relative in geometry['sourceSHA256'] if relative.startswith('Sources/CADCore/')}, 'Current Core compiler inventory differs.')
        record['retainedCoreCompilerPhase'] = core_phase
        product_map = ROOT / 'current-geometry/products.json'
        pin(product_map, 'd09b7659aca7757e57f16805d1a1a637d5327b023d99b688a70133c5fc93b0d8')
        require(json.loads(product_map.read_text())['lanes'][args.lane]['receiptSHA256'] == pins[str(geometry_receipt)], 'Current product-map authority differs.')
        pin(HARNESS / 'native_tests.py')
        pin(Path(__file__))
        for relative, expected in geometry['toolSHA256'].items():
            pin(Path(phase['command'][0]).parent / relative, expected)
        for path, expected in geometry['wasmSDK']['metadataSHA256'].items():
            pin(Path(geometry['wasmSDK']['path']) / path, expected)
        pin(Path(geometry['nativeSDK']['path']) / 'SDKSettings.json', geometry['nativeSDK']['SDKSettings.json'])
        pin(geometry['nativeLinker']['path'], geometry['nativeLinker']['sha256'])
        copied = []
        for relative, expected in INPUTS.items():
            pin(SOURCE / relative, expected)
            destination = output / 'snapshot' / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(SOURCE / relative, destination)
            pin(destination, expected)
            copied.append(str(destination))
        link = []
        replaced = 0
        for value in selected['commands']['link']:
            if value.endswith('/snapshot/Tests/OriginalQueryExecutionVerification/FullGeometryPortable.swift'):
                link.extend(copied)
                replaced += 1
            else:
                link.append(value)
        require(replaced == 1, 'Expected one original standalone client source in link command.')
        old_executable = selected['products'][-1]
        executable = output / ('DiagnosticPrefix' if args.lane == 'asan' else 'DiagnosticPrefix.wasm')
        link[link.index('-o') + 1] = str(executable)
        runtime = [str(executable) if item == old_executable else item for item in selected['commands']['runtime']]
        for item in runtime:
            if item.endswith('.mjs'):
                pin(item)
        record['commands'] = {'client-link': link, 'runtime': runtime}
        record['executable'] = str(executable)
        record['fixtureSHA256'] = INPUTS
        record['status'] = 'running'
        save()
        environment = dict(os.environ)
        environment.pop('TOOLCHAINS', None)
        environment['ASAN_OPTIONS'] = 'halt_on_error=1:abort_on_error=1'
        deadline = time.monotonic() + 1200
        for name, command in record['commands'].items():
            step = run(command, output / (name + '.log'), environment,
                       deadline=time.monotonic() + 120 if name == 'runtime' else deadline,
                       stage_limit=120 if name == 'runtime' else 1200)
            record['steps'][name] = step
            pin(output / (name + '.log'), step['logSHA256'])
            if name == 'client-link' and step['exitCode'] == 0:
                record['executableSHA256'] = pin(executable)
            save()
            require(step['exitCode'] == 0 and step['stopReason'] is None, name + ' failed; inspect actual log.')
        observed = [line for line in (output / 'runtime.log').read_text().splitlines() if line.startswith('PASS ')]
        require(observed == EXPECTED, 'Actual metadata oracle output differs.')
        record['postflightDrift'] = verify()
        require(not record['postflightDrift'], 'Source/tool/product/log drift after runtime.')
        record['sourcesProductsAndLogsUnchanged'] = True
        record['status'] = 'passed'
        save()
        print(json.dumps({'status': record['status'], 'receipt': str(output / 'receipt.json'), 'oracles': len(observed)}))
        return 0
    except Exception as error:
        record['status'] = 'failed'
        record['failure'] = str(error)
        record['postflightDrift'] = verify()
        save()
        print(str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
